﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.EF;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class KhachHangsController : Controller
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.KhachHang = Newtonsoft.Json.JsonConvert.SerializeObject(new KhachHang());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            KhachHang formData = db.KhachHangs.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.KhachHang = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchKhachHang());
            return View("SEARCH");
        }
    }
}
