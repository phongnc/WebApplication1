﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.EF;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class DonHangSPsController : Controller
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.DonHangSP = Newtonsoft.Json.JsonConvert.SerializeObject(new DonHangSP());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            DonHangSP formData = db.DonHangSPs.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.DonHangSP = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchDonHangSP());
            return View("SEARCH");
        }
    }
}
