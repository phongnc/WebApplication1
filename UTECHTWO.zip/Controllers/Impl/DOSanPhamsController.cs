﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.DO;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class DOSanPhamsController : Controller
    {
        private Models.DP.DPSanPhams db = new Models.DP.DPSanPhams();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.DOSanPham = Newtonsoft.Json.JsonConvert.SerializeObject(new DOSanPham());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            DOSanPham formData = db.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.DOSanPham = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchDOSanPham());
            return View("SEARCH");
        }
    }
}
