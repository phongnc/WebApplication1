﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.DO;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class DOBaoGiasController : Controller
    {
        private Models.DP.DPBaoGias db = new Models.DP.DPBaoGias();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.DOBaoGia = Newtonsoft.Json.JsonConvert.SerializeObject(new DOBaoGia());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            DOBaoGia formData = db.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.DOBaoGia = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchDOBaoGia());
            return View("SEARCH");
        }
    }
}
