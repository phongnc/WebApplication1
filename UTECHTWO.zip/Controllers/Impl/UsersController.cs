﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.EF;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class UsersController : Controller
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.User = Newtonsoft.Json.JsonConvert.SerializeObject(new User());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            User formData = db.Users.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.User = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchUser());
            return View("SEARCH");
        }
    }
}
