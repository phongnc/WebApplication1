﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.DO;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class DODonHangsController : Controller
    {
        private Models.DP.DPDonHangs db = new Models.DP.DPDonHangs();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.DODonHang = Newtonsoft.Json.JsonConvert.SerializeObject(new DODonHang());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            DODonHang formData = db.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.DODonHang = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchDODonHang());
            return View("SEARCH");
        }
    }
}
