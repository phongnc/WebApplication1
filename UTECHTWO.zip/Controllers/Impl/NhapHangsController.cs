﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.EF;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class NhapHangsController : Controller
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.NhapHang = Newtonsoft.Json.JsonConvert.SerializeObject(new NhapHang());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            NhapHang formData = db.NhapHangs.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.NhapHang = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchNhapHang());
            return View("SEARCH");
        }
    }
}
