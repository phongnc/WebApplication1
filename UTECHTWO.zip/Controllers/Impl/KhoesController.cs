﻿
using System.Net;
using System.Web.Mvc;
using UTECHTWO.Models.EF;
using UTECHTWO.Models.SO;
namespace UTECHTWO.Controllers
{
    public class KhoesController : Controller
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public ActionResult Index()
        {
            return View("CRUD");
        }
        public ActionResult Create()
        {
            ViewBag.Kho = Newtonsoft.Json.JsonConvert.SerializeObject(new Kho());
            return View("FORM");
        }
        public ActionResult Edit(int? id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Kho formData = db.Khoes.Find(id.Value);
            if (formData == null) { return HttpNotFound();}
            ViewBag.Kho = Newtonsoft.Json.JsonConvert.SerializeObject(formData);
            return View("FORM");
        }
        public ActionResult Search()
        {
            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new SearchKho());
            return View("SEARCH");
        }
    }
}
