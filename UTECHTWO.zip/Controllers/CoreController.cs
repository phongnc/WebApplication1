﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Reflection;
using System.IO;

// file này chứa tất cả các hàm cho việc generate, cần loại bỏ khi publish
// được sử dụng EF Model trong này khi loại thì loại cả EF Model
namespace UTECHTWO.Controllers
{
    public class CoreController : Controller
    {
        string strNameSpace = "UTECHTWO";
        string strBitValue = "BitValue";
        List<string> glang = new List<string>();
        //Models.EF.Model1 db = new Models.EF.Model1();
        Models.DO.COManuals da = new Models.DO.COManuals();
        int uid = 1; // Biz.Auth.AuthenticationHelpers.CurrentUser(HttpContext).IID
        //Bước 2 tạo EF Model và EF Entity bằng Visual Studio (Rebuild)
        //Bước 2 tạo DO Model từ ImplType manual (Rebuild)
        //Bước 3 tạo MVC Model (Dapper) chỉ dùng cho Entity
        public ActionResult CreateModel(string modelName = "")
        {
            string result = "";
            try
            {
                if (string.IsNullOrEmpty(modelName)) throw new Exception();
                var _model = Assembly.GetExecutingAssembly().GetTypes().First(o => (o.Namespace == strNameSpace + ".Models.EF") && (o.Name == modelName));
                var _modelProps = _model.GetProperties().Where(o => o.PropertyType.FullName.Contains(strNameSpace + ".Models.EF")).ToList();
                Models.EF.Model0 db0 = new Models.EF.Model0();
                var tvws = db0.Tables_vw.ToList();
                string strModel = "";
                string strScript = "";
                strModel += "\n" + @"using System.Collections.Generic;";
                strModel += "\n" + @"using " + strNameSpace + ".Models.EF;";
                strModel += "\n" + @"";
                strModel += "\n" + @"namespace " + strNameSpace + @".Models.DP";
                strModel += "\n" + @"{";
                strModel += "\n" + @"    public class " + modelName;
                strModel += "\n" + @"    {";
                for (int ip = 0; ip < _modelProps.Count; ip++)
                {
                    string str__1 = _modelProps[ip].PropertyType.FullName;
                    if (str__1.Contains("QLKUserVerifys_Tb"))
                    {
                        ;
                    }
                    str__1 = str__1.Substring(str__1.IndexOf(strNameSpace + ".Models.EF."));
                    str__1 = str__1.Substring(0, str__1.IndexOf(","));
                    string str__2 = str__1.Replace(strNameSpace + ".Models.EF.", "");

                    var _model_ = Assembly.GetExecutingAssembly().GetTypes().Where(o => o.Namespace == strNameSpace + ".Models.EF" && o.Name == str__2).First();
                    var _model_Props = _model_.GetProperties().ToList();
                    string tableName = _model_.Name;
                    if (string.IsNullOrEmpty(tableName) || (tvws.Count(o => o.Table_Name == tableName) != 1)) { result += (tableName + " not found") + "<br/>"; continue; }

                    string strColumns = "";
                    List<Models.EF.Columns_vw> cvws = db0.Columns_vw.Where(o => o.Table_Name == tableName).ToList();
                    string keyColumn = "";
                    try { keyColumn = cvws.First(o => o.Is_Id == true).Column_Name; }
                    catch
                    {
                        try
                        {
                            int _Is_Id = cvws.Count(o => o.Column_Name.EndsWith("_id"));
                            if (_Is_Id == 1) keyColumn = cvws.First(o => o.Column_Name.EndsWith("_id")).Column_Name;
                            else
                            {
                                _Is_Id = cvws.Count(o => o.Column_Name.EndsWith("ID"));
                                if (_Is_Id == 1) keyColumn = cvws.First(o => o.Column_Name.EndsWith("ID")).Column_Name;
                            }
                        }
                        catch { }
                    }
                    if (string.IsNullOrEmpty(keyColumn)) { result += (tableName + " not key") + "<br/>"; keyColumn = "NO_KEY"; }
                    for (int i = 0; i < cvws.Count; i++)
                    {
                        if (cvws[i].Is_Id) continue;
                        strColumns += @"""" + cvws[i].Column_Name + @""",";
                    }
                    strScript += "\n" + @"            " + _modelProps[ip].Name + @" = new DpSet<" + _model_.Name + @">()";
                    strScript += "\n" + @"            {";
                    strScript += "\n" + @"                ConnectionString = _ConnectionString,";
                    strScript += "\n" + @"                TableName = """ + _model_.Name + @""",";
                    strScript += "\n" + @"                IdentityColumn = """ + keyColumn + @""",";
                    strScript += "\n" + @"                Columns = new List<string>() { " + strColumns + " }";
                    strScript += "\n" + @"            };";
                    strModel += "\n" + @"        public DpSet<" + _model_.Name + @"> " + _modelProps[ip].Name + @" { get; set; }";
                    createView(_model_.Name, _modelProps[ip].Name, _model_.Name);
                    createController(_model_.Name, _modelProps[ip].Name, modelName);
                    createApiController(_model_.Name, _modelProps[ip].Name, modelName, keyColumn);
                    createApiClient(_model_.Name, _modelProps[ip].Name);
                }
                strModel += "\n" + @"        public " + modelName + @"()";
                strModel += "\n" + @"        {";
                strModel += "\n" + @"            string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings[""" + modelName + @"""].ToString();";
                strModel += strScript;
                strModel += "\n" + @"        }";
                strModel += "\n" + @"    };";
                strModel += "\n" + @"};";
                string path = Server.MapPath("~") + @"Models\DP\";
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);
                try
                {
                    using (StreamWriter writer = new StreamWriter(path + modelName + ".cs", false, System.Text.Encoding.UTF8))
                    {
                        writer.WriteLine(strModel);
                    }
                }
                catch { }
                try { createGooTran(modelName); } catch { }
            }
            catch { result = "Model Not Found"; }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        //Bước 3 tạo MVC Model (Dapper) chỉ dùng cho DOModel
        public ActionResult CreateDOModel(string modelName = "")
        {
            string result = "";
            try
            {
                if (string.IsNullOrEmpty(modelName)) throw new Exception();
                string contextName = "DP" + modelName.Substring(2) + "s";
                Models.DO.DOModel doModel = new Models.DO.DOModels().getModel(modelName);
                Models.DO.DOConfig keyConfig = doModel.Configs.First(o => o.MapName == "");
                var _model = Assembly.GetExecutingAssembly().GetTypes().First(o => (o.Namespace == strNameSpace + ".Models.DO") && (o.Name == modelName));
                Models.EF.Model0 db0 = new Models.EF.Model0();
                var tvws = db0.Tables_vw.ToList();
                string strModel = "";
                string strScript = "";
                string strTableInObj = "";
                strModel += "\n" + @"using System.Collections.Generic;";
                strModel += "\n" + @"using " + strNameSpace + ".Models.EF;";
                strModel += "\n" + @"using Dapper;";
                strModel += "\n" + @"";
                strModel += "\n" + @"namespace " + strNameSpace + @".Models.DP";
                strModel += "\n" + @"{";
                strModel += "\n" + @"    public class " + contextName + @" : DpSet<DO." + modelName + @">";
                strModel += "\n" + @"    {";
                for (int ip = 0; ip < doModel.Configs.Count; ip++)
                {
                    var _model_ = Assembly.GetExecutingAssembly().GetTypes().Where(o => o.Namespace == strNameSpace + ".Models.EF" && o.Name == doModel.Configs[ip].TypeName).First();
                    var _model_Props = _model_.GetProperties().ToList();
                    string tableName = _model_.Name;
                    if (string.IsNullOrEmpty(tableName) || (tvws.Count(o => o.Table_Name == tableName) != 1)) { result += (tableName + " not found") + "<br/>"; continue; }

                    string strColumns = "";
                    List<Models.EF.Columns_vw> cvws = db0.Columns_vw.Where(o => o.Table_Name == tableName).ToList();
                    string keyColumn = "";
                    try { keyColumn = cvws.First(o => o.Is_Id == true).Column_Name; }
                    catch { }
                    if (string.IsNullOrEmpty(keyColumn)) { result += (tableName + " not key") + "<br/>"; keyColumn = "NO_KEY"; }
                    for (int i = 0; i < cvws.Count; i++)
                    {
                        if (cvws[i].Is_Id) continue;
                        strColumns += @"""" + cvws[i].Column_Name + @""",";
                    }
                    strScript += "\n" + @"            " + doModel.Configs[ip].PropName + @" = new DpSet<" + _model_.Name + @">()";
                    strScript += "\n" + @"            {";
                    strScript += "\n" + @"                ConnectionString = _ConnectionString,";
                    strScript += "\n" + @"                TableName = """ + _model_.Name + @""",";
                    strScript += "\n" + @"                IdentityColumn = """ + keyColumn + @""",";
                    strScript += "\n" + @"                Columns = new List<string>() { " + strColumns + " }";
                    strScript += "\n" + @"            };";
                    strModel += "\n" + @"        public DpSet<" + _model_.Name + @"> " + doModel.Configs[ip].PropName + @" { get; set; }";
                    strTableInObj += doModel.Configs[ip].TypeName + ",";
                }
                createView(modelName, modelName + "s", strTableInObj);
                createController(modelName, modelName + "s", contextName);
                createApiController(modelName, modelName + "s", contextName, keyConfig.PropName + @"." + keyConfig.KeyName);
                createDOApiClient(modelName);
                strModel += "\n" + @"        public " + contextName + @"()";
                strModel += "\n" + @"        {";
                strModel += "\n" + @"            string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings[""" + "Model2" + @"""].ToString();";//use Model2 to get connectionString not modelName
                strModel += "\n" + @"            ConnectionString = _ConnectionString;";
                strModel += "\n" + @"            TableName = """ + keyConfig.TypeName + " AS " + keyConfig.PropName + @" INNER JOIN " + string.Join(" INNER JOIN ", doModel.Configs.Where(o => o.MapName != "").Select(o => o.TypeName + " AS " + o.PropName + @" ON " + keyConfig.PropName + @"." + o.MapName + @" = " + o.PropName + @"." + o.KeyName + @"")) + @""";";
                strModel += "\n" + @"            IdentityColumn = """ + keyConfig.PropName + @"." + keyConfig.KeyName + @""";";
                strModel += strScript;
                strModel += "\n" + @"        }";
                strModel += CreateDOModelOverride(modelName);
                strModel += "\n" + @"    };";
                strModel += "\n" + @"};";
                string path = Server.MapPath("~") + @"Models\DP\";
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);
                try
                {
                    using (StreamWriter writer = new StreamWriter(path + contextName + ".cs", false, System.Text.Encoding.UTF8))
                    {
                        writer.WriteLine(strModel);
                    }
                }
                catch { }
            }
            catch { result = "Model Not Found"; }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        string CreateDOModelOverride(string modelName = "")
        {
            Models.DO.DOModel doModel = new Models.DO.DOModels().getModel(modelName);
            Models.DO.DOConfig keyConfig = doModel.Configs.First(o => o.MapName == "");
            string strCode = "";
            strCode += "\n" + @"        public override DO." + modelName + @" Find(int id)";
            strCode += "\n" + @"        {";
            strCode += "\n" + @"            DO." + modelName + @" model = new DO." + modelName + @"();";
            for (int i = 0; i < doModel.Configs.Count; i++)
            {
                if (doModel.Configs[i].MapName == "")
                    strCode += "\n" + @"            model." + doModel.Configs[i].PropName + @" = " + doModel.Configs[i].PropName + @".Find(id);";
                else
                    strCode += "\n" + @"            model." + doModel.Configs[i].PropName + @" = " + doModel.Configs[i].PropName + @".Find(model." + keyConfig.PropName + @"." + doModel.Configs[i].MapName + @");";
            }
            strCode += "\n" + @"            return model;";
            strCode += "\n" + @"        }";
            strCode += "\n" + @"        public override DpSelectResult<DO." + modelName + @"> SelectResult(string _orderCondition = """", string _conditionString = """", object keyValues = null)";
            strCode += "\n" + @"        {";
            strCode += "\n" + @"            DpSelectResult<DO." + modelName + @"> result = new DpSelectResult<DO." + modelName + @">();";
            strCode += "\n" + @"            string _param6 = """ + string.Join(",", doModel.Configs.Select(o => o.PropName + ".*")) + @""";";
            strCode += "\n" + @"            string _param7 = ""INNER JOIN " + keyConfig.TypeName + @" AS " + keyConfig.PropName + @" ON T." + keyConfig.KeyName + @" = " + keyConfig.PropName + @"." + keyConfig.KeyName + @" INNER JOIN " + string.Join(" INNER JOIN ", doModel.Configs.Where(o => o.MapName != "").Select(o => o.TypeName + " AS " + o.PropName + @" ON " + keyConfig.PropName + @"." + o.MapName + @" = " + o.PropName + @"." + o.KeyName + @"")) + @""";";
            strCode += "\n" + @"            var multipleResults = DOSelectResult(_param6, _param7, _orderCondition, _conditionString, keyValues);";
            strCode += "\n" + @"            result.ResultCount = multipleResults.Read<int>().AsList()[0];";
            strCode += "\n" + @"            result.ResultList = multipleResults.Read<" + string.Join(",", doModel.Configs.Select(o => "EF." + o.TypeName)) + @", DO." + modelName + @">((" + string.Join(",", doModel.Configs.Select(o => "_" + o.PropName)) + @") => { return new DO." + modelName + @"() { " + string.Join(",", doModel.Configs.Select(o => o.PropName + " = _" + o.PropName)) + @" }; }, splitOn: """ + string.Join(",", doModel.Configs.Select(o => o.KeyName).Distinct()) + @""");";
            strCode += "\n" + @"            return result;";
            strCode += "\n" + @"        }";
            strCode += "\n" + @"        public override DO." + modelName + @" Add(DO." + modelName + @" model)";
            strCode += "\n" + @"        {";
            for (int i = 0; i < doModel.Configs.Count; i++)
            {
                if (doModel.Configs[i].MapName == "") continue;
                strCode += "\n" + @"            model." + doModel.Configs[i].PropName + @" = " + doModel.Configs[i].PropName + @".Add(model." + doModel.Configs[i].PropName + @");";
                strCode += "\n" + @"            model." + keyConfig.PropName + @"." + doModel.Configs[i].MapName + @" = model." + keyConfig.PropName + @"." + doModel.Configs[i].KeyName + @";";
            }
            strCode += "\n" + @"            model." + keyConfig.PropName + @" = " + keyConfig.PropName + @".Add(model." + keyConfig.PropName + @");";
            strCode += "\n" + @"            return model;";
            strCode += "\n" + @"        }";
            strCode += "\n" + @"        public override DO." + modelName + @" Update(DO." + modelName + @" model)";
            strCode += "\n" + @"        {";
            for (int i = 0; i < doModel.Configs.Count; i++)
            {
                strCode += "\n" + @"            model." + doModel.Configs[i].PropName + @" = " + doModel.Configs[i].PropName + @".Update(model." + doModel.Configs[i].PropName + @");";
            }
            strCode += "\n" + @"            return model;";
            strCode += "\n" + @"        }";
            strCode += "\n" + @"        public override DO." + modelName + @" Remove(DO." + modelName + @" model)";
            strCode += "\n" + @"        {";
            for (int i = 0; i < doModel.Configs.Count; i++)
            {
                strCode += "\n" + @"            model." + doModel.Configs[i].PropName + @" = " + doModel.Configs[i].PropName + @".Remove(model." + doModel.Configs[i].PropName + @");";
            }
            strCode += "\n" + @"            return model;";
            strCode += "\n" + @"        }";
            return strCode;
        }
        //Bước 4 tạo Views, Controllers, App_Api, App_Client
        public void createView(string tableName = "", string viewName = "", string tableInObj = "")
        {
            string path = Server.MapPath("~") + "Views" + @"\" + viewName + @"\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            string strCRUD = "";
            strCRUD += "\r" + @"@{";
            strCRUD += "\r" + @"    ViewBag.Title = ""QUẢN LÝ " + tableName.ToUpper() + @""";";
            strCRUD += "\r" + @"}";
            //strCRUD += "\r" + @"<div class=""row wrapper border-bottom white-bg page-heading""><div class=""col-lg-10""><h2>@ViewBag.Title</h2><ol class=""breadcrumb"">@ViewBag.Breadcrumb</ol></div><div class=""col-lg-2""></div></div>";
            strCRUD += "\r" + @"<div class=""row wrapper wrapper-content dx-viewport"">";
            strCRUD += "\r" + @"    <div class=""demo-container"">";
            //strCRUD += (viewName.StartsWith("DO") ? ("\r" + @"        <form action="""" id=""form-container""><div id=""searchContainer""></div><br /><div id=""searchButton""></div><div id=""reportButton""></div></form>") : "");
            strCRUD += "\r" + @"        <div id=""button""></div><br/>";
            strCRUD += "\r" + @"        <div id=""gridContainer""></div>";
            strCRUD += "\r" + @"    </div>";
            strCRUD += "\r" + @"</div>";
            //strCRUD += (viewName.StartsWith("DO") ? ("\r" + @"    <script>var _searchData = @Html.Raw(ViewBag._searchData);</script>") : "");
            strCRUD += "\r" + @"@section Scripts {";
            strCRUD += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/_Trans.js""></script>";
            strCRUD += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/_Common.js""></script>";
            strCRUD += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Impl/" + viewName + @".js""></script>";
            //strCRUD += (viewName.StartsWith("DO") ? ("\r" + @"    <script title=""javascript"" src=""~/App_Client/Impl/" + viewName + "-Search" + @".js""></script>") : "");
            strCRUD += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/dx.grd.js""></script>";
            if (da.ClientConfigs.Count(o => o.TableName == tableName && o.FTableName == "dxDetailLink") > 0)
            {
                strCRUD += "\r" + @"    <script>";
                strCRUD += "\r" + @"    	$(function () {";
                strCRUD += "\r" + @"    		$('#gridContainer').dxDataGrid({";
                strCRUD += "\r" + @"    			editing: {";
                strCRUD += "\r" + @"    				allowAdding: false,";
                strCRUD += "\r" + @"    				allowUpdating: false,";
                strCRUD += "\r" + @"    				allowDeleting: false,";
                strCRUD += "\r" + @"    			},";
                strCRUD += "\r" + @"    		});";
                strCRUD += "\r" + @"    		$('#button').dxButton({";
                strCRUD += "\r" + @"    			text: 'Tạo mới',";
                strCRUD += "\r" + @"    			type: 'success',";
                strCRUD += "\r" + @"    			onClick: function (e) {";
                strCRUD += "\r" + @"    				window.open(vDir + '/" + viewName + @"/Create', '_blank');";
                strCRUD += "\r" + @"    			}";
                strCRUD += "\r" + @"    		});";
                strCRUD += "\r" + @"    	});";
                strCRUD += "\r" + @"    </script>";
            }
            strCRUD += "\r" + @"}";

            try
            {
                using (StreamWriter writer = new StreamWriter(path + "CRUD.cshtml", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strCRUD);
                }
            }
            catch { }

            string strSEARCH = "";
            strSEARCH += "\r" + @"@{";
            strSEARCH += "\r" + @"    ViewBag.Title = ""DANH SÁCH " + tableName.ToUpper() + @""";";
            strSEARCH += "\r" + @"}";
            //strSEARCH += "\r" + @"<div class=""row wrapper border-bottom white-bg page-heading""><div class=""col-lg-10""><h2>@ViewBag.Title</h2><ol class=""breadcrumb"">@ViewBag.Breadcrumb</ol></div><div class=""col-lg-2""></div></div>";
            strSEARCH += "\r" + @"<div class=""row wrapper wrapper-content dx-viewport"">";
            strSEARCH += "\r" + @"    <div class=""demo-container"">";
            strSEARCH += "\r" + @"        <form action="""" id=""form-container""><div class=""row""><div class=""col-lg-12""><div class=""ibox""><div class=""ibox-content ibox-heading""><div id=""form" + tableName + @"""></div><br /><div id=""searchButton""></div><div id=""reportButton""></div></div></div></div></div></form>";
            strSEARCH += "\r" + @"        <div id=""button""></div><br/>";
            strSEARCH += "\r" + @"        <div id=""gridContainer""></div>";
            strSEARCH += "\r" + @"    </div>";
            strSEARCH += "\r" + @"</div>";
            strSEARCH += "\r" + @"@section Scripts {";
            strSEARCH += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/_Trans.js""></script>";
            strSEARCH += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/_Common.js""></script>";
            strSEARCH += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Impl/" + viewName + @".js""></script>";
            strSEARCH += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Impl/" + viewName + "-Search" + @".js""></script>";
            strSEARCH += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/dx.grd.js""></script>";
            strSEARCH += "\r" + @"<script>";
            strSEARCH += "\r" + @"var _searchData = @Html.Raw(ViewBag._searchData);";
            strSEARCH += "\r" + @"function _" + tableName.ToLower() + @"_search() { }";
            strSEARCH += "\r" + @"function initSearch() { _" + tableName.ToLower() + @"_form(_searchData, 2, true); }";
            strSEARCH += "\r" + @"$(function () {";
            strSEARCH += "\r" + @"})";
            strSEARCH += "\r" + @"</script>";
            strSEARCH += "\r" + @"}";

            try
            {
                using (StreamWriter writer = new StreamWriter(path + "SEARCH.cshtml", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strSEARCH);
                }
            }
            catch { }

            string strFORM = "";
            strFORM += "\r" + @"@{";
            strFORM += "\r" + @"    ViewBag.Title = ""TẠO MỚI " + tableName.ToUpper() + @""";";
            strFORM += "\r" + @"}";
            //strFORM += "\r" + @"<div class=""row wrapper border-bottom white-bg page-heading""><div class=""col-lg-10""><h2>@ViewBag.Title</h2><ol class=""breadcrumb"">@ViewBag.Breadcrumb</ol></div><div class=""col-lg-2""></div></div>";
            strFORM += "\r" + @"<div class=""row wrapper wrapper-content dx-viewport"">";
            strFORM += "\r" + @"    <div class=""demo-container"">";
            strFORM += "\r" + @"        <div id=""form" + tableName + @"""></div><br/>";
            strFORM += "\r" + @"        <div id=""button""></div>";
            strFORM += "\r" + @"    </div>";
            strFORM += "\r" + @"</div>";
            strFORM += "\r" + @"";
            strFORM += "\r" + @"@section Scripts {";
            strFORM += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/_Trans.js""></script>";
            strFORM += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Util/_Common.js""></script>";
            strFORM += "\r" + @"    <script title=""javascript"" src=""~/App_Client/Impl/" + viewName + @"-Form.js""></script>";
            strFORM += setInitEDSForm(tableInObj, tableName, viewName);
            strFORM += "\r" + @"}";

            try
            {
                using (StreamWriter writer = new StreamWriter(path + "FORM.cshtml", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strFORM);
                }
            }
            catch { }
        }
        public void createController(string tableName = "", string viewName = "", string modelName = "")
        {
            string strController = "";
            strController += "\n" + @"using System.Net;";
            strController += "\n" + @"using System.Web.Mvc;";
            strController += "\n" + @"using " + strNameSpace + @".Models." + (modelName.StartsWith("DP") ? "DO" : "EF") + @";";
            strController += "\n" + @"using " + strNameSpace + @".Models.SO;";
            strController += "\n" + @"namespace " + strNameSpace + @".Controllers";
            strController += "\n" + @"{";
            strController += "\n" + @"    public class " + viewName + @"Controller : Controller";
            strController += "\n" + @"    {";
            strController += "\n" + @"        private Models.DP." + modelName + " db = new Models.DP." + modelName + "();";
            strController += "\n" + @"        public ActionResult Index()";
            strController += "\n" + @"        {";
            //strController += (viewName.StartsWith("DO") ? ("\n" + @"        ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new Search" + tableName + @"());") : "");
            strController += "\n" + @"            return View(""CRUD"");";
            strController += "\n" + @"        }";
            strController += "\n" + @"        public ActionResult Create()";
            strController += "\n" + @"        {";
            strController += "\n" + @"            ViewBag." + tableName + @" = Newtonsoft.Json.JsonConvert.SerializeObject(new " + tableName + @"());";
            strController += "\n" + @"            return View(""FORM"");";
            strController += "\n" + @"        }";
            strController += "\n" + @"        public ActionResult Edit(int? id)";
            strController += "\n" + @"        {";
            strController += "\n" + @"            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }";
            strController += "\n" + @"            " + tableName + @" formData = db." + (modelName.StartsWith("DP") ? "" : (viewName + ".")) + @"Find(id.Value);";
            strController += "\n" + @"            if (formData == null) { return HttpNotFound();}";
            strController += "\n" + @"            ViewBag." + tableName + @" = Newtonsoft.Json.JsonConvert.SerializeObject(formData);";
            strController += "\n" + @"            return View(""FORM"");";
            strController += "\n" + @"        }";
            strController += "\n" + @"        public ActionResult Search()";
            strController += "\n" + @"        {";
            strController += "\n" + @"            ViewBag._searchData = Newtonsoft.Json.JsonConvert.SerializeObject(new Search" + tableName + @"());";
            strController += "\n" + @"            return View(""SEARCH"");";
            strController += "\n" + @"        }";
            strController += "\n" + @"    }";
            strController += "\n" + @"}";
            string path = Server.MapPath("~") + @"Controllers\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + "Controller.cs", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strController);
                }
            }
            catch { }
        }
        public void createApiController(string tableName = "", string viewName = "", string modelName = "", string keyColumn = "")
        {
            createSO(tableName, modelName);
            string DOorEF = (modelName.StartsWith("DP")) ? "DO" : "EF";
            string DOorEF_DB = (modelName.StartsWith("DP")) ? "db" : "db." + viewName;
            string strApiController = "";
            strApiController += "\n" + @"using System;";
            strApiController += "\n" + @"using System.Collections.Generic;";
            strApiController += "\n" + @"using System.Data;";
            strApiController += "\n" + @"using System.Data.Entity;";
            strApiController += "\n" + @"using System.Data.Entity.Infrastructure;";
            strApiController += "\n" + @"using System.Linq;";
            strApiController += "\n" + @"using System.Net;";
            strApiController += "\n" + @"using System.Net.Http;";
            strApiController += "\n" + @"using System.Web.Http;";
            strApiController += "\n" + @"using System.Web.Http.Description;";
            strApiController += "\n" + @"using " + strNameSpace + @".Models." + DOorEF + @";";

            strApiController += "\n" + @"namespace " + strNameSpace + @".Api";
            strApiController += "\n" + @"{";
            strApiController += "\n" + @"    public partial class Search" + viewName + @"Controller : ApiController";
            strApiController += "\n" + @"    {";
            strApiController += "\n" + @"        private Models.DP." + modelName + @" db = new Models.DP." + modelName + @"();";

            strApiController += "\n" + @"        // GET: api/" + viewName + @"";
            strApiController += "\n" + @"        public Models.DP.DpSelectResult<Models." + DOorEF + @"." + tableName + @"> PutSearch" + viewName + @"(Models.SO.Search"+ tableName + @" biz)";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            db." + ((modelName.StartsWith("DP")) ? (keyColumn.Substring(0, keyColumn.IndexOf("."))) : (viewName)) + @".SkipRows = biz.skip;";
            strApiController += "\n" + @"            db." + ((modelName.StartsWith("DP")) ? (keyColumn.Substring(0, keyColumn.IndexOf("."))) : (viewName)) + @".TakeRows = biz.take;";
            if (modelName.StartsWith("DP"))
            {
                strApiController += "\n" + @"            db.SkipRows = biz.skip;";
                strApiController += "\n" + @"            db.TakeRows = biz.take;";
            }
            strApiController += "\n" + @"            return " + DOorEF_DB + @".SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());";
            strApiController += "\n" + @"        }";
            strApiController += "\n" + @"    }";

            strApiController += "\n" + @"    public partial class " + viewName + @"Controller : ApiController";
            strApiController += "\n" + @"    {";
            strApiController += "\n" + @"        private Models.DP." + modelName + @" db = new Models.DP." + modelName + @"();";

            strApiController += "\n" + @"        // GET: api/" + viewName + @"";
            strApiController += "\n" + @"        public Models.DP.DpSelectResult<Models." + DOorEF + @"." + tableName + @"> Get" + viewName + @"(int skip = 0, int take = 10)";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            db." + ((modelName.StartsWith("DP")) ? (keyColumn.Substring(0, keyColumn.IndexOf("."))) : (viewName)) + @".SkipRows = skip;";
            strApiController += "\n" + @"            db." + ((modelName.StartsWith("DP")) ? (keyColumn.Substring(0, keyColumn.IndexOf("."))) : (viewName)) + @".TakeRows = take;";
            strApiController += "\n" + @"            return " + DOorEF_DB + @".SelectResult();";
            strApiController += "\n" + @"        }";

            strApiController += "\n" + @"        // GET: api/" + viewName + @"/5";
            strApiController += "\n" + @"        [ResponseType(typeof(Models." + DOorEF + @"." + tableName + @"))]";
            strApiController += "\n" + @"        public IHttpActionResult Get" + tableName + @"(int id)";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            Models." + DOorEF + @"." + tableName + @" biz = " + DOorEF_DB + @".Find(id);";
            strApiController += "\n" + @"            if (biz == null)";
            strApiController += "\n" + @"            {";
            strApiController += "\n" + @"                return NotFound();";
            strApiController += "\n" + @"            }";

            strApiController += "\n" + @"            return Ok(biz);";
            strApiController += "\n" + @"        }";

            strApiController += "\n" + @"        // PUT: api/" + viewName + @"/5";
            strApiController += "\n" + @"        [ResponseType(typeof(void))]";
            strApiController += "\n" + @"        public IHttpActionResult Put" + tableName + @"(int id, Models." + DOorEF + @"." + tableName + @" biz)";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            if (!ModelState.IsValid)";
            strApiController += "\n" + @"            {";
            strApiController += "\n" + @"                return BadRequest(ModelState);";
            strApiController += "\n" + @"            }";

            if (keyColumn == "NO_KEY")
                strApiController += "\n" + @"            /*";
            strApiController += "\n" + @"            if (id != biz." + keyColumn + @")";
            strApiController += "\n" + @"            {";
            strApiController += "\n" + @"                return BadRequest();";
            strApiController += "\n" + @"            }";
            if (keyColumn == "NO_KEY")
                strApiController += "\n" + @"            */";

            strApiController += "\n" + @"            //db.Entry(biz).State = EntityState.Modified;";

            strApiController += "\n" + @"            try";
            strApiController += "\n" + @"            {";
            strApiController += "\n" + @"                " + DOorEF_DB + @".Update(biz);";
            strApiController += "\n" + @"            }";
            strApiController += "\n" + @"            catch (DbUpdateConcurrencyException)";
            strApiController += "\n" + @"            {";
            strApiController += "\n" + @"                if (!" + tableName + @"Exists(id))";
            strApiController += "\n" + @"                {";
            strApiController += "\n" + @"                    return NotFound();";
            strApiController += "\n" + @"                }";
            strApiController += "\n" + @"                else";
            strApiController += "\n" + @"                {";
            strApiController += "\n" + @"                    throw;";
            strApiController += "\n" + @"                }";
            strApiController += "\n" + @"            }";

            strApiController += "\n" + @"            return StatusCode(HttpStatusCode.NoContent);";
            strApiController += "\n" + @"        }";

            strApiController += "\n" + @"        // POST: api/" + viewName + @"";
            strApiController += "\n" + @"        [ResponseType(typeof(Models." + DOorEF + @"." + tableName + @"))]";
            strApiController += "\n" + @"        public IHttpActionResult Post" + tableName + @"(Models." + DOorEF + @"." + tableName + @" biz)";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            if (!ModelState.IsValid)";
            strApiController += "\n" + @"            {";
            strApiController += "\n" + @"                return BadRequest(ModelState);";
            strApiController += "\n" + @"            }";

            strApiController += "\n" + @"            //biz." + strBitValue + @" = true;";
            strApiController += "\n" + @"            biz = " + DOorEF_DB + @".Add(biz);";
            strApiController += "\n" + @"            //db.SaveChanges();";

            if (keyColumn == "NO_KEY")
                strApiController += "\n" + @"            return BadRequest(ModelState);";
            else
                strApiController += "\n" + @"            return CreatedAtRoute(""DefaultApi"", new { id = biz." + keyColumn + @" }, biz);";
            strApiController += "\n" + @"        }";

            strApiController += "\n" + @"        // DELETE: api/" + viewName + @"/5";
            strApiController += "\n" + @"        [ResponseType(typeof(Models." + DOorEF + @"." + tableName + @"))]";
            strApiController += "\n" + @"        public IHttpActionResult Delete" + tableName + @"(int id)";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            Models." + DOorEF + @"." + tableName + @" biz = " + DOorEF_DB + @".Find(id);";
            strApiController += "\n" + @"            if (biz == null)";
            strApiController += "\n" + @"            {";
            strApiController += "\n" + @"                return NotFound();";
            strApiController += "\n" + @"            }";

            strApiController += "\n" + @"            //biz." + strBitValue + @" = !biz." + strBitValue + @";";
            strApiController += "\n" + @"            " + DOorEF_DB + @".Update(biz);";
            strApiController += "\n" + @"            //" + DOorEF_DB + @".Remove(biz);";
            strApiController += "\n" + @"            //db.SaveChanges();";

            strApiController += "\n" + @"            return Ok(biz);";
            strApiController += "\n" + @"        }";

            strApiController += "\n" + @"        //protected override void Dispose(bool disposing)";
            strApiController += "\n" + @"        //{";
            strApiController += "\n" + @"        //    if (disposing)";
            strApiController += "\n" + @"        //    {";
            strApiController += "\n" + @"        //        db.Dispose();";
            strApiController += "\n" + @"        //    }";
            strApiController += "\n" + @"        //    base.Dispose(disposing);";
            strApiController += "\n" + @"        //}";

            strApiController += "\n" + @"        private bool " + tableName + @"Exists(int id)";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            return db." + ((modelName.StartsWith("DP")) ? (keyColumn.Substring(0, keyColumn.IndexOf("."))) : (viewName)) + @".Count(id) > 0;";
            strApiController += "\n" + @"        }";
            strApiController += "\n" + @"    }";
            strApiController += "\n" + @"}";
            string path = Server.MapPath("~") + @"App_Api\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + "Controller.cs", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strApiController);
                }
            }
            catch { }
        }
        public void createSO(string tableName = "", string modelName = "")
        {
            string DOorEF = (modelName.StartsWith("DP")) ? "DO" : "EF";
            string strApiController = "";
            strApiController += "\n" + @"using System.Collections.Generic;";
            strApiController += "\n" + @"namespace " + strNameSpace + @".Models.SO";
            strApiController += "\n" + @"{";
            strApiController += "\n" + @"    public class Search" + tableName + @" : Models." + DOorEF + @"." + tableName;
            strApiController += "\n" + @"    {";
            strApiController += "\n" + @"        public int take { get; set; }";
            strApiController += "\n" + @"        public int skip { get; set; }";
            strApiController += "\n" + @"        public Search" + tableName + @"()";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            //TODO:";
            strApiController += "\n" + @"        }";
            strApiController += "\n" + @"        public string OrderCondition()";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            string _orderCondition =  """";";
            strApiController += "\n" + @"            return _orderCondition;";
            strApiController += "\n" + @"        }";
            strApiController += "\n" + @"        public string ConditionString()";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            string _conditionString = """";";
            strApiController += "\n" + @"            List<string> _conditionList = new List<string>();";
            strApiController += "\n" + @"            ";
            strApiController += "\n" + @"            if (_conditionList.Count > 0) _conditionString = string.Join("" AND "", _conditionList);";
            strApiController += "\n" + @"            return _conditionString;";
            strApiController += "\n" + @"        }";
            strApiController += "\n" + @"        public object ConditionObject()";
            strApiController += "\n" + @"        {";
            strApiController += "\n" + @"            return new {";
            strApiController += "\n" + @"            };";
            strApiController += "\n" + @"        }";
            strApiController += "\n" + @"    }";
            strApiController += "\n" + @"}";
            string path = Server.MapPath("~") + @"Models\SO\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + "Search" + tableName + ".cs", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strApiController);
                }
            }
            catch { }
        }
        public void createApiClient(string tableName = "", string viewName = "")
        {
            string result = "";
            Models.EF.Model0 db0 = new Models.EF.Model0();
            var tvws = db0.Tables_vw.ToList();

            string strScript = "";
            string strColumns = "";
            string strForm = "";
            string strFields = "";
            List<string> _ColumnsFields = createApiClientColumnField(tableName, "");
            strColumns = _ColumnsFields[0].Replace("#VIEWNAME", viewName);
            strFields = _ColumnsFields[1];
            List<Models.EF.Columns_vw> cvws = db0.Columns_vw.Where(o => o.Table_Name == tableName).ToList();
            string keyColumn = "";
            try { keyColumn = cvws.First(o => o.Is_Id == true).Column_Name; }
            catch { }
            if (string.IsNullOrEmpty(keyColumn)) { result += (tableName + " not key") + "<br/>"; keyColumn = "NO_KEY"; }
            strScript += setInitEDS(tableName, viewName);

            strScript += "\n" + @"function dump() {";
            strScript += "\n" + @"    ctrl = {";
            strScript += "\n" + @"    key: function(obj) { return obj." + keyColumn + @"; },";
            strScript += "\n" + @"    name: """ + viewName + @""",";
            strScript += "\n" + @"    columns: [";
            strScript += strColumns;
            strScript += "\n" + @"    ]";
            strScript += "\n" + @"    };";
            if (da.ClientConfigs.Count(o => o.TableName == tableName && o.FTableName == "dxDetailLink") > 0)
            {
                strScript += "\n" + @"    ctrl.onToolbarPreparing = function (e) {";
                strScript += "\n" + @"        var toolbarItems = e.toolbarOptions.items;";
                strScript += "\n" + @"        $.each(toolbarItems, function (_, item) {";
                strScript += "\n" + @"            if (item.name === ""addRowButton"") {";
                strScript += "\n" + @"                item.options.onClick = function (e) {";
                strScript += "\n" + @"                    window.open(vDir + '/"+ viewName + @"/Create', '_blank');";
                strScript += "\n" + @"                }";
                strScript += "\n" + @"            }";
                strScript += "\n" + @"        });";
                strScript += "\n" + @"    }";
            }
            strScript += "\n" + @"};";
            string path = Server.MapPath("~") + "App_Client" + @"\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + ".js", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strScript);
                }
            }
            catch { }
            strForm += "\n" + @"function _" + tableName.ToLower() + @"_form(data, cols, isNew) {";
            strForm += "\n" + @"    $(""#form" + tableName + @""").dxForm({";
            strForm += "\n" + @"        colCount: cols,";
            strForm += "\n" + @"        readOnly: !isNew,";
            strForm += "\n" + @"        showBorders: true,";
            strForm += "\n" + @"        formData: data,";
            strForm += "\n" + @"        labelLocation: ""top"",";
            strForm += "\n" + @"        items: [";
            strForm += strFields;
            strForm += "\n" + @"        ],";
            strForm += "\n" + @"    });";
            strForm += "\n" + @"    $(""#button"").dxButton({";
            strForm += "\n" + @"        text: ""Tạo " + tableName + @""",";
            strForm += "\n" + @"        type: ""success"",";
            strForm += "\n" + @"        onClick: function (e) {";
            strForm += "\n" + @"            var values = $(""#form" + tableName + @""").dxForm(""instance"")._options.formData;";
            strForm += "\n" + @"			if (values." + keyColumn + @" == 0) {";
            strForm += "\n" + @"			    return $.post(vDir + ""/api/" + viewName + @"/"", values).done(function (x) {";
            strForm += "\n" + @"			        location.href = vDir + ""/" + viewName + @"/"";";
            strForm += "\n" + @"			    });";
            strForm += "\n" + @"			}";
            strForm += "\n" + @"			else {";
            strForm += "\n" + @"			    return $.ajax({";
            strForm += "\n" + @"			        url: vDir + ""/api/" + viewName + @"/"" + encodeURIComponent(values." + keyColumn + @"),";
            strForm += "\n" + @"			        method: ""PUT"",";
            strForm += "\n" + @"			        data: values,";
            strForm += "\n" + @"			        success: function (x) {";
            strForm += "\n" + @"						location.href = vDir + ""/" + viewName + @"/"";";
            strForm += "\n" + @"			        },";
            strForm += "\n" + @"			    });";
            strForm += "\n" + @"			}";
            strForm += "\n" + @"			alert(""Có lỗi trong việc tạo " + tableName + @"""); ";
            strForm += "\n" + @"        }";
            strForm += "\n" + @"    });";
            strForm += "\n" + @"};";
            path = Server.MapPath("~") + "App_Client" + @"\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + "-Form.js", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strForm);
                }
            }
            catch { }
            string strSearch = "";
            strSearch += "\n" + @"function _" + tableName.ToLower() + @"_form(_searchData, cols, isNew) {";
            strSearch += "\n" + @"    $(""#form" + tableName + @""").dxForm({";
            strSearch += "\n" + @"        colCount: cols,";
            strSearch += "\n" + @"        readOnly: !isNew,";
            strSearch += "\n" + @"        showBorders: true,";
            strSearch += "\n" + @"        formData: _searchData,";
            strSearch += "\n" + @"        labelLocation: ""top"",";
            strSearch += "\n" + @"        items: [";
            strSearch += strFields;
            strSearch += "\n" + @"        ],";
            strSearch += "\n" + @"    });";
            strSearch += "\n" + @"    $(""#searchButton"").dxButton({";
            strSearch += "\n" + @"        text: ""Tìm kiếm"",";
            strSearch += "\n" + @"        type: ""success"",";
            strSearch += "\n" + @"        onClick: function (e) {";
            strSearch += "\n" + @"            //localStorage.setItem('_searchData', JSON.stringify(_searchData));";
            strSearch += "\n" + @"            var grid = $(""#gridContainer"").dxDataGrid('instance');";
            strSearch += "\n" + @"            //ctrl.datasource.load();";
            strSearch += "\n" + @"            grid.refresh();";
            strSearch += "\n" + @"        }";
            strSearch += "\n" + @"    });";
            strSearch += "\n" + @"};";
            path = Server.MapPath("~") + "App_Client" + @"\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + "-Search.js", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strSearch);
                }
            }
            catch { }
        }
        public void createGooTran(string modelName)
        {
            string strLang = @"var dic" + modelName + @" = [";
            for (int i = 0; i < glang.Count; i++)
            {
                strLang += "\n" + @"    { ""key"": """ + glang[i] + @""", ""value"": """ + glang[i] + @"!"" },";
            }
            strLang += "\n" + @"];";
            strLang += "\n" + "gooDics = gooDics.concat(dic" + modelName + @");";
            string path = Server.MapPath("~") + "App_Client" + @"\Util\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + "_Trans-" + modelName + ".js", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strLang);
                }
            }
            catch { }
        }
        public void createDOApiClient(string modelName = "")
        {
            Models.DO.DOModel doModel = new Models.DO.DOModels().getModel(modelName);
            Models.DO.DOConfig keyConfig = doModel.Configs.First(o => o.MapName == "");
            string strAssign = @"function (key, values) { " + string.Join(";", doModel.Configs.Select(o => "Object.assign(key." + o.PropName + ", values." + o.PropName + ")")) + @"; }";

            string result = "";

            string strScript = "";
            string strColumns = "";
            string strForm = "";
            string strFields = "";
            string strTableInObj = "";
            for (int i = 0; i < doModel.Configs.Count; i++)
            {
                List<string> _ColumnsFields = createApiClientColumnField(doModel.Configs[i].TypeName, doModel.Configs[i].PropName + ".");
                strColumns += _ColumnsFields[0].Replace("#VIEWNAME", modelName + "s"); ;
                strFields += "\n" + @"        {";
                if (doModel.DetailViewType == "TAB")
                {
                    strFields += "\n" + @"            title: """ + doModel.Configs[i].PropName + @""",";
                }
                else
                {
                    strFields += "\n" + @"            itemType: ""group"",";
                    strFields += "\n" + @"            caption: """ + doModel.Configs[i].PropName + @""",";
                }
                strFields += "\n" + @"            items: [";
                strFields += _ColumnsFields[1];
                strFields += "\n" + @"            ],";
                strFields += "\n" + @"        },";
                strTableInObj += doModel.Configs[i].TypeName + ",";
            }
            string keyColumn = "";
            try { keyColumn = keyConfig.PropName + "." + keyConfig.KeyName; }
            catch { }
            if (string.IsNullOrEmpty(keyColumn)) { result += (modelName + " not key") + "<br/>"; keyColumn = "NO_KEY"; }
            strScript += setInitEDS(strTableInObj, "");

            string viewName = modelName + "s";
            strScript += "\n" + @"function dump() {";
            strScript += "\n" + @"    ctrl = {";
            strScript += "\n" + @"    key: function(obj) { return obj." + keyColumn + @"; },";
            strScript += "\n" + @"    assign: " + strAssign + @",";
            strScript += "\n" + @"    name: """ + viewName + @""",";
            strScript += "\n" + @"    search: " + @"function() { return _" + modelName.ToLower() + @"_search(); },";
            strScript += "\n" + @"    columns: [";
            strScript += strColumns;
            strScript += "\n" + @"    ]";
            strScript += "\n" + @"    };";
                strScript += "\n" + @"    ctrl.onToolbarPreparing = function (e) {";
                strScript += "\n" + @"        var toolbarItems = e.toolbarOptions.items;";
                strScript += "\n" + @"        $.each(toolbarItems, function (_, item) {";
                strScript += "\n" + @"            if (item.name === ""addRowButton"") {";
                strScript += "\n" + @"                item.options.onClick = function (e) {";
                strScript += "\n" + @"                    window.open(vDir + '/" + viewName + @"/Create', '_blank');";
                strScript += "\n" + @"                }";
                strScript += "\n" + @"            }";
                strScript += "\n" + @"        });";
                strScript += "\n" + @"    }";
            strScript += "\n" + @"};";
            string path = Server.MapPath("~") + "App_Client" + @"\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + ".js", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strScript);
                }
            }
            catch { }
            strForm += "\n" + @"function _" + modelName.ToLower() + @"_form(data, cols, isNew) {";
            strForm += "\n" + @"    $(""#form" + modelName + @""").dxForm({";
            strForm += "\n" + @"        colCount: cols,";
            strForm += "\n" + @"        readOnly: !isNew,";
            strForm += "\n" + @"        showBorders: true,";
            strForm += "\n" + @"        formData: data,";
            strForm += "\n" + @"        labelLocation: ""top"",";
            strForm += "\n" + @"        items: [";
            if (doModel.DetailViewType == "TAB")
            {
                strForm += "\n" + @"        {";
                strForm += "\n" + @"        itemType: ""tabbed"",";
                strForm += "\n" + @"        tabs: [";
            }
            strForm += strFields;
            if (doModel.DetailViewType == "TAB")
            {
                strForm += "\n" + @"        ],";
                strForm += "\n" + @"        }";
            }
            strForm += "\n" + @"        ],";
            strForm += "\n" + @"    });";
            strForm += "\n" + @"    $(""#button"").dxButton({";
            strForm += "\n" + @"        text: ""Tạo " + modelName + @""",";
            strForm += "\n" + @"        type: ""success"",";
            strForm += "\n" + @"        onClick: function (e) {";
            strForm += "\n" + @"            var values = $(""#form" + modelName + @""").dxForm(""instance"")._options.formData;";
            strForm += "\n" + @"			if (values." + keyColumn + @" == 0) {";
            strForm += "\n" + @"			    return $.post(vDir + ""/api/" + viewName + @"/"", values).done(function (x) {";
            strForm += "\n" + @"			        location.href = vDir + ""/" + viewName + @"/"";";
            strForm += "\n" + @"			    });";
            strForm += "\n" + @"			}";
            strForm += "\n" + @"			else {";
            strForm += "\n" + @"			    return $.ajax({";
            strForm += "\n" + @"			        url: vDir + ""/api/" + viewName + @"/"" + encodeURIComponent(values." + keyColumn + @"),";
            strForm += "\n" + @"			        method: ""PUT"",";
            strForm += "\n" + @"			        data: values,";
            strForm += "\n" + @"			        success: function (x) {";
            strForm += "\n" + @"						location.href = vDir + ""/" + viewName + @"/"";";
            strForm += "\n" + @"			        },";
            strForm += "\n" + @"			    });";
            strForm += "\n" + @"			}";
            strForm += "\n" + @"			alert(""Có lỗi trong việc tạo " + modelName + @"""); ";
            strForm += "\n" + @"        }";
            strForm += "\n" + @"    });";
            strForm += "\n" + @"};";
            path = Server.MapPath("~") + "App_Client" + @"\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + "-Form.js", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strForm);
                }
            }
            catch { }
            string strSearch = "";
            strSearch += "\n" + @"function _" + modelName.ToLower() + @"_form(_searchData, cols, isNew) {";
            strSearch += "\n" + @"    $(""#form" + modelName + @""").dxForm({";
            strSearch += "\n" + @"        colCount: cols,";
            strSearch += "\n" + @"        readOnly: !isNew,";
            strSearch += "\n" + @"        showBorders: true,";
            strSearch += "\n" + @"        formData: _searchData,";
            strSearch += "\n" + @"        labelLocation: ""top"",";
            strSearch += "\n" + @"        items: [";
            strSearch += strFields;
            strSearch += "\n" + @"        ],";
            strSearch += "\n" + @"    });";
            strSearch += "\n" + @"    $(""#searchButton"").dxButton({";
            strSearch += "\n" + @"        text: ""Tìm kiếm"",";
            strSearch += "\n" + @"        type: ""success"",";
            strSearch += "\n" + @"        onClick: function (e) {";
            strSearch += "\n" + @"            //localStorage.setItem('_searchData', JSON.stringify(_searchData));";
            strSearch += "\n" + @"            var grid = $(""#gridContainer"").dxDataGrid('instance');";
            strSearch += "\n" + @"            //ctrl.datasource.load();";
            strSearch += "\n" + @"            grid.refresh();";
            strSearch += "\n" + @"        }";
            strSearch += "\n" + @"    });";
            strSearch += "\n" + @"};";
            path = Server.MapPath("~") + "App_Client" + @"\Impl\";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            try
            {
                using (StreamWriter writer = new StreamWriter(path + viewName + "-Search.js", false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine(strSearch);
                }
            }
            catch { }
        }
        List<string> createApiClientColumnField(string tableName, string morphName)
        {
            Models.EF.Model0 db0 = new Models.EF.Model0();
            var tvws = db0.Tables_vw.ToList();
            string strColumns = "";
            string strFields = "";
            List<Models.EF.Columns_vw> cvws = db0.Columns_vw.Where(o => o.Table_Name == tableName).ToList();
            for (int i = 0; i < cvws.Count; i++)
            {
                if (cvws[i].Is_Id) continue;
                strColumns += "\n" + @"        {";
                strFields += "\n" + @"        {";
                strColumns += "\n" + @"            dataField: """ + morphName + cvws[i].Column_Name + @""",";
                strFields += "\n" + @"            dataField: """ + morphName + cvws[i].Column_Name + @""",";
                strColumns += "\n" + @"            caption: gooTrans(""" + gooTrans(morphName + tableName + "." + cvws[i].Column_Name) + @"""),";
                strFields += "\n" + @"            label: { text: gooTrans(""" + gooTrans(morphName + tableName + "." + cvws[i].Column_Name) + @"""), },";
                if (!string.IsNullOrEmpty(mapType(cvws[i].Data_Type)))
                {
                    strColumns += "\n" + @"            dataType: """ + mapType(cvws[i].Data_Type) + @""",";
                    strFields += "\n" + @"            dataType: """ + mapType(cvws[i].Data_Type) + @""",";
                    string frmFields = frmType(mapType(cvws[i].Data_Type));
                    if (!string.IsNullOrEmpty(frmFields)) strFields += "\n" + @"            editorType: """ + frmFields + @""",";
                }
                strColumns += setColumn(cvws[i].Table_Name, cvws[i].Column_Name);
                strFields += setField(cvws[i].Table_Name, cvws[i].Column_Name);
                strColumns += "\n" + @"        },";
                strFields += "\n" + @"        },";
            }
            List<string> result = new List<string>();
            result.Add(strColumns); result.Add(strFields);
            return result;
        }
        public string gooTrans(string strLang)
        {
            if (string.IsNullOrEmpty(strLang)) return "";
            strLang = strLang.Trim();
            if (!glang.Contains(strLang)) glang.Add(strLang);
            return strLang;
        }
        public string mapType(string sqlType)
        {
            string[] sqlTypes = new string[] { "bigint", "bit", "char", "smalldatetime", "datetime", "datetime2", "float", "int", "ntext", "nvarchar", "varchar" };
            string[] netTypes = new string[] { "", "boolean", "", "datetime", "datetime", "datetime", "", "", "", "", "" };
            for (int i = 0; i < sqlTypes.Length; i++)
            {
                if (sqlTypes[i] == sqlType) return netTypes[i];
            }
            return "";
        }
        public string frmType(string mapType)
        {
            if (mapType == "boolean")
            {
                return "dxCheckBox";
            }
            else if (mapType == "datetime")
            {
                return "dxDateBox";
            }
            return "";
        }
        public string setColumn(string tableName, string columnName)
        {
            string result = "";
            if (columnName == "BizID")
            {
                result += "\n" + @"            visible: false,";
                result += "\n" + @"            formItem: { visible: false },";
            }
            else if (columnName == "IsDelete")
            {
                result += "\n" + @"            cellTemplate: function (element, info) {";
                result += "\n" + @"                colIsDelete(element, info);";
                result += "\n" + @"            },";
                result += "\n" + @"            formItem: { visible: false },";
            }
            else if (columnName == "Visible")
            {
                result += "\n" + @"            cellTemplate: function (element, info) {";
                result += "\n" + @"                colVisible(element, info);";
                result += "\n" + @"            },";
                result += "\n" + @"            formItem: { visible: false },";
            }
            else if (columnName == "Title")
            {
                result += "\n" + @"            validationRules: [";
                result += "\n" + @"            { type: 'required', message: 'Không được để trống' },";
                result += "\n" + @"            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },";
                result += "\n" + @"            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }";
                result += "\n" + @"            ],";
            }
            else if (columnName.Contains("Description"))
            {
                result += "\n" + @"            allowFiltering: false,";
                result += "\n" + @"            editorWith: ""dxTextArea"",";
                result += "\n" + @"            editorOptions: { height: 180 },";
                result += "\n" + @"            formItem: { colSpan: 2 },";
            }
            else if (columnName.EndsWith("JsonData"))
            {
                result += "\n" + @"            visible: false,";
                result += "\n" + @"            formItem: { visible: false },";
            }
            else if (da.EnumConfigs.Count(o => o.TableName == tableName && o.ColumnName == columnName) > 0)
            {
                var __co = da.EnumConfigs.First(o => o.TableName == tableName && o.ColumnName == columnName);
                result += "\n" + @"            lookup: {";
                result += "\n" + @"                dataSource: _selectedEDS2(_options, """ + columnName + @"""),";
                result += "\n" + @"                valueExpr: 'IID',";
                result += "\n" + @"                displayExpr: 'TitValue',";
                result += "\n" + @"            },";
            }
            if (da.ClientConfigs.Count(o => o.TableName == tableName && o.ColumnName == columnName) > 0)
            {
                var __co = da.ClientConfigs.First(o => o.TableName == tableName && o.ColumnName == columnName);
                if (__co.FTableName == "dxDetailLink")
                {
                    result += "\n" + @"            cellTemplate: function (container, options) {";
                    result += "\n" + @"                $('<a/>').text(options.data." + columnName + @")";
                    result += "\n" + @"                    .on('dxclick', function () {";
                    result += "\n" + @"                        window.open(vDir + '/#VIEWNAME/Edit?id=' + options.data." + __co.FValueColumnName + @", '_blank');";
                    result += "\n" + @"                    }).appendTo(container);";
                    result += "\n" + @"            },";
                }
                if (__co.FTableName == "dxTextArea")
                {
                    result += "\n" + @"            allowFiltering: false,";
                    result += "\n" + @"            editorWith: ""dxTextArea"",";
                    result += "\n" + @"            editorOptions: { height: 180 },";
                    result += "\n" + @"            formItem: { colSpan: 2 },";
                }
                if (__co.FTableName == "dxHtmlEditor")
                {
                    result += "\n" + @"            allowFiltering: false,";
                    result += "\n" + @"            editorWith: ""dxHtmlEditor"",";
                    result += "\n" + @"            //editorOptions: { height: 180 },";
                    result += "\n" + @"            formItem: { colSpan: 2 },";
                }
                //dataType: "date",
                //editorType: "dxDateBox",
            }

            return result;
        }
        public string setField(string tableName, string columnName)
        {
            string result = "";
            //editorOptions: { disabled: true }
            if ((columnName == "IsDelete") || (columnName == "Visible") || (columnName.EndsWith("JsonData")))
            {
                result += "\n" + @"            visible: false,";
            }
            if (columnName == "Title")
            {
                result += "\n" + @"            validationRules: [";
                result += "\n" + @"            { type: 'required', message: 'Không được để trống' },";
                result += "\n" + @"            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },";
                result += "\n" + @"            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }";
                result += "\n" + @"            ],";
            }
            else if (columnName.Contains("Description"))
            {
                result += "\n" + @"            editorType: ""dxTextArea"",";
                result += "\n" + @"            editorOptions: { height: 120 },";
                result += "\n" + @"            colSpan: cols,";
            }
            else if (da.EnumConfigs.Count(o => o.TableName == tableName && o.ColumnName == columnName) > 0)
            {
                var __co = da.EnumConfigs.First(o => o.TableName == tableName && o.ColumnName == columnName);
                result += "\n" + @"            editorType: ""dxSelectBox"",";
                result += "\n" + @"            editorOptions: {";
                result += "\n" + @"                onValueChanged: function (data) {";
                result += "\n" + @"                    doEvent(""dxSelectBox.onValueChanged"");";
                result += "\n" + @"                },";
                result += "\n" + @"                searchEnabled: true,";
                result += "\n" + @"                dataSource: _selectedEDS2(_options, """ + columnName + @"""),";
                result += "\n" + @"                valueExpr: 'IID',";
                result += "\n" + @"                displayExpr: 'TitValue',";
                result += "\n" + @"            },";
            }
            if (da.ClientConfigs.Count(o => o.TableName == tableName && o.ColumnName == columnName) > 0)
            {
                var __co = da.ClientConfigs.First(o => o.TableName == tableName && o.ColumnName == columnName);
                if (__co.FTableName == "dxImageEditor")
                {
                    result += "\n" + @"            template: function (data, element) {";
                    result += "\n" + @"                var _img = $('<img/>').attr('height', 100).attr('src', data.editorOptions.value).appendTo(element);";
                    result += "\n" + @"                $(_img).froalaEditor({";
                    result += "\n" + @"                    imageUploadURL: vDir + '/Home/UploadImageResize',";
                    result += "\n" + @"                    fileUploadURL: vDir + '/Home/UploadFile',";
                    result += "\n" + @"                    imageManagerLoadURL: vDir + '/Home/LoadImages',";
                    result += "\n" + @"                    imageManagerDeleteURL: vDir + '/Home/DeleteImage',";
                    result += "\n" + @"                    imageManagerDeleteMethod: 'POST',";
                    result += "\n" + @"                }).on('froalaEditor.contentChanged', function (obj, editor) {";
                    result += "\n" + @"                    $(""#form" + tableName + @""").dxForm(""instance"")._options.formData." + columnName + @" = $(editor.html.get()).attr('src');";
                    result += "\n" + @"                });";
                    result += "\n" + @"            }";
                }
                if (__co.FTableName == "dxHtmlEditor")
                {
                    result += "\n" + @"            template: function (data, element) {";
                    result += "\n" + @"                var $editor = $('<textarea/>').attr('height', 100).text(data.editorOptions.value).appendTo(element);";
                    result += "\n" + @"                $editor.froalaEditor({";
                    result += "\n" + @"                    toolbarButtons: ['bold', 'italic', 'underline', '|', 'fontFamily', 'fontSize', 'outdent', 'indent', 'clearFormatting', '|', 'insertImage', 'insertTable', 'html'],";
                    result += "\n" + @"                    charCounterCount: false,";
                    result += "\n" + @"                    imageUploadURL: vDir + '/Home/UploadImageResize',";
                    result += "\n" + @"                    fileUploadURL: vDir + '/Home/UploadFile',";
                    result += "\n" + @"                    imageManagerLoadURL: vDir + '/Home/LoadImages',";
                    result += "\n" + @"                    imageManagerDeleteURL: vDir + '/Home/DeleteImage',";
                    result += "\n" + @"                    imageManagerDeleteMethod: 'POST',";
                    result += "\n" + @"                //}).on('froalaEditor.image.removed', function (e, editor, $img) { froalaEditor_image_removed(e, editor, $img);";
                    result += "\n" + @"                //}).on('froalaEditor.file.unlink', function (e, editor, link) { froalaEditor_file_unlink(e, editor, link);";
                    result += "\n" + @"                }).on('froalaEditor.contentChanged', function (obj, editor) {";
                    result += "\n" + @"                    $(""#form" + tableName + @""").dxForm(""instance"")._options.formData." + columnName + @" = editor.html.get();";
                    result += "\n" + @"                }).on('froalaEditor.commands.after', function (e, editor, cmd, param1, param2) {";
                    result += "\n" + @"                    if (cmd == 'html') { }";
                    result += "\n" + @"                });";
                    result += "\n" + @"            }";
                }
            }

            return result;
        }
        public string setInitEDS(string tableInObj, string viewName)
        {
            int count = 0;
            count = da.EnumConfigs.Where(o => o.TableName == tableInObj).Count();
            if (tableInObj.IndexOf(",") > 0)
            {
                List<string> __l = tableInObj.Split(new char[] { ',' }).ToList();
                count = da.EnumConfigs.Where(o => __l.Contains(o.TableName)).Count();
            }
            string result = "";
            if (count > 0)
            {
                result += "\n" + @"var _options = {}; var ctrl = {};";
                result += "\n" + @"ctrl.initEDS = function (callback) {";
                result += "\n" + @"    $.ajax({";
                result += "\n" + @"        url: vDir + ""/api/EnumRecords/?EID=0&isList=true&theString=" + tableInObj + @""",";
                result += "\n" + @"        data: {take: 1001},";
                result += "\n" + @"        success: function (result) {";
                result += "\n" + @"            _options = result;";
                result += "\n" + @"            callback();";
                result += "\n" + @"        },";
                result += "\n" + @"        error: function () {";
                result += "\n" + @"        },";
                result += "\n" + @"        timeout: 5000";
                result += "\n" + @"    });";
                result += "\n" + @"}";
            }
            else
            {
                result += "\n" + @"var ctrl = {}";
            }
            return result;
        }
        public string setInitEDSForm(string tableInObj, string tableName, string viewName)
        {
            int count = 0;
            count = da.EnumConfigs.Where(o => o.TableName == tableInObj).Count();
            if (tableName.StartsWith("DO"))
            {
                if (tableInObj.IndexOf(",") > 0)
                {
                    List<string> __l = tableInObj.Split(new char[] { ',' }).ToList();
                    count = da.EnumConfigs.Where(o => __l.Contains(o.TableName)).Count();
                }
            }
            string result = "";
            if (count > 0)
            {
                result += "\n" + @"<script>";
                result += "\n" + @"var _options = {};";
                result += "\n" + @"var _data = @Html.Raw(ViewBag." + tableName + @");";
                result += "\n" + @"$(function () {";
                result += "\n" + @"    $.ajax({";
                result += "\n" + @"        url: vDir + ""/api/EnumRecords/?EID=0&isList=true&theString=" + tableInObj + @""",";
                result += "\n" + @"        data: {take: 1001},";
                result += "\n" + @"        success: function (result) {";
                result += "\n" + @"            _options = result;";
                result += "\n" + @"            _" + tableName.ToLower() + @"_form(_data, 2, true)";
                result += "\n" + @"        },";
                result += "\n" + @"        error: function () {";
                result += "\n" + @"        },";
                result += "\n" + @"        timeout: 5000";
                result += "\n" + @"    });";
                result += "\n" + @"})";
                result += "\n" + @"</script>";
            }
            else
            {
                result += "\n" + @"<script>";
                result += "\n" + @"var _options = {};";
                result += "\n" + @"var _data = @Html.Raw(ViewBag." + tableName + @");";
                result += "\n" + @"$(function () {";
                result += "\n" + @"            _" + tableName.ToLower() + @"_form(_data, 2, true)";
                result += "\n" + @"})";
                result += "\n" + @"</script>";
            }
            return result;
        }
    }
}