﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImageMagick;
using System.Configuration;

namespace UTECHTWO.Controllers
{
    public class HomeController : Controller
    {
        string uploadPath
        {
            get { return UploadFolder(); }
        }
        string fileRoute
        {
            get { return UploadFolder(); }
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            Helpers.DataHelpers _helpers = new Helpers.DataHelpers();
            //_helpers.KhoKhach();
            return View();
        }

        public ActionResult Error()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult UploadImage()
        {
            try
            {
                return Json(FroalaEditor.Image.Upload(System.Web.HttpContext.Current, uploadPath));
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public ActionResult UploadFile()
        {
            try
            {
                return Json(FroalaEditor.File.Upload(System.Web.HttpContext.Current, uploadPath));
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public ActionResult LoadImages()
        {
            try
            {
                return Json(FroalaEditor.Image.List(uploadPath), JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public ActionResult UploadImageResize()
        {
            MagickGeometry resizeGeometry = new MagickGeometry(300, 300);
            resizeGeometry.IgnoreAspectRatio = true;

            FroalaEditor.ImageOptions options = new FroalaEditor.ImageOptions
            {
                ResizeGeometry = resizeGeometry
            };

            try
            {
                return Json(FroalaEditor.Image.Upload(System.Web.HttpContext.Current, fileRoute, options));
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public ActionResult UploadImageValidation()
        {
            Func<string, string, bool> validationFunction = (filePath, mimeType) => {

                MagickImageInfo info = new MagickImageInfo(filePath);

                if (info.Width != info.Height)
                {
                    return false;
                }

                return true;
            };

            FroalaEditor.ImageOptions options = new FroalaEditor.ImageOptions
            {
                Fieldname = "myImage",
                Validation = new FroalaEditor.ImageValidation(validationFunction)
            };

            try
            {
                return Json(FroalaEditor.Image.Upload(System.Web.HttpContext.Current, fileRoute, options));
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public ActionResult UploadFileValidation()
        {
            Func<string, string, bool> validationFunction = (filePath, mimeType) => {

                long size = new System.IO.FileInfo(filePath).Length;
                if (size > 10 * 1024 * 1024)
                {
                    return false;
                }

                return true;
            };

            FroalaEditor.FileOptions options = new FroalaEditor.FileOptions
            {
                Fieldname = "myFile",
                Validation = new FroalaEditor.FileValidation(validationFunction)
            };

            try
            {
                return Json(FroalaEditor.Image.Upload(System.Web.HttpContext.Current, fileRoute, options));
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public ActionResult DeleteFile()
        {
            try
            {
                FroalaEditor.File.Delete(HttpContext.Request.Form["src"]);
                return Json(true);
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public ActionResult DeleteImage()
        {
            try
            {
                FroalaEditor.Image.Delete(fileRoute + HttpContext.Request.Form["src"]);
                return Json(true);
            }
            catch (Exception e)
            {
                return Json(e);
            }
        }

        public object S3Signature()
        {
            FroalaEditor.S3Config config = new FroalaEditor.S3Config
            {
                Bucket = Environment.GetEnvironmentVariable("AWS_BUCKET"),
                Region = Environment.GetEnvironmentVariable("AWS_REGION"),
                KeyStart = Environment.GetEnvironmentVariable("AWS_KEY_START"),
                Acl = Environment.GetEnvironmentVariable("AWS_ACL"),
                AccessKey = Environment.GetEnvironmentVariable("AWS_ACCESS_KEY"),
                SecretKey = Environment.GetEnvironmentVariable("AWS_SECRET_KEY")
            };

            return Json(FroalaEditor.S3.GetHash(config), JsonRequestBehavior.AllowGet);
        }

        public string UploadFolder()
        {
            string uploadFolder = ConfigurationManager.AppSettings["UploadFolder"];
            string result = uploadFolder;
            string strRef = HttpContext.Request.UrlReferrer.ToString();
            if (strRef.Contains("IPMNewss_Tb")) result = uploadFolder + "News/";
            else if (strRef.Contains("IPMArticles_Tb")) result = uploadFolder + "CoverArt/";
            return result;
        }

        public ActionResult generateCaptcha()
        {
            System.Drawing.FontFamily family = new System.Drawing.FontFamily("Arial");
            CaptchaImage img = new CaptchaImage(130, 30, family);
            string text = img.CreateRandomText(5);
            img.SetText(text);
            img.GenerateImage();
            img.Image.Save(Server.MapPath("~/Content/captcha/") + this.Session.SessionID.ToString() + ".png", System.Drawing.Imaging.ImageFormat.Png);
            Session["captchaText"] = text;
            return Json("/Content/captcha/" + this.Session.SessionID.ToString() + ".png?t=" + DateTime.Now.Ticks, JsonRequestBehavior.AllowGet);
        }
    }
}