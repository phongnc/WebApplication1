﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UTECHTWO.Controllers
{
    public class GraphsController : Controller
    {

        public ActionResult Flot()
        {
            return View();
        }

        public ActionResult Morris()
        {
            return View();
        }

        public ActionResult Rickshaw()
        {
            return View();
        }

        public ActionResult Chartjs()
        {
            return View();
        }
        public ActionResult Chartist()
        {
            return View();
        }
        public ActionResult Peity()
        {
            return View();
        }

        public ActionResult Sparkline()
        {
            return View();
        }

        public ActionResult C3charts()
        {
            return View();
        }
    }
}