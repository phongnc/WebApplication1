﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using System.Data;
using UTECHTWO.Models.EF;

namespace UTECHTWO.Controllers
{
    public class EObject
    {
        public string StringValue = "";
        public string TitValue = "";
        public string ICD = "";
        public int IID = 0;
        public int PID = 0;
    }
    public class UploadsController : Controller
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public int IntParse(string str)
        {
            try
            {
                float x = float.Parse(str);
                return (int)Math.Round(x);
            }
            catch { }
            return 0;
        }
        public IQueryable<Models.DO.EObject> GetEnumRecords(int EID, bool isList, string theString)
        {
            //if (EIDs.Length == 0) try { EIDs = Newtonsoft.Json.JsonConvert.DeserializeObject<int[]>(theString); } catch { }
            List<Models.DO.EObject> result = new List<Models.DO.EObject>();
            switch (theString)
            {
                case "BanHang":
                    var x11 = db.KhachHangs.MorphRange("", null, "KhachHangID,TenKhachHang").ToList();
                    for (int i = 0; i < x11.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhachHangID",
                            IID = x11[i].KhachHangID,
                            TitValue = x11[i].TenKhachHang
                        });
                    }
                    var x12 = db.GiaiDoans.MorphRange("", null, "GiaiDoanID,MaGiaiDoan").ToList();
                    for (int i = 0; i < x12.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "GiaiDoanID",
                            IID = x12[i].GiaiDoanID,
                            TitValue = x12[i].MaGiaiDoan
                        });
                    }
                    break;
                case "BaoGia":
                    var x21 = db.BanHangs.MorphRange("", null, "BanHangID,Title").ToList();
                    for (int i = 0; i < x21.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "BanHangID",
                            IID = x21[i].BanHangID,
                            TitValue = x21[i].Title
                        });
                    }
                    break;
                case "BaoGiaSP":
                    var x22 = db.BaoGias.MorphRange("", null, "BaoGiaID,MaBaoGia").ToList();
                    for (int i = 0; i < x22.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "BaoGiaID",
                            IID = x22[i].BaoGiaID,
                            TitValue = x22[i].MaBaoGia
                        });
                    }
                    var x23 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x23.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x23[i].SanPhamID,
                            TitValue = x23[i].TenSanPham
                        });
                    }
                    break;
                case "DoanhThu":
                    var x13 = db.DonHangSPs.MorphRange("", null, "DonHangSPID,SanPhamID").ToList();
                    for (int i = 0; i < x13.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "DonHangSPID",
                            IID = x13[i].DonHangSPID,
                            TitValue = x13[i].SanPhamID.ToString()
                        });
                    }
                    break;
                case "DonHang":
                    var x24 = db.BanHangs.MorphRange("", null, "BanHangID,Title").ToList();
                    for (int i = 0; i < x24.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "BanHangID",
                            IID = x24[i].BanHangID,
                            TitValue = x24[i].Title
                        });
                    }
                    break;
                case "DonHangSP":
                    var x25 = db.BaoGias.MorphRange("", null, "BaoGiaID,MaBaoGia").ToList();
                    for (int i = 0; i < x25.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "BaoGiaID",
                            IID = x25[i].BaoGiaID,
                            TitValue = x25[i].MaBaoGia
                        });
                    }
                    var x26 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x26.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x26[i].SanPhamID,
                            TitValue = x26[i].TenSanPham
                        });
                    }
                    break;
                case "DuBao":
                    var x14 = db.KhachHangs.MorphRange("", null, "KhachHangID,TenKhachHang").ToList();
                    for (int i = 0; i < x14.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhachHangID",
                            IID = x14[i].KhachHangID,
                            TitValue = x14[i].TenKhachHang
                        });
                    }
                    var x15 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x15.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x15[i].SanPhamID,
                            TitValue = x15[i].TenSanPham
                        });
                    }
                    var x16 = db.GiaiDoans.MorphRange("", null, "GiaiDoanID,MaGiaiDoan").ToList();
                    for (int i = 0; i < x16.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "GiaiDoanID",
                            IID = x16[i].GiaiDoanID,
                            TitValue = x16[i].MaGiaiDoan
                        });
                    }
                    break;
                case "KhoKhach":
                    var x17 = db.KhachHangs.MorphRange("", null, "KhachHangID,TenKhachHang").ToList();
                    for (int i = 0; i < x17.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhachHangID",
                            IID = x17[i].KhachHangID,
                            TitValue = x17[i].TenKhachHang
                        });
                    }
                    var x18 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x18.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x18[i].SanPhamID,
                            TitValue = x18[i].TenSanPham
                        });
                    }
                    break;
                case "NhapHang":
                    var x31 = db.Khoes.MorphRange("", null, "KhoID,TenKho").ToList();
                    for (int i = 0; i < x31.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhoID",
                            IID = x31[i].KhoID,
                            TitValue = x31[i].TenKho
                        });
                    }
                    var x32 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x31.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x32[i].SanPhamID,
                            TitValue = x32[i].TenSanPham
                        });
                    }
                    var x33 = db.NhaCungCaps.MorphRange("", null, "NhaCungCapID,TenNhaCungCap").ToList();
                    for (int i = 0; i < x31.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "NhaCungCapID",
                            IID = x33[i].NhaCungCapID,
                            TitValue = x33[i].TenNhaCungCap
                        });
                    }
                    break;
                case "XuatHang":
                    var x34 = db.DonHangSPs.MorphRange("", null, "DonHangSPID,SanPhamID").ToList();
                    for (int i = 0; i < x34.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "DonHangSPID",
                            IID = x34[i].DonHangSPID,
                            TitValue = x34[i].SanPhamID.ToString()
                        });
                    }
                    var x35 = db.NhapHangs.MorphRange("", null, "NhapHangID,MaLoHang").ToList();
                    for (int i = 0; i < x35.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "NhapHangID",
                            IID = x35[i].NhapHangID,
                            TitValue = x35[i].MaLoHang
                        });
                    }
                    break;
            }
            return result.AsQueryable();
        }
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult SaleItems()
        {
            //var x = GetEnumRecords(0, true, "SaleItem");
            string result = "";
            var files = Request.Files;
            for (int i = 0; i < files.Count; i++)
            {
                if (Path.GetExtension(files[i].FileName) == ".xlsx")
                {
                    using (var excel = new ExcelPackage(files[i].InputStream))
                    {
                        var ws = excel.Workbook.Worksheets.First();
                        var hasHeader = true;
                        //foreach (var firstRowCell in ws.Cells[1, 1, 1, ws.Dimension.End.Column])
                        //    tbl.Columns.Add(hasHeader ? firstRowCell.Text : String.Format("Column {0}", firstRowCell.Start.Column));
                        int startRow = hasHeader ? 3 : 1;
                        int successRow = 0;
                        int failRow = 0;
                        int _giaidoanID = 3;
                        List<Models.EF.DuBao> rowDBs = new List<DuBao>();
                        List<Models.EF.BaoGiaSP> rowBGs = new List<BaoGiaSP>();
                        List<Models.EF.DonHangSP> rowDHs = new List<DonHangSP>();
                        for (int rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
                        {
                            int colNum = 0;
                            int _khachhangID = 0;
                            int _sanphamID = 0;
                            int _banhangID = 0;
                            int _baogiaID = 0;
                            int _donhangID = 0;
                            string strDonVi = "";
                            colNum += 1;
                            try { _khachhangID = db.KhachHangs.Select("LOWER(TenKhachHang) = @TenKhachHang", new { TenKhachHang = ws.Cells[rowNum, colNum].Text.ToLower().Trim() }).KhachHangID; } catch { _khachhangID = 0; }
                            //if (_khachhangID == 0)
                            //{
                            //    var _khachhang = db.KhachHangs.Add(new KhachHang()
                            //    {
                            //        TenKhachHang = ws.Cells[rowNum, colNum].Text.Trim(),
                            //        MaKhachHang = Trim(ws.Cells[rowNum, colNum].Text.Trim().Replace(" ", "").ToUpper(), 50),
                            //        MST = "",
                            //        DiaChi = "",
                            //        IsDelete = false,
                            //    });
                            //    _khachhangID = _khachhang.KhachHangID;
                            //    var _banhang = db.BanHangs.Add(new BanHang()
                            //    {
                            //        GiaiDoanID = _giaidoanID,
                            //        KhachHangID = _khachhangID,
                            //        DienGiai = "PO: T3/2018",
                            //        LoaiChietKhau = "PO: T3/2018",
                            //        LoaiDonHang = 1,
                            //        NguoiDatHang = "Khach Hang",
                            //        MaBoPhan = "5NVDUNG1",
                            //        TyGia = "1000",
                            //        Title = _khachhangID.ToString() + "PO: T3/2018",
                            //        IsDelete = false,
                            //    });
                            //    _banhangID = _banhang.BanHangID;
                            //    var _baogia = db.BaoGias.Add(new BaoGia()
                            //    {
                            //        BanHangID = _banhangID,
                            //        MaBaoGia = "20181003_" + _banhangID.ToString(),
                            //        NgayBaoGia = DateTime.Now.AddMonths(-1),
                            //        LanSuaDoi = 1,
                            //        TrangThai = 5,
                            //        CreatedDate = DateTime.Now,
                            //        CreatedUID = 1,
                            //        ModifiedDate = DateTime.Now,
                            //        ModifiedUID = 1,
                            //        IsDelete = false,
                            //    });
                            //    _baogiaID = _baogia.BaoGiaID;
                            //    var _donhang = db.DonHangs.Add(new DonHang()
                            //    {
                            //        BanHangID = _banhangID,
                            //        MaDonHang = "20181003_" + _banhangID.ToString(),
                            //        NgayDonHang = DateTime.Now.AddMonths(-1),
                            //        LanSuaDoi = 1,
                            //        TrangThai = 5,
                            //        CreatedDate = DateTime.Now,
                            //        CreatedUID = 1,
                            //        ModifiedDate = DateTime.Now,
                            //        ModifiedUID = 1,
                            //        IsDelete = false,
                            //    });
                            //    _donhangID = _donhang.DonHangID;
                            //}
                            //else
                            //{
                            //    try { _banhangID = db.BanHangs.Select("KhachHangID = @KhachHangID", new { KhachHangID = _khachhangID }).BanHangID; } catch { _banhangID = 0; }
                            //    try { _baogiaID = db.BaoGias.Select("BanHangID = @BanHangID", new { BanHangID = _banhangID }).BaoGiaID; } catch { _baogiaID = 0; }
                            //    try { _donhangID = db.DonHangs.Select("BanHangID = @BanHangID", new { BanHangID = _banhangID }).DonHangID; } catch { _donhangID = 0; }
                            //}
                            colNum += 1;
                            colNum += 1;
                            string strTenSanPham = ""; try { strTenSanPham = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            colNum += 1; try { strDonVi = ws.Cells[rowNum, colNum].Text; } catch { strDonVi = ""; }
                            try { _sanphamID = db.SanPhams.Select("LOWER(TenSanPham) = @TenSanPham", new { TenSanPham = strTenSanPham.ToLower() }).SanPhamID; } catch { _sanphamID = 0; }
                            if (_sanphamID == 0)
                            {
                                var _sanpham = db.SanPhams.Add(new SanPham()
                                {
                                    TenSanPham = strTenSanPham,
                                    MaSanPham = Trim(strTenSanPham.Replace(" ", "").ToUpper(), 50),
                                    DonVi = strDonVi,
                                    IsDelete = false,
                                    SanPhamMD = 0,
                                });
                                _sanphamID = _sanpham.SanPhamID;
                                db.SPInfoes.Add(new SPInfo()
                                {
                                    SanPhamID =_sanphamID,
                                    TenSanXuat = strTenSanPham,
                                    ChungLoaiVoChua = "",
                                    KhoiLuongDungLuong = "",
                                    NhaCungCapID = 1,
                                    NongDoMauSac = "",
                                    PhanPhoiSanXuat = "",
                                    SanLuong = "",
                                    JsonData = "",
                                    GhiChu = ""
                                });
                                db.SPImages.Add(new SPImage()
                                {
                                    SanPhamID = _sanphamID,
                                });
                            }
                            //Models.EF.DuBao rowDB = new DuBao()
                            //{
                            //    GiaiDoanID = _giaidoanID,
                            //    KhachHangID = _khachhangID,
                            //    SanPhamID = _sanphamID,
                            //    TrangThai = 1,
                            //    CreatedDate = DateTime.Now,
                            //    CreatedUID = 1,
                            //    ModifiedDate = DateTime.Now,
                            //    ModifiedUID = 1,
                            //    IsDelete = false,
                            //};
                            //Models.EF.BaoGiaSP rowBG = new BaoGiaSP()
                            //{
                            //    BaoGiaID = _baogiaID,
                            //    SanPhamID = _sanphamID,
                            //    TrangThai = 1,
                            //    IsDelete = false,
                            //};
                            //Models.EF.DonHangSP rowDH = new DonHangSP()
                            //{
                            //    DonHangID = _baogiaID,
                            //    SanPhamID = _sanphamID,
                            //    TrangThai = 1,
                            //    IsDelete = false,
                            //};
                            //Models.EF.DoanhThu rowDT = new DoanhThu();
                            //colNum += 1; try { rowBG.DonGia = IntParse(ws.Cells[rowNum, colNum].Text); } catch { rowBG.DonGia = 0; }
                            //rowDH.DonGia = rowBG.DonGia;
                            //colNum += 1; try { rowDB.SoLuong = IntParse(ws.Cells[rowNum, colNum].Text); } catch { rowDB.SoLuong = 0; }
                            //rowDB.DonGia = rowDH.DonGia;
                            //colNum += 1; //try { rowDB.DoanhThuDuBao = IntParse(ws.Cells[rowNum, colNum].Text); } catch { rowBG.DoanhThuDuBao = 0; }
                            //colNum += 1; try { rowBG.SoLuong = IntParse(ws.Cells[rowNum, colNum].Text); } catch { rowBG.SoLuong = 0; }
                            //rowDH.SoLuong = rowBG.SoLuong;
                            //colNum += 1; try { rowDT.DoanhThuDuKien = IntParse(ws.Cells[rowNum, colNum].Text); } catch { rowDT.DoanhThuDuKien = 0; }
                            //colNum += 1; try { rowDT.DoanhThuHoaDon = IntParse(ws.Cells[rowNum, colNum].Text); } catch { rowDT.DoanhThuHoaDon = 0; }
                            //colNum += 1; try { rowDT.DoanhThuThucTe = IntParse(ws.Cells[rowNum, colNum].Text); } catch { rowDT.DoanhThuThucTe = 0; }
                            //colNum += 1; try { rowDT.GhiChu = ws.Cells[rowNum, colNum].Text; } catch { rowDT.GhiChu = ""; }
                            //if (_donhangID > 0)
                            //{
                            //    rowDB = db.DuBaos.Add(rowDB);
                            //    rowBG = db.BaoGiaSPs.Add(rowBG);
                            //    rowDH = db.DonHangSPs.Add(rowDH);
                            //    rowDT.DonHangSPID = rowDH.DonHangSPID;
                            //    rowDT = db.DoanhThus.Add(rowDT);
                            //    successRow++;
                            //}
                            //else failRow++;
                        }
                        result = String.Format("DataTable successfully created from excel-file. Success:{0} Fail:{1}", successRow, failRow);
                    }
                }
                else
                {
                    result = "You did not specify a correct file to upload.";
                }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult ProductItems()
        {
            string result = "";
            var files = Request.Files;
            int _MD = 3;
            for (int i = 0; i < files.Count; i++)
            {
                if (Path.GetExtension(files[i].FileName) == ".xlsx")
                {
                    using (var excel = new ExcelPackage(files[i].InputStream))
                    {
                        var ws = excel.Workbook.Worksheets.First();
                        var hasHeader = true;
                        //foreach (var firstRowCell in ws.Cells[1, 1, 1, ws.Dimension.End.Column])
                        //    tbl.Columns.Add(hasHeader ? firstRowCell.Text : String.Format("Column {0}", firstRowCell.Start.Column));
                        int startRow = hasHeader ? 3 : 1;
                        int successRow = 0;
                        int failRow = 0;
                        var _xxx = ws.Drawings;
                        //List<Models.EF.CosoTruong> rows = new List<CosoTruong>();
                        for (int rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
                        {
                            string strText = "";
                            int intSTT = 0;
                            SanPham _sp = new SanPham(); _sp.SanPhamMD = _MD;
                            SPInfo _if = new SPInfo();
                            SPImage _im = new SPImage();
                            int colNum = 0;
                            colNum += 1; try { intSTT = int.Parse(ws.Cells[rowNum, colNum].Text); } catch { intSTT = 0; }
                            if (intSTT == 0) continue;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _sp.MaSanPham = strText;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _sp.TenSanPham = strText;
                            int _sanphamID = 0;
                            try { _sanphamID = db.SanPhams.Select("LOWER(TenSanPham) = @TenSanPham", new { TenSanPham = _sp.TenSanPham.ToLower() }).SanPhamID; } catch { _sanphamID = 0; }
                            if (_sanphamID > 0) continue;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _if.TenSanXuat = strText;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _if.NongDoMauSac = strText;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _sp.DonVi = strText;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _if.KhoiLuongDungLuong = strText;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _if.ChungLoaiVoChua = strText;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            try
                            {
                                _if.NhaCungCapID = db.NhaCungCaps.Select("TenNhaCungCap = @TenNhaCungCap", new { TenNhaCungCap = new Dapper.DbString() { Value = strText.ToUpper(), IsAnsi = false, Length = 150 } }).NhaCungCapID;
                            }
                            catch
                            {
                                try
                                {
                                    var x = db.NhaCungCaps.Add(new NhaCungCap()
                                    {
                                        TenNhaCungCap = strText.ToUpper(),
                                        MaNhaCungCap = strText.Replace(" ", "").ToUpper(),
                                        DiaChi = "",
                                        MST = "",
                                        IsDelete = false
                                    });
                                    _if.NhaCungCapID = x.NhaCungCapID;
                                }
                                catch { }
                            }
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            _if.SanLuong = strText;
                            colNum += 1; try { strText = ws.Cells[rowNum, colNum].Text.Trim(); } catch { }
                            try
                            {
                                _if.JsonData = strText.ToUpper().Replace("C.TY", "CÔNG TY");
                            }
                            catch { }
                            _sp = db.SanPhams.Add(_sp);
                            _if.SanPhamID = _sp.SanPhamID;
                            _im.SanPhamID = _sp.SanPhamID;
                            var _xxx_ = _xxx.OrderBy(o => o.From.Column).Where(o => o.From.Row == rowNum - 1).ToList();
                            for (int _xxi_ = 0; _xxi_ < _xxx_.Count; _xxi_++)
                            {
                                string _imgName = Guid.NewGuid().ToString() + ".jpg";
                                string _f1 = _imgName.Substring(0, 1);
                                string _f2 = _imgName.Substring(1, 2);
                                string _imgFolder = Server.MapPath("~/Content/uploads/" + _f1 + "/" + _f2 + "/");
                                string _imgPath = "/Content/uploads/" + _f1 + "/" + _f2 + "/" + _imgName;
                                if (!Directory.Exists(_imgFolder)) Directory.CreateDirectory(_imgFolder);
                                try
                                {
                                    ((ExcelPicture)_xxx_[_xxi_]).Image.Save(_imgFolder + _imgName);
                                    switch (_xxx_[_xxi_].From.Column)
                                    {
                                        case 11: _im.MatTruoc = _imgPath; break;
                                        case 12: _im.MatSau = _imgPath; break;
                                        case 13: _im.MatTren = _imgPath; break;
                                        case 14: _im.DongGoi1 = _imgPath; break;
                                        case 15: _im.DongGoi2 = _imgPath; break;
                                        case 16: _im.AnhKhac = _imgPath; break;
                                    }
                                }
                                catch { }
                            }
                            db.SPInfoes.Add(_if);
                            db.SPImages.Add(_im);
                            if (_sp.MaSanPham.Contains("\n"))
                            {
                                string[] _mas = _sp.MaSanPham.Split(new string[] { "\n" }, StringSplitOptions.None);
                                string[] _tens = _sp.TenSanPham.Split(new string[] { "\n" }, StringSplitOptions.None);
                                _sp.MaSanPham = _mas[0];
                                _sp.TenSanPham = _tens[0];
                                db.SanPhams.Update(_sp);
                                try
                                {
                                    for (int _xxi_ = 1; _xxi_ < _mas.Length; _xxi_++)
                                    {
                                        try
                                        {
                                            _sp.SanPhamID = 0;
                                            _sp.MaSanPham = _mas[_xxi_];
                                            _sp.TenSanPham = _tens[_xxi_];
                                            _sp = db.SanPhams.Add(_sp);
                                            _if.SPInfoID = 0;
                                            _if.SanPhamID = _sp.SanPhamID;
                                            _im.SPImageID = 0;
                                            _im.SanPhamID = _sp.SanPhamID;
                                            db.SPInfoes.Add(_if);
                                            db.SPImages.Add(_im);
                                        }
                                        catch { }
                                    }
                                }
                                catch { }
                            }
                        }
                        result = String.Format("DataTable successfully created from excel-file. Success:{0} Fail:{1}", successRow, failRow);
                    }
                }
                else
                {
                    result = "You did not specify a correct file to upload.";
                }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public string Trim(string inString, int inLength)
        {
            if (inString.Length <= inLength) return inString;
            return inString.Substring(0, inLength);
        }
    }
}