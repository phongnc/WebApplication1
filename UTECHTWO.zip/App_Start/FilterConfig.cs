﻿using System.Web;
using System.Web.Mvc;

namespace UTECHTWO
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            filters.Add(new HandleExecuteAction());
        }
    }
    public class HandleExecuteAction : IActionFilter, IResultFilter
    {
        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var user = new Models.BO.UserRecord();
            string _ActionName = filterContext.ActionDescriptor.ActionName;
            string _ControllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            int httpStatusCode = 200;
            try { user = Helpers.AuthenticationHelpers.CurrentUser(filterContext.HttpContext); if (user == null) user = new Models.BO.UserRecord(); } catch { }
            try {
                if (_ControllerName == "Home") httpStatusCode = 200;
                else if (_ControllerName == "Account")
                {
                    if (_ActionName == "Login") httpStatusCode = 200;
                    else if (_ActionName == "LogOff") httpStatusCode = 200;
                }
                else
                {
                    if (user.UserRecordMD == 1) httpStatusCode = 200;
                }
                //httpStatusCode = new Helpers.AuthorizationHelpers().checkRoles(user.UserRecordID, user.UserRecordMD, user.UserRecordFD, _ActionName, _ControllerName);
            } catch { }
            //
            switch (httpStatusCode)
            {
                case 200: break;
                case 403: filterContext.Result = new RedirectResult("~/Account/Login"); break;
            }
            //throw new System.NotImplementedException();
        }

        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            //throw new System.NotImplementedException();
        }

        public void OnResultExecuting(ResultExecutingContext filterContext)
        {
            //throw new System.NotImplementedException();
        }

        public void OnResultExecuted(ResultExecutedContext filterContext)
        {
            //throw new System.NotImplementedException();
        }
    }
}
