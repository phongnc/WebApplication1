﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Filters;

namespace UTECHTWO
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config.Filters.Add(new HandleExecuteApiAction());
        }
    }
    public class HandleExecuteApiAction : ActionFilterAttribute
    {
        public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext filterContext)
        {
            var user = new Models.BO.UserRecord();
            string _ActionName = filterContext.ActionDescriptor.ActionName;
            string _ControllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            int httpStatusCode = 403;
            try { user = Helpers.AuthenticationHelpers.ClientUser(filterContext.Request); if (user == null) user = new Models.BO.UserRecord(); } catch { }
            try { if (user.UserRecordMD == 1) httpStatusCode = 200; } catch { }
            httpStatusCode = 200;
            switch (httpStatusCode)
            {
                case 200: break;
                case 401: filterContext.Response = filterContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Không tìm thấy yêu cầu"); break;
                case 402: filterContext.Response = filterContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Không tìm thấy yêu cầu"); break;
                case 403: filterContext.Response = filterContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Không tìm thấy yêu cầu"); break;
            }
        }
    }
}
