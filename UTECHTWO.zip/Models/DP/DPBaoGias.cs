﻿
using System.Collections.Generic;
using UTECHTWO.Models.EF;
using Dapper;

namespace UTECHTWO.Models.DP
{
    public class DPBaoGias : DpSet<DO.DOBaoGia>
    {
        public DpSet<BaoGia> UBaoGia { get; set; }
        public DpSet<BanHang> UBanHang { get; set; }
        public DPBaoGias()
        {
            string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Model2"].ToString();
            ConnectionString = _ConnectionString;
            TableName = "BaoGia AS UBaoGia INNER JOIN BanHang AS UBanHang ON UBaoGia.BanHangID = UBanHang.BanHangID";
            IdentityColumn = "UBaoGia.BaoGiaID";
            UBaoGia = new DpSet<BaoGia>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BaoGia",
                IdentityColumn = "BaoGiaID",
                Columns = new List<string>() { "BanHangID","MaBaoGia","NgayBaoGia","LanSuaDoi","TrangThai","CreatedDate","ModifiedDate","CreatedUID","ModifiedUID","IsDelete", }
            };
            UBanHang = new DpSet<BanHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BanHang",
                IdentityColumn = "BanHangID",
                Columns = new List<string>() { "Title","KhachHangID","LoaiDonHang","GiaiDoanID","NguoiDatHang","MaBoPhan","TyGia","LoaiChietKhau","DienGiai","IsDelete", }
            };
        }
        public override DO.DOBaoGia Find(int id)
        {
            DO.DOBaoGia model = new DO.DOBaoGia();
            model.UBaoGia = UBaoGia.Find(id);
            model.UBanHang = UBanHang.Find(model.UBaoGia.BanHangID.Value);
            return model;
        }
        public override DpSelectResult<DO.DOBaoGia> SelectResult(string _orderCondition = "", string _conditionString = "", object keyValues = null)
        {
            DpSelectResult<DO.DOBaoGia> result = new DpSelectResult<DO.DOBaoGia>();
            string _param6 = "UBaoGia.*,UBanHang.*";
            string _param7 = "INNER JOIN BaoGia AS UBaoGia ON T.BaoGiaID = UBaoGia.BaoGiaID INNER JOIN BanHang AS UBanHang ON UBaoGia.BanHangID = UBanHang.BanHangID";
            var multipleResults = DOSelectResult(_param6, _param7, _orderCondition, _conditionString, keyValues);
            result.ResultCount = multipleResults.Read<int>().AsList()[0];
            result.ResultList = multipleResults.Read<EF.BaoGia,EF.BanHang, DO.DOBaoGia>((_UBaoGia,_UBanHang) => { return new DO.DOBaoGia() { UBaoGia = _UBaoGia,UBanHang = _UBanHang }; }, splitOn: "BaoGiaID,BanHangID");
            return result;
        }
        public override DO.DOBaoGia Add(DO.DOBaoGia model)
        {
            model.UBanHang = UBanHang.Add(model.UBanHang);
            model.UBaoGia.BanHangID = model.UBaoGia.BanHangID;
            model.UBaoGia = UBaoGia.Add(model.UBaoGia);
            return model;
        }
        public override DO.DOBaoGia Update(DO.DOBaoGia model)
        {
            model.UBaoGia = UBaoGia.Update(model.UBaoGia);
            model.UBanHang = UBanHang.Update(model.UBanHang);
            return model;
        }
        public override DO.DOBaoGia Remove(DO.DOBaoGia model)
        {
            model.UBaoGia = UBaoGia.Remove(model.UBaoGia);
            model.UBanHang = UBanHang.Remove(model.UBanHang);
            return model;
        }
    };
};
