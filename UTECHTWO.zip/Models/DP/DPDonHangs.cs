﻿
using System.Collections.Generic;
using UTECHTWO.Models.EF;
using Dapper;

namespace UTECHTWO.Models.DP
{
    public class DPDonHangs : DpSet<DO.DODonHang>
    {
        public DpSet<DonHang> UDonHang { get; set; }
        public DpSet<BanHang> UBanHang { get; set; }
        public DPDonHangs()
        {
            string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Model2"].ToString();
            ConnectionString = _ConnectionString;
            TableName = "DonHang AS UDonHang INNER JOIN BanHang AS UBanHang ON UDonHang.BanHangID = UBanHang.BanHangID";
            IdentityColumn = "UDonHang.DonHangID";
            UDonHang = new DpSet<DonHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "DonHang",
                IdentityColumn = "DonHangID",
                Columns = new List<string>() { "BanHangID","MaDonHang","NgayDonHang","LanSuaDoi","TrangThai","CreatedDate","ModifiedDate","CreatedUID","ModifiedUID","IsDelete", }
            };
            UBanHang = new DpSet<BanHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BanHang",
                IdentityColumn = "BanHangID",
                Columns = new List<string>() { "Title","KhachHangID","LoaiDonHang","GiaiDoanID","NguoiDatHang","MaBoPhan","TyGia","LoaiChietKhau","DienGiai","IsDelete", }
            };
        }
        public override DO.DODonHang Find(int id)
        {
            DO.DODonHang model = new DO.DODonHang();
            model.UDonHang = UDonHang.Find(id);
            model.UBanHang = UBanHang.Find(model.UDonHang.BanHangID.Value);
            return model;
        }
        public override DpSelectResult<DO.DODonHang> SelectResult(string _orderCondition = "", string _conditionString = "", object keyValues = null)
        {
            DpSelectResult<DO.DODonHang> result = new DpSelectResult<DO.DODonHang>();
            string _param6 = "UDonHang.*,UBanHang.*";
            string _param7 = "INNER JOIN DonHang AS UDonHang ON T.DonHangID = UDonHang.DonHangID INNER JOIN BanHang AS UBanHang ON UDonHang.BanHangID = UBanHang.BanHangID";
            var multipleResults = DOSelectResult(_param6, _param7, _orderCondition, _conditionString, keyValues);
            result.ResultCount = multipleResults.Read<int>().AsList()[0];
            result.ResultList = multipleResults.Read<EF.DonHang,EF.BanHang, DO.DODonHang>((_UDonHang,_UBanHang) => { return new DO.DODonHang() { UDonHang = _UDonHang,UBanHang = _UBanHang }; }, splitOn: "DonHangID,BanHangID");
            return result;
        }
        public override DO.DODonHang Add(DO.DODonHang model)
        {
            model.UBanHang = UBanHang.Add(model.UBanHang);
            model.UDonHang.BanHangID = model.UDonHang.BanHangID;
            model.UDonHang = UDonHang.Add(model.UDonHang);
            return model;
        }
        public override DO.DODonHang Update(DO.DODonHang model)
        {
            model.UDonHang = UDonHang.Update(model.UDonHang);
            model.UBanHang = UBanHang.Update(model.UBanHang);
            return model;
        }
        public override DO.DODonHang Remove(DO.DODonHang model)
        {
            model.UDonHang = UDonHang.Remove(model.UDonHang);
            model.UBanHang = UBanHang.Remove(model.UBanHang);
            return model;
        }
    };
};
