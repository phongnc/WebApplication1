﻿
using System.Collections.Generic;
using UTECHTWO.Models.EF;

namespace UTECHTWO.Models.DP
{
    public class Model1
    {
        public DpSet<BanHang> BanHangs { get; set; }
        public DpSet<BaoGia> BaoGias { get; set; }
        public DpSet<BaoGiaSP> BaoGiaSPs { get; set; }
        public DpSet<DoanhThu> DoanhThus { get; set; }
        public DpSet<DonHang> DonHangs { get; set; }
        public DpSet<DonHangSP> DonHangSPs { get; set; }
        public DpSet<DuBao> DuBaos { get; set; }
        public DpSet<GiaiDoan> GiaiDoans { get; set; }
        public DpSet<KhachHang> KhachHangs { get; set; }
        public DpSet<Kho> Khoes { get; set; }
        public DpSet<KhoKhach> KhoKhaches { get; set; }
        public DpSet<LoaiSanPham> LoaiSanPhams { get; set; }
        public DpSet<NhaCungCap> NhaCungCaps { get; set; }
        public DpSet<NhapHang> NhapHangs { get; set; }
        public DpSet<SanPham> SanPhams { get; set; }
        public DpSet<SanPhamX> SanPhamXes { get; set; }
        public DpSet<SPImage> SPImages { get; set; }
        public DpSet<SPInfo> SPInfoes { get; set; }
        public DpSet<User> Users { get; set; }
        public DpSet<XuatHang> XuatHangs { get; set; }
        public Model1()
        {
            string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Model1"].ToString();
            BanHangs = new DpSet<BanHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BanHang",
                IdentityColumn = "BanHangID",
                Columns = new List<string>() { "Title","KhachHangID","LoaiDonHang","GiaiDoanID","NguoiDatHang","MaBoPhan","TyGia","LoaiChietKhau","DienGiai","IsDelete", }
            };
            BaoGias = new DpSet<BaoGia>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BaoGia",
                IdentityColumn = "BaoGiaID",
                Columns = new List<string>() { "BanHangID","MaBaoGia","NgayBaoGia","LanSuaDoi","TrangThai","CreatedDate","ModifiedDate","CreatedUID","ModifiedUID","IsDelete", }
            };
            BaoGiaSPs = new DpSet<BaoGiaSP>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BaoGiaSP",
                IdentityColumn = "BaoGiaSPID",
                Columns = new List<string>() { "BaoGiaID","SanPhamID","SoLuong","DonGia","TrangThai","IsDelete", }
            };
            DoanhThus = new DpSet<DoanhThu>()
            {
                ConnectionString = _ConnectionString,
                TableName = "DoanhThu",
                IdentityColumn = "DoanhThuID",
                Columns = new List<string>() { "DonHangSPID","DoanhThuDuKien","DoanhThuHoaDon","DoanhThuThucTe","GhiChu", }
            };
            DonHangs = new DpSet<DonHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "DonHang",
                IdentityColumn = "DonHangID",
                Columns = new List<string>() { "BanHangID","MaDonHang","NgayDonHang","LanSuaDoi","TrangThai","CreatedDate","ModifiedDate","CreatedUID","ModifiedUID","IsDelete", }
            };
            DonHangSPs = new DpSet<DonHangSP>()
            {
                ConnectionString = _ConnectionString,
                TableName = "DonHangSP",
                IdentityColumn = "DonHangSPID",
                Columns = new List<string>() { "DonHangID","SanPhamID","SoLuong","DonGia","TrangThai","IsDelete", }
            };
            DuBaos = new DpSet<DuBao>()
            {
                ConnectionString = _ConnectionString,
                TableName = "DuBao",
                IdentityColumn = "DuBaoID",
                Columns = new List<string>() { "KhachHangID","SanPhamID","GiaiDoanID","SoLuong","DonGia","TrangThai","CreatedDate","ModifiedDate","CreatedUID","ModifiedUID","IsDelete", }
            };
            GiaiDoans = new DpSet<GiaiDoan>()
            {
                ConnectionString = _ConnectionString,
                TableName = "GiaiDoan",
                IdentityColumn = "GiaiDoanID",
                Columns = new List<string>() { "MaGiaiDoan","BatDau","KetThuc", }
            };
            KhachHangs = new DpSet<KhachHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "KhachHang",
                IdentityColumn = "KhachHangID",
                Columns = new List<string>() { "MaKhachHang","TenKhachHang","DiaChi","MST","IsDelete", }
            };
            Khoes = new DpSet<Kho>()
            {
                ConnectionString = _ConnectionString,
                TableName = "Kho",
                IdentityColumn = "KhoID",
                Columns = new List<string>() { "MaKho","TenKho","IsDelete", }
            };
            KhoKhaches = new DpSet<KhoKhach>()
            {
                ConnectionString = _ConnectionString,
                TableName = "KhoKhach",
                IdentityColumn = "KhoKhachID",
                Columns = new List<string>() { "KhachHangID","SanPhamID","SoLuong", }
            };
            LoaiSanPhams = new DpSet<LoaiSanPham>()
            {
                ConnectionString = _ConnectionString,
                TableName = "LoaiSanPham",
                IdentityColumn = "LoaiSanPhamID",
                Columns = new List<string>() { "MaLoaiSanPham","TenLoaiSanPham","IsDelete", }
            };
            NhaCungCaps = new DpSet<NhaCungCap>()
            {
                ConnectionString = _ConnectionString,
                TableName = "NhaCungCap",
                IdentityColumn = "NhaCungCapID",
                Columns = new List<string>() { "MaNhaCungCap","TenNhaCungCap","DiaChi","MST","IsDelete", }
            };
            NhapHangs = new DpSet<NhapHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "NhapHang",
                IdentityColumn = "NhapHangID",
                Columns = new List<string>() { "KhoID","SanPhamID","NhaCungCapID","NhaSanXuat","MaLoHang","SoLuong","TonKho","DonGia","HanSuDung","NgayNhapHang","IsDelete", }
            };
            SanPhams = new DpSet<SanPham>()
            {
                ConnectionString = _ConnectionString,
                TableName = "SanPham",
                IdentityColumn = "SanPhamID",
                Columns = new List<string>() { "SanPhamMD","MaSanPham","TenSanPham","DonVi","IsDelete", }
            };
            SanPhamXes = new DpSet<SanPhamX>()
            {
                ConnectionString = _ConnectionString,
                TableName = "SanPhamX",
                IdentityColumn = "SanPhamID",
                Columns = new List<string>() { "SanPhamMD","MaSanPham","TenSanPham","DonVi","IsDelete", }
            };
            SPImages = new DpSet<SPImage>()
            {
                ConnectionString = _ConnectionString,
                TableName = "SPImage",
                IdentityColumn = "SPImageID",
                Columns = new List<string>() { "SanPhamID","SPImageMoreID","MatTruoc","MatSau","MatTren","DongGoi1","DongGoi2","AnhKhac", }
            };
            SPInfoes = new DpSet<SPInfo>()
            {
                ConnectionString = _ConnectionString,
                TableName = "SPInfo",
                IdentityColumn = "SPInfoID",
                Columns = new List<string>() { "SanPhamID","NhaCungCapID","TenSanXuat","SanLuong","NongDoMauSac","KhoiLuongDungLuong","ChungLoaiVoChua","PhanPhoiSanXuat","GhiChu","JsonData", }
            };
            Users = new DpSet<User>()
            {
                ConnectionString = _ConnectionString,
                TableName = "User",
                IdentityColumn = "UserID",
                Columns = new List<string>() { "Email","Password", }
            };
            XuatHangs = new DpSet<XuatHang>()
            {
                ConnectionString = _ConnectionString,
                TableName = "XuatHang",
                IdentityColumn = "XuatHangID",
                Columns = new List<string>() { "NhapHangID","DonHangSPID","SoLuong", }
            };
        }
    };
};
