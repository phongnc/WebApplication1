﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using Dapper;

namespace UTECHTWO.Models.DP
{
    public class DpSearch<TEntity>
    {
        int _pageSize = 10;
        int _requestPage = 1;
        int _skipRows = 0;
        int _takeRows = 1000;
        public int ResultCount { get; set; }
        public int PageSize { set { _pageSize = value; } }
        public int RequestPage { set { _requestPage = value; } }
        public int SkipRows { set { _skipRows = value; } }
        public int TakeRows { set { _takeRows = value; } }
    }
    public class DpSelectResult<TEntity>
    {
        public IEnumerable<TEntity> ResultList { get; set; }
        public int ResultCount { get; set; }
    }
    public class DpCache<TEntity>
    {
        public virtual List<TEntity> getCaching()
        {
            throw new Exception("getCaching not implement in cache mode");
        }
        public virtual void resetCaching(List<TEntity> value)
        {
            throw new Exception("resetCaching not implement in cache mode");
        }
        public virtual int Count(int id)
        {
            throw new Exception("Count with id not implement in cache mode");
        }
        public virtual int Count(string _conditionString, object keyValues = null)
        {
            throw new Exception("Count with keyValues not implement in cache mode");
        }
        public virtual TEntity Find(int id)
        {
            throw new Exception("Find with id not implement in cache mode");
        }
        public virtual DpSelectResult<TEntity> SelectResult(string _orderCondition = "", string _conditionString = "", object keyValues = null)
        {
            throw new Exception("SelectResult with keyValues not implement in cache mode");
        }
        public virtual TEntity Select(string _conditionString = "", object keyValues = null)
        {
            throw new Exception("Select with keyValues not implement in cache mode");
        }
        public virtual IEnumerable<TEntity> SelectRange(string _conditionString = "", object keyValues = null)
        {
            throw new Exception("SelectRange with keyValues not implement in cache mode");
        }
        public virtual IEnumerable<TEntity> MorphRange(string _conditionString = "", object keyValues = null, string _morphString = "", string _targetName = "")
        {
            throw new Exception("MorphRange with keyValues not implement in cache mode");
        }
    }
    public class DpSet<TEntity>
    {
        string _connectionString;
        SqlConnection _connection;
        public string ConnectionString { set { _connectionString = value; _connection = new SqlConnection(_connectionString); } }
        //bool _isCached = false;
        //DpCache<TEntity> _dataCached;
        //public bool IsCached { get { return _isCached; }  set { _isCached = value; } }
        //public DpCache<TEntity> DataCached { get { return _dataCached; } set { _dataCached = value; } }
        string _tableName;
        string _identityColumn;
        List<string> _columns = new List<string>();
        public string TableName { set { _tableName = value; } }
        public string IdentityColumn { set { _identityColumn = value; } }
        public List<string> Columns { set { _columns = value; } }
        int _pageSize = 10;
        int _requestPage = 1;
        int _skipRows = 0;
        int _takeRows = 1000;
        public int PageSize { set { _pageSize = value; } }
        public int RequestPage { set { _requestPage = value; } }
        public int SkipRows { set { _skipRows = value; } }
        public int TakeRows { set { _takeRows = value; } }
        string _countQuery = "SELECT COUNT(*) FROM {0}{1}";
        string _findQuery = "SELECT TOP 1 * FROM {0} WHERE {1} = @ID";
        string _selectQuery = "SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY {2}) AS ROW_NUMBER_STT, * FROM {0}{1}) T WHERE (ROW_NUMBER_STT BETWEEN {3} AND {4})";
        string _selectDOQuery = "SELECT {6} FROM (SELECT ROW_NUMBER() OVER(ORDER BY {2}) AS ROW_NUMBER_STT,{5} FROM {0}{1}) T {7} WHERE ROW_NUMBER_STT BETWEEN {3} AND {4}";
        //{11} = ;
        //{2}=CustomerBase.IID DESC
        //{12}=CustomerBase.IID
        //{13}=ImplBase AS CustomerBase INNER JOIN dbo.ImplRecord AS CustomerInfo1 ON CustomerBase.IntValue1 = CustomerInfo1.IID
        //{14}=
        string _addQuery = "INSERT INTO {0} ({1}) VALUES({2});SELECT CAST(SCOPE_IDENTITY() AS INT)";
        string _updateQuery = "UPDATE {0} SET {1} WHERE {2} = @{2}";
        string _removeQuery = "DELETE FROM {0} WHERE {1} = @{1}";
        TEntity SetIdentity(TEntity entity, int id)
        {
            entity.GetType().GetProperty(_identityColumn).GetAccessors()[1].Invoke(entity, new object[] { id });
            return entity;
        }
        int GetIdentity(TEntity entity)
        {
            int id = 0;
            id = (int)entity.GetType().GetProperty(_identityColumn).GetAccessors()[0].Invoke(entity, null);
            return id;
        }
        string GetColumns(int opt)
        {
            List<string> columns = new List<string>();
            for (int i = 0; i < _columns.Count; i++)
            {
                switch (opt)
                {
                    case 1:
                        columns.Add("@" + _columns[i]); break;
                    case 2:
                        columns.Add(_columns[i] + " = @" + _columns[i]);
                        break;
                    default:
                        columns.Add(_columns[i]); break;
                }
            }
            return String.Join(",", columns);
        }
        void log(string _log)
        {
            _connection.Execute("insert into AppLog(msg) values (@log)", new { log = _log });
        }
        public int Count(int id)
        {
            string sqlQuery = String.Format(_countQuery, _tableName, " WHERE " + _identityColumn + " = @ID");
            //if (_isCached) return DataCached.Count(id);
            log(sqlQuery); return _connection.QueryFirst<int>(sqlQuery, new { ID = id });
        }
        public int Count(string _conditionString, object keyValues = null)
        {
            if (!string.IsNullOrEmpty(_conditionString)) _conditionString = " WHERE " + _conditionString.Trim(); else _conditionString = "";
            string sqlQuery = String.Format(_countQuery, _tableName, _conditionString);
            //if (_isCached) return DataCached.Count(_conditionString, keyValues);
            log(sqlQuery); return _connection.QueryFirst<int>(sqlQuery, keyValues);
        }
        public virtual TEntity Find(int id)
        {
            string sqlQuery = String.Format(_findQuery, _tableName, _identityColumn);
            //if (_isCached) return DataCached.Find(id);
            log(sqlQuery); return _connection.QueryFirst<TEntity>(sqlQuery, new { ID = id });
        }
        public DpSelectResult<TEntity> SelectResult(IQueryable<TEntity> _entities)
        {
            return new DpSelectResult<TEntity>()
            {
                ResultCount = _entities.Count(),
                ResultList = _entities.Skip(_skipRows).Take(_takeRows)
            };
        }
        public virtual DpSelectResult<TEntity> SelectResult(string _orderCondition = "", string _conditionString = "", object keyValues = null)
        {
            DpSelectResult<TEntity> result = new DpSelectResult<TEntity>();
            if (string.IsNullOrEmpty(_orderCondition)) _orderCondition = _identityColumn + " DESC";
            if (string.IsNullOrEmpty(_conditionString) || (_conditionString == " WHERE "))
            {
                string sqlQuery = String.Join(";", String.Format(_countQuery, _tableName, ""), String.Format(_selectQuery, _tableName, "", _orderCondition, (_skipRows + 1).ToString(), (_skipRows + _takeRows).ToString()));
                //if (_isCached) return DataCached.SelectResult(_orderCondition, _conditionString, keyValues);
                log(sqlQuery);
                var multipleResults = _connection.QueryMultiple(sqlQuery);
                result.ResultCount = multipleResults.Read<int>().ToList()[0];
                result.ResultList = multipleResults.Read<TEntity>().ToList();
                return result;
            }
            else
            {
                _conditionString = " WHERE " + _conditionString.Trim();
                string sqlQuery = String.Join(";", String.Format(_countQuery, _tableName, _conditionString), String.Format(_selectQuery, _tableName, _conditionString, _orderCondition, (_skipRows + 1).ToString(), (_skipRows + _takeRows).ToString()));
                //if (_isCached) return DataCached.SelectResult(_orderCondition, _conditionString, keyValues);
                log(sqlQuery);
                var multipleResults = _connection.QueryMultiple(sqlQuery, keyValues);
                result.ResultCount = multipleResults.Read<int>().ToList()[0];
                result.ResultList = multipleResults.Read<TEntity>().ToList();
                return result;
            }
        }
        public SqlMapper.GridReader DOSelectResult(string _selectAll, string _joinT, string _orderCondition = "", string _conditionString = "", object keyValues = null)
        {
            DpSelectResult<TEntity> result = new DpSelectResult<TEntity>();
            if (string.IsNullOrEmpty(_orderCondition)) _orderCondition = _identityColumn + " DESC";
            if (string.IsNullOrEmpty(_conditionString) || (_conditionString == " WHERE "))
            {
                string sqlQuery = String.Join(";", String.Format(_countQuery, _tableName, ""), String.Format(_selectDOQuery, _tableName, "", _orderCondition, (_skipRows + 1).ToString(), (_skipRows + _takeRows).ToString(), _identityColumn, _selectAll, _joinT));
                log(sqlQuery); var multipleResults = _connection.QueryMultiple(sqlQuery);
                return multipleResults;
            }
            else
            {
                _conditionString = " WHERE " + _conditionString.Trim();
                string sqlQuery = String.Join(";", String.Format(_countQuery, _tableName, _conditionString), String.Format(_selectDOQuery, _tableName, _conditionString, _orderCondition, (_skipRows + 1).ToString(), (_skipRows + _takeRows).ToString(), _identityColumn, _selectAll, _joinT));
                log(sqlQuery); var multipleResults = _connection.QueryMultiple(sqlQuery, keyValues);
                return multipleResults;
            }
        }
        public TEntity Select(string _conditionString = "", object keyValues = null)
        {
            if (!string.IsNullOrEmpty(_conditionString)) _conditionString = " WHERE " + _conditionString.Trim();
            string sqlQuery = String.Format("SELECT * FROM {0}{1}", _tableName, _conditionString);
            //if (_isCached) return DataCached.Select(_conditionString, keyValues);
            log(sqlQuery); return _connection.QueryFirst<TEntity>(sqlQuery, keyValues);
        }
        public IEnumerable<TEntity> SelectRange(string _conditionString = "", object keyValues = null)
        {
            if (!string.IsNullOrEmpty(_conditionString)) _conditionString = " WHERE " + _conditionString.Trim();
            string sqlQuery = String.Format("SELECT * FROM {0}{1}", _tableName, _conditionString);
            //if (_isCached) return DataCached.SelectRange(_conditionString, keyValues);
            log(sqlQuery); return _connection.Query<TEntity>(sqlQuery, keyValues);
        }
        public IEnumerable<TEntity> MorphRange(string _conditionString = "", object keyValues = null, string _morphString = "", string _targetName = "")
        {
            if (string.IsNullOrEmpty(_targetName)) _targetName = _tableName;
            if (string.IsNullOrEmpty(_morphString)) _morphString = "*";
            if (!string.IsNullOrEmpty(_conditionString)) _conditionString = " WHERE " + _conditionString.Trim();
            string sqlQuery = String.Format("SELECT {2} FROM {0}{1}", _targetName, _conditionString, _morphString);
            //if (_isCached) return DataCached.MorphRange(_conditionString, keyValues);
            log(sqlQuery); return _connection.Query<TEntity>(sqlQuery, keyValues);
        }
        public virtual TEntity Add(TEntity entity)
        {
            string sqlQuery = String.Format(_addQuery, _tableName, GetColumns(0), GetColumns(1));
            log(sqlQuery); var id = _connection.QueryFirstOrDefault<int>(sqlQuery, entity);
            //if (_isCached) { _isCached = false; DataCached.resetCaching(SelectRange().ToList()); _isCached = true; }
            return SetIdentity(entity, id);
        }
        public IEnumerable<TEntity> AddRange(IEnumerable<TEntity> entities)
        {
            List<TEntity> _entities = entities.ToList();
            for (int i = 0; i < _entities.Count(); i++)
                _entities[i] = Add(_entities[i]);
            return _entities.AsEnumerable();
        }
        public virtual TEntity Update(TEntity entity)
        {
            string sqlQuery = String.Format(_updateQuery, _tableName, GetColumns(2), _identityColumn);
            log(sqlQuery); _connection.Execute(sqlQuery, entity);
            //if (_isCached) { _isCached = false; DataCached.resetCaching(SelectRange().ToList()); _isCached = true; }
            return entity;
        }
        public IEnumerable<TEntity> UpdateRange(IEnumerable<TEntity> entities)
        {
            List<TEntity> _entities = entities.ToList();
            for (int i = 0; i < _entities.Count(); i++)
                Update(_entities[i]);
            return _entities.AsEnumerable();
        }
        public virtual TEntity Remove(TEntity entity)
        {
            int id = GetIdentity(entity);
            string sqlQuery = String.Format(_removeQuery, _tableName, _identityColumn);
            log(sqlQuery); _connection.Execute(sqlQuery, new { id });
            //if (_isCached) { _isCached = false; DataCached.resetCaching(SelectRange().ToList()); _isCached = true; }
            return entity;
        }
        public IEnumerable<TEntity> RemoveRange(IEnumerable<TEntity> entities)
        {
            List<TEntity> _entities = entities.ToList();
            for (int i = 0; i < _entities.Count(); i++)
                Remove(_entities[i]);
            return _entities.AsEnumerable();
        }
        public void ExecuteQuery(string sqlQuery)
        {
            log(sqlQuery); _connection.Execute(sqlQuery);
        }
        public void ExecuteQuery(string sqlQuery, object param)
        {
            log(sqlQuery); _connection.Execute(sqlQuery, param);
        }
    }
}