﻿
using System.Collections.Generic;
using UTECHTWO.Models.EF;
using Dapper;

namespace UTECHTWO.Models.DP
{
    public class DPSanPhams : DpSet<DO.DOSanPham>
    {
        public DpSet<SanPham> USanPham { get; set; }
        public DpSet<SPInfo> USPInfo { get; set; }
        public DpSet<SPImage> USPImage { get; set; }
        public DPSanPhams()
        {
            string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Model2"].ToString();
            ConnectionString = _ConnectionString;
            TableName = "SanPham AS USanPham INNER JOIN SPInfo AS USPInfo ON USanPham.SanPhamID = USPInfo.SanPhamID INNER JOIN SPImage AS USPImage ON USanPham.SanPhamID = USPImage.SanPhamID";
            IdentityColumn = "USanPham.SanPhamID";
            USanPham = new DpSet<SanPham>()
            {
                ConnectionString = _ConnectionString,
                TableName = "SanPham",
                IdentityColumn = "SanPhamID",
                Columns = new List<string>() { "SanPhamMD","MaSanPham","TenSanPham","DonVi","IsDelete", }
            };
            USPInfo = new DpSet<SPInfo>()
            {
                ConnectionString = _ConnectionString,
                TableName = "SPInfo",
                IdentityColumn = "SPInfoID",
                Columns = new List<string>() { "SanPhamID","NhaCungCapID","TenSanXuat","SanLuong","NongDoMauSac","KhoiLuongDungLuong","ChungLoaiVoChua","PhanPhoiSanXuat","GhiChu","JsonData", }
            };
            USPImage = new DpSet<SPImage>()
            {
                ConnectionString = _ConnectionString,
                TableName = "SPImage",
                IdentityColumn = "SPImageID",
                Columns = new List<string>() { "SanPhamID","SPImageMoreID","MatTruoc","MatSau","MatTren","DongGoi1","DongGoi2","AnhKhac", }
            };
        }
        public override DO.DOSanPham Find(int id)
        {
            DO.DOSanPham model = new DO.DOSanPham();
            model.USanPham = USanPham.Find(id);
            model.USPInfo = USPInfo.Find(model.USanPham.SanPhamID);
            model.USPImage = USPImage.Find(model.USanPham.SanPhamID);
            return model;
        }
        public override DpSelectResult<DO.DOSanPham> SelectResult(string _orderCondition = "", string _conditionString = "", object keyValues = null)
        {
            DpSelectResult<DO.DOSanPham> result = new DpSelectResult<DO.DOSanPham>();
            string _param6 = "USanPham.*,USPInfo.*,USPImage.*";
            string _param7 = "INNER JOIN SanPham AS USanPham ON T.SanPhamID = USanPham.SanPhamID INNER JOIN SPInfo AS USPInfo ON USanPham.SanPhamID = USPInfo.SanPhamID INNER JOIN SPImage AS USPImage ON USanPham.SanPhamID = USPImage.SanPhamID";
            var multipleResults = DOSelectResult(_param6, _param7, _orderCondition, _conditionString, keyValues);
            result.ResultCount = multipleResults.Read<int>().AsList()[0];
            result.ResultList = multipleResults.Read<EF.SanPham,EF.SPInfo,EF.SPImage, DO.DOSanPham>((_USanPham,_USPInfo,_USPImage) => { return new DO.DOSanPham() { USanPham = _USanPham,USPInfo = _USPInfo,USPImage = _USPImage }; }, splitOn: "SanPhamID");
            return result;
        }
        public override DO.DOSanPham Add(DO.DOSanPham model)
        {
            model.USPInfo = USPInfo.Add(model.USPInfo);
            model.USanPham.SanPhamID = model.USanPham.SanPhamID;
            model.USPImage = USPImage.Add(model.USPImage);
            model.USanPham.SanPhamID = model.USanPham.SanPhamID;
            model.USanPham = USanPham.Add(model.USanPham);
            return model;
        }
        public override DO.DOSanPham Update(DO.DOSanPham model)
        {
            model.USanPham = USanPham.Update(model.USanPham);
            model.USPInfo = USPInfo.Update(model.USPInfo);
            model.USPImage = USPImage.Update(model.USPImage);
            return model;
        }
        public override DO.DOSanPham Remove(DO.DOSanPham model)
        {
            model.USanPham = USanPham.Remove(model.USanPham);
            model.USPInfo = USPInfo.Remove(model.USPInfo);
            model.USPImage = USPImage.Remove(model.USPImage);
            return model;
        }
    };
};
