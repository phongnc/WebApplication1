namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("NhapHang")]
    public partial class NhapHang
    {
        public int NhapHangID { get; set; }

        public int? KhoID { get; set; }

        public int? SanPhamID { get; set; }

        public int? NhaCungCapID { get; set; }

        [StringLength(150)]
        public string NhaSanXuat { get; set; }

        [StringLength(50)]
        public string MaLoHang { get; set; }

        public int? SoLuong { get; set; }

        public int? TonKho { get; set; }

        public int? DonGia { get; set; }

        [StringLength(15)]
        public string HanSuDung { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? NgayNhapHang { get; set; }

        public bool? IsDelete { get; set; }
    }
}
