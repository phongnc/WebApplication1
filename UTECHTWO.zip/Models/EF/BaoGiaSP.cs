namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BaoGiaSP")]
    public partial class BaoGiaSP
    {
        public int BaoGiaSPID { get; set; }

        public int? BaoGiaID { get; set; }

        public int? SanPhamID { get; set; }

        public int? SoLuong { get; set; }

        public int? DonGia { get; set; }

        public int? TrangThai { get; set; }

        public bool? IsDelete { get; set; }
    }
}
