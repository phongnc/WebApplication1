namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SanPham")]
    public partial class SanPham
    {
        public int SanPhamID { get; set; }

        public int? SanPhamMD { get; set; }

        [StringLength(50)]
        public string MaSanPham { get; set; }

        [StringLength(150)]
        public string TenSanPham { get; set; }

        [StringLength(15)]
        public string DonVi { get; set; }

        public bool? IsDelete { get; set; }
    }
}
