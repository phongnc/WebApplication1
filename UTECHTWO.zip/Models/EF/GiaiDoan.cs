namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("GiaiDoan")]
    public partial class GiaiDoan
    {
        public int GiaiDoanID { get; set; }

        [StringLength(50)]
        public string MaGiaiDoan { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? BatDau { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? KetThuc { get; set; }
    }
}
