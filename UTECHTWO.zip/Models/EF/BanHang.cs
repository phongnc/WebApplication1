namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BanHang")]
    public partial class BanHang
    {
        public int BanHangID { get; set; }

        [StringLength(150)]
        public string Title { get; set; }

        public int? KhachHangID { get; set; }

        public int? LoaiDonHang { get; set; }

        public int? GiaiDoanID { get; set; }

        [StringLength(250)]
        public string NguoiDatHang { get; set; }

        [StringLength(50)]
        public string MaBoPhan { get; set; }

        [StringLength(15)]
        public string TyGia { get; set; }

        [StringLength(150)]
        public string LoaiChietKhau { get; set; }

        [StringLength(250)]
        public string DienGiai { get; set; }

        public bool? IsDelete { get; set; }
    }
}
