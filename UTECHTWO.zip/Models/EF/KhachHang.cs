namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("KhachHang")]
    public partial class KhachHang
    {
        public int KhachHangID { get; set; }

        [StringLength(50)]
        public string MaKhachHang { get; set; }

        [StringLength(150)]
        public string TenKhachHang { get; set; }

        [StringLength(250)]
        public string DiaChi { get; set; }

        [StringLength(50)]
        public string MST { get; set; }

        public bool? IsDelete { get; set; }
    }
}
