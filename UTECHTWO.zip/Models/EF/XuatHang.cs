namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("XuatHang")]
    public partial class XuatHang
    {
        public int XuatHangID { get; set; }

        public int? NhapHangID { get; set; }

        public int? DonHangSPID { get; set; }

        public int? SoLuong { get; set; }
    }
}
