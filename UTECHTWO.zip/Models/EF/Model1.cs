namespace UTECHTWO.Models.EF
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<BanHang> BanHangs { get; set; }
        public virtual DbSet<BaoGia> BaoGias { get; set; }
        public virtual DbSet<BaoGiaSP> BaoGiaSPs { get; set; }
        public virtual DbSet<DoanhThu> DoanhThus { get; set; }
        public virtual DbSet<DonHang> DonHangs { get; set; }
        public virtual DbSet<DonHangSP> DonHangSPs { get; set; }
        public virtual DbSet<DuBao> DuBaos { get; set; }
        public virtual DbSet<GiaiDoan> GiaiDoans { get; set; }
        public virtual DbSet<KhachHang> KhachHangs { get; set; }
        public virtual DbSet<Kho> Khoes { get; set; }
        public virtual DbSet<KhoKhach> KhoKhaches { get; set; }
        public virtual DbSet<LoaiSanPham> LoaiSanPhams { get; set; }
        public virtual DbSet<NhaCungCap> NhaCungCaps { get; set; }
        public virtual DbSet<NhapHang> NhapHangs { get; set; }
        public virtual DbSet<SanPham> SanPhams { get; set; }
        public virtual DbSet<SanPhamX> SanPhamXes { get; set; }
        public virtual DbSet<SPImage> SPImages { get; set; }
        public virtual DbSet<SPInfo> SPInfoes { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<XuatHang> XuatHangs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BaoGia>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<BaoGia>()
                .Property(e => e.ModifiedDate)
                .HasPrecision(0);

            modelBuilder.Entity<DonHang>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<DonHang>()
                .Property(e => e.ModifiedDate)
                .HasPrecision(0);

            modelBuilder.Entity<DuBao>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<DuBao>()
                .Property(e => e.ModifiedDate)
                .HasPrecision(0);

            modelBuilder.Entity<NhapHang>()
                .Property(e => e.HanSuDung)
                .IsUnicode(false);

            modelBuilder.Entity<NhapHang>()
                .Property(e => e.NgayNhapHang)
                .HasPrecision(0);
        }
    }
}
