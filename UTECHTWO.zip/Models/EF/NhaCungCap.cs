namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("NhaCungCap")]
    public partial class NhaCungCap
    {
        public int NhaCungCapID { get; set; }

        [StringLength(50)]
        public string MaNhaCungCap { get; set; }

        [StringLength(150)]
        public string TenNhaCungCap { get; set; }

        [StringLength(250)]
        public string DiaChi { get; set; }

        [StringLength(50)]
        public string MST { get; set; }

        public bool? IsDelete { get; set; }
    }
}
