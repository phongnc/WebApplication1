namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DonHangSP")]
    public partial class DonHangSP
    {
        public int DonHangSPID { get; set; }

        public int? DonHangID { get; set; }

        public int? SanPhamID { get; set; }

        public int? SoLuong { get; set; }

        public int? DonGia { get; set; }

        public int? TrangThai { get; set; }

        public bool? IsDelete { get; set; }
    }
}
