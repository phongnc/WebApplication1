namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SPInfo")]
    public partial class SPInfo
    {
        public int SPInfoID { get; set; }

        public int? SanPhamID { get; set; }

        public int? NhaCungCapID { get; set; }

        [StringLength(150)]
        public string TenSanXuat { get; set; }

        [StringLength(150)]
        public string SanLuong { get; set; }

        [StringLength(150)]
        public string NongDoMauSac { get; set; }

        [StringLength(150)]
        public string KhoiLuongDungLuong { get; set; }

        [StringLength(150)]
        public string ChungLoaiVoChua { get; set; }

        [StringLength(50)]
        public string PhanPhoiSanXuat { get; set; }

        [StringLength(250)]
        public string GhiChu { get; set; }

        public string JsonData { get; set; }
    }
}
