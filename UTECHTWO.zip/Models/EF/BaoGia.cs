namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BaoGia")]
    public partial class BaoGia
    {
        public int BaoGiaID { get; set; }

        public int? BanHangID { get; set; }

        [StringLength(50)]
        public string MaBaoGia { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? NgayBaoGia { get; set; }

        public int? LanSuaDoi { get; set; }

        public int? TrangThai { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ModifiedDate { get; set; }

        public int? CreatedUID { get; set; }

        public int? ModifiedUID { get; set; }

        public bool? IsDelete { get; set; }
    }
}
