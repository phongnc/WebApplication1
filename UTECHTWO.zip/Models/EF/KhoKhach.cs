namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("KhoKhach")]
    public partial class KhoKhach
    {
        public int KhoKhachID { get; set; }

        public int? KhachHangID { get; set; }

        public int? SanPhamID { get; set; }

        public int? SoLuong { get; set; }
    }
}
