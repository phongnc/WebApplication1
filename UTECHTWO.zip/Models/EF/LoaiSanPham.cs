namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("LoaiSanPham")]
    public partial class LoaiSanPham
    {
        public int LoaiSanPhamID { get; set; }

        [StringLength(50)]
        public string MaLoaiSanPham { get; set; }

        [StringLength(150)]
        public string TenLoaiSanPham { get; set; }

        public bool? IsDelete { get; set; }
    }
}
