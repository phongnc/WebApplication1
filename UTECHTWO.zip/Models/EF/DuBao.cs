namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DuBao")]
    public partial class DuBao
    {
        public int DuBaoID { get; set; }

        public int? KhachHangID { get; set; }

        public int? SanPhamID { get; set; }

        public int? GiaiDoanID { get; set; }

        public int? SoLuong { get; set; }

        public int? DonGia { get; set; }

        public int? TrangThai { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ModifiedDate { get; set; }

        public int? CreatedUID { get; set; }

        public int? ModifiedUID { get; set; }

        public bool? IsDelete { get; set; }
    }
}
