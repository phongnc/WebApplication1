namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SPImage")]
    public partial class SPImage
    {
        public int SPImageID { get; set; }

        public int? SanPhamID { get; set; }

        public int? SPImageMoreID { get; set; }

        [StringLength(250)]
        public string MatTruoc { get; set; }

        [StringLength(250)]
        public string MatSau { get; set; }

        [StringLength(250)]
        public string MatTren { get; set; }

        [StringLength(250)]
        public string DongGoi1 { get; set; }

        [StringLength(250)]
        public string DongGoi2 { get; set; }

        [StringLength(250)]
        public string AnhKhac { get; set; }
    }
}
