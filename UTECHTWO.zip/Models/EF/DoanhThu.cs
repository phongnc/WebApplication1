namespace UTECHTWO.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DoanhThu")]
    public partial class DoanhThu
    {
        public int DoanhThuID { get; set; }

        public int? DonHangSPID { get; set; }

        public int? DoanhThuDuKien { get; set; }

        public int? DoanhThuHoaDon { get; set; }

        public int? DoanhThuThucTe { get; set; }

        [StringLength(450)]
        public string GhiChu { get; set; }
    }
}
