﻿
using System.Collections.Generic;
namespace UTECHTWO.Models.SO
{
    public class SearchLoaiSanPham : Models.EF.LoaiSanPham
    {
        public int take { get; set; }
        public int skip { get; set; }
        public SearchLoaiSanPham()
        {
            //TODO:
        }
        public string OrderCondition()
        {
            string _orderCondition =  "";
            return _orderCondition;
        }
        public string ConditionString()
        {
            string _conditionString = "";
            List<string> _conditionList = new List<string>();
            try { if (!string.IsNullOrEmpty(TenLoaiSanPham)) _conditionList.Add("TenLoaiSanPham LIKE @TenLoaiSanPham"); } catch { }
            if (_conditionList.Count > 0) _conditionString = string.Join(" AND ", _conditionList);
            return _conditionString;
        }
        public object ConditionObject()
        {
            return new {
                TenLoaiSanPham = new Dapper.DbString() { Value = '%' + TenLoaiSanPham + '%', IsAnsi = false, Length = 150 },
            };
        }
    }
}
