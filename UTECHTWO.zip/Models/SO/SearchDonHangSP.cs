﻿
using System.Collections.Generic;
namespace UTECHTWO.Models.SO
{
    public class SearchDonHangSP : Models.EF.DonHangSP
    {
        public int take { get; set; }
        public int skip { get; set; }
        public SearchDonHangSP()
        {
            //TODO:
        }
        public string OrderCondition()
        {
            string _orderCondition =  "";
            return _orderCondition;
        }
        public string ConditionString()
        {
            string _conditionString = "";
            List<string> _conditionList = new List<string>();
            
            if (_conditionList.Count > 0) _conditionString = string.Join(" AND ", _conditionList);
            return _conditionString;
        }
        public object ConditionObject()
        {
            return new {
            };
        }
    }
}
