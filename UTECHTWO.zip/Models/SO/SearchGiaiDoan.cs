﻿
using System.Collections.Generic;
namespace UTECHTWO.Models.SO
{
    public class SearchGiaiDoan : Models.EF.GiaiDoan
    {
        public int take { get; set; }
        public int skip { get; set; }
        public SearchGiaiDoan()
        {
            //TODO:
        }
        public string OrderCondition()
        {
            string _orderCondition =  "";
            return _orderCondition;
        }
        public string ConditionString()
        {
            string _conditionString = "";
            List<string> _conditionList = new List<string>();
            try { if (!string.IsNullOrEmpty(MaGiaiDoan)) _conditionList.Add("MaGiaiDoan LIKE @MaGiaiDoan"); } catch { }
            if (_conditionList.Count > 0) _conditionString = string.Join(" AND ", _conditionList);
            return _conditionString;
        }
        public object ConditionObject()
        {
            return new {
                MaGiaiDoan = new Dapper.DbString() { Value = '%' + MaGiaiDoan + '%', IsAnsi = false, Length = 50 },
            };
        }
    }
}
