﻿
using System.Collections.Generic;
namespace UTECHTWO.Models.SO
{
    public class SearchDOSanPham : Models.DO.DOSanPham
    {
        public int take { get; set; }
        public int skip { get; set; }
        public SearchDOSanPham()
        {
            USanPham = new EF.SanPham();
            USPInfo = new EF.SPInfo();
            USPImage = new EF.SPImage();
        }
        public string OrderCondition()
        {
            string _orderCondition =  "";
            return _orderCondition;
        }
        public string ConditionString()
        {
            string _conditionString = "";
            List<string> _conditionList = new List<string>();
            try { if (USanPham.SanPhamMD > 0) _conditionList.Add("USanPham.SanPhamMD = @USanPham_SanPhamMD"); } catch { }
            try { if (USPInfo.NhaCungCapID > 0) _conditionList.Add("USPInfo.NhaCungCapID LIKE @USPInfo_NhaCungCapID"); } catch { }
            try { if (!string.IsNullOrEmpty(USanPham.TenSanPham)) _conditionList.Add("USanPham.TenSanPham LIKE @USanPham_TenSanPham"); } catch { }
            try { if (!string.IsNullOrEmpty(USPInfo.TenSanXuat)) _conditionList.Add("USPInfo.TenSanXuat LIKE @USPInfo_TenSanXuat"); } catch { }
            if (_conditionList.Count > 0) _conditionString = string.Join(" AND ", _conditionList);
            return _conditionString;
        }
        public object ConditionObject()
        {
            return new {
                USanPham_SanPhamMD = USanPham.SanPhamMD,
                USPInfo_NhaCungCapID = USPInfo.NhaCungCapID,
                USanPham_TenSanPham = new Dapper.DbString() { Value = '%' + USanPham.TenSanPham + '%', IsAnsi = false, Length = 150 },
                USPInfo_TenSanXuat = new Dapper.DbString() { Value = '%' + USPInfo.TenSanXuat + '%', IsAnsi = false, Length = 150 },
            };
        }
    }
}
