﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UTECHTWO.Models.DO
{
    public class EObject
    {
        public string StringValue = "";
        public string TitValue = "";
        public string ICD = "";
        public int IID = 0;
    }
    public class COConfig
    {
        public string TableName = "";
        public string ColumnName = "";
        public string FTableName = "";
        public string FValueColumnName = "";
        public string FTextColumnName = "";
    }
    public class COManuals
    {
        public List<COConfig> EnumConfigs = new List<COConfig>();
        public List<COConfig> ClientConfigs = new List<COConfig>();
        public COManuals()
        {
            COConfig _clConfig10 = new COConfig()
            {
                TableName = "BanHang",
                ColumnName = "Title",
                FTableName = "dxDetailLink",
                FValueColumnName = "BanHangID"
            };
            COConfig _clConfig101 = new COConfig()
            {
                TableName = "DonHang",
                ColumnName = "MaDonHang",
                FTableName = "dxDetailLink",
                FValueColumnName = "DonHangID"
            };
            COConfig _clConfig103 = new COConfig()
            {
                TableName = "BaoGia",
                ColumnName = "MaBaoGia",
                FTableName = "dxDetailLink",
                FValueColumnName = "BaoGiaID"
            };
            COConfig _clConfig20 = new COConfig()
            {
                TableName = "SanPham",
                ColumnName = "TenSanPham",
                FTableName = "dxDetailLink",
                FValueColumnName = "SanPhamID"
            };
            //COConfig _clConfig3 = new COConfig()
            //{
            //    TableName = "IPMNewss_Tb",
            //    ColumnName = "Image",
            //    FTableName = "dxImageEditor"
            //};
            //COConfig _clConfig4 = new COConfig()
            //{
            //    TableName = "IPMNewss_Tb",
            //    ColumnName = "Content",
            //    FTableName = "dxHtmlEditor"
            //};
            ClientConfigs.Add(_clConfig10);
            ClientConfigs.Add(_clConfig101);
            ClientConfigs.Add(_clConfig103);
            ClientConfigs.Add(_clConfig20);
            //ClientConfigs.Add(_clConfig3);
            //ClientConfigs.Add(_clConfig4);
            COConfig _coConfig9_1 = new COConfig()
            {
                TableName = "KhoKhach",
                ColumnName = "KhachHangID",
                FTableName = "KhachHang",
                FValueColumnName = "KhachHangID",
                FTextColumnName = "TenKhachHang"
            };
            COConfig _coConfig9_2 = new COConfig()
            {
                TableName = "KhoKhach",
                ColumnName = "SanPhamID",
                FTableName = "SanPham",
                FValueColumnName = "SanPhamID",
                FTextColumnName = "TenSanPham"
            };
            COConfig _coConfig10_1 = new COConfig()
            {
                TableName = "BanHang",
                ColumnName = "KhachHangID",
                FTableName = "KhachHang",
                FValueColumnName = "KhachHangID",
                FTextColumnName = "TenKhachHang"
            };
            COConfig _coConfig10_2 = new COConfig()
            {
                TableName = "BanHang",
                ColumnName = "GiaiDoanID",
                FTableName = "GiaiDoan",
                FValueColumnName = "GiaiDoanID",
                FTextColumnName = "MaGiaiDoan"
            };
            COConfig _coConfig101_0 = new COConfig()
            {
                TableName = "BaoGia",
                ColumnName = "BanHangID",
                FTableName = "BanHang",
                FValueColumnName = "BanHangID",
                FTextColumnName = "Title"
            };
            COConfig _coConfig102_0 = new COConfig()
            {
                TableName = "BaoGiaSP",
                ColumnName = "BaoGiaID",
                FTableName = "BaoGia",
                FValueColumnName = "BaoGiaID",
                FTextColumnName = "MaBaoGia"
            };
            COConfig _coConfig102_1 = new COConfig()
            {
                TableName = "BaoGiaSP",
                ColumnName = "SanPhamID",
                FTableName = "SanPham",
                FValueColumnName = "SanPhamID",
                FTextColumnName = "TenSanPham"
            };
            COConfig _coConfig103_0 = new COConfig()
            {
                TableName = "DonHang",
                ColumnName = "BanHangID",
                FTableName = "BanHang",
                FValueColumnName = "BanHangID",
                FTextColumnName = "Title"
            };
            COConfig _coConfig104_0 = new COConfig()
            {
                TableName = "DonHangSP",
                ColumnName = "DonHangID",
                FTableName = "DonHang",
                FValueColumnName = "DonHangID",
                FTextColumnName = "MaDonHang"
            };
            COConfig _coConfig104_1 = new COConfig()
            {
                TableName = "DonHangSP",
                ColumnName = "SanPhamID",
                FTableName = "SanPham",
                FValueColumnName = "SanPhamID",
                FTextColumnName = "TenSanPham"
            };
            COConfig _coConfig11_1 = new COConfig()
            {
                TableName = "NhapHang",
                ColumnName = "KhoID",
                FTableName = "Kho",
                FValueColumnName = "KhoID",
                FTextColumnName = "TenKho"
            };
            COConfig _coConfig11_2 = new COConfig()
            {
                TableName = "NhapHang",
                ColumnName = "SanPhamID",
                FTableName = "SanPham",
                FValueColumnName = "SanPhamID",
                FTextColumnName = "TenSanPham"
            };
            COConfig _coConfig11_3 = new COConfig()
            {
                TableName = "NhapHang",
                ColumnName = "NhaCungCapID",
                FTableName = "NhaCungCap",
                FValueColumnName = "NhaCungCapID",
                FTextColumnName = "TenNhaCungCap"
            };
            COConfig _coConfig12_1 = new COConfig()
            {
                TableName = "XuatHang",
                ColumnName = "DonHangSPID",
                FTableName = "DonHangSP",
                FValueColumnName = "DonHangSPID",
                FTextColumnName = "SanPhamID"
            };
            COConfig _coConfig12_2 = new COConfig()
            {
                TableName = "XuatHang",
                ColumnName = "NhapHangID",
                FTableName = "NhapHang",
                FValueColumnName = "NhapHangID",
                FTextColumnName = "MaLoHang"
            };
            COConfig _coConfig13_0 = new COConfig()
            {
                TableName = "DoanhThu",
                ColumnName = "DonHangSPID",
                FTableName = "DonHangSP",
                FValueColumnName = "DonHangSPID",
                FTextColumnName = "SanPhamID"
            };
            COConfig _coConfig14_1 = new COConfig()
            {
                TableName = "DuBao",
                ColumnName = "KhachHangID",
                FTableName = "KhachHang",
                FValueColumnName = "KhachHangID",
                FTextColumnName = "TenKhachHang"
            };
            COConfig _coConfig14_2 = new COConfig()
            {
                TableName = "DuBao",
                ColumnName = "SanPhamID",
                FTableName = "SanPham",
                FValueColumnName = "SanPhamID",
                FTextColumnName = "TenSanPham"
            };
            COConfig _coConfig14_3 = new COConfig()
            {
                TableName = "DuBao",
                ColumnName = "GiaiDoanID",
                FTableName = "GiaiDoan",
                FValueColumnName = "GiaiDoanID",
                FTextColumnName = "MaGiaiDoan"
            };
            COConfig _coConfig20_1 = new COConfig()
            {
                TableName = "SanPham",
                ColumnName = "SanPhamMD",
                FTableName = "LoaiSanPham",
                FValueColumnName = "LoaiSanPhamID",
                FTextColumnName = "TenLoaiSanPham"
            };
            COConfig _coConfig21_0 = new COConfig()
            {
                TableName = "SPInfo",
                ColumnName = "SanPhamID",
                FTableName = "SanPham",
                FValueColumnName = "SanPhamID",
                FTextColumnName = "TenSanPham"
            };
            COConfig _coConfig21_1 = new COConfig()
            {
                TableName = "SPInfo",
                ColumnName = "NhaCungCapID",
                FTableName = "NhaCungCap",
                FValueColumnName = "NhaCungCapID",
                FTextColumnName = "TenNhaCungCap"
            };
            COConfig _coConfig22_0 = new COConfig()
            {
                TableName = "SPImage",
                ColumnName = "SanPhamID",
                FTableName = "SanPham",
                FValueColumnName = "SanPhamID",
                FTextColumnName = "TenSanPham"
            };
            EnumConfigs.Add(_coConfig9_1);
            EnumConfigs.Add(_coConfig9_2);
            EnumConfigs.Add(_coConfig10_1);
            EnumConfigs.Add(_coConfig10_2);
            EnumConfigs.Add(_coConfig101_0);
            EnumConfigs.Add(_coConfig102_0);
            EnumConfigs.Add(_coConfig102_1);
            EnumConfigs.Add(_coConfig103_0);
            EnumConfigs.Add(_coConfig104_0);
            EnumConfigs.Add(_coConfig104_1);
            EnumConfigs.Add(_coConfig11_1);
            EnumConfigs.Add(_coConfig11_2);
            EnumConfigs.Add(_coConfig11_3);
            EnumConfigs.Add(_coConfig12_1);
            EnumConfigs.Add(_coConfig12_2);
            EnumConfigs.Add(_coConfig13_0);
            EnumConfigs.Add(_coConfig14_1);
            EnumConfigs.Add(_coConfig14_2);
            EnumConfigs.Add(_coConfig14_3);
            EnumConfigs.Add(_coConfig20_1);
            EnumConfigs.Add(_coConfig21_0);
            EnumConfigs.Add(_coConfig21_1);
            EnumConfigs.Add(_coConfig22_0);
        }
    }
    public class DOConfig
    {
        public string PropName = "";
        public string TypeName = "";
        public string KeyName = "";
        public string MapName = "";
    }
    public class DOModel
    {
        public string Name = "";
        public string ListViewType = "GRID"; // GRID OR LIST
        public string DetailViewType = "GROUP"; // GROUP OR TAB
        public List<DOConfig> Configs = new List<DOConfig>();
    }
    public class DOModels
    {
        List<DOModel> doModels = new List<DOModel>();
        public DOModels()
        {
            DOModel _DOSanPham = new DOModel();
            _DOSanPham.Name = "DOSanPham";
            _DOSanPham.DetailViewType = "GROUP";
            _DOSanPham.Configs.Add(new DOConfig
            {
                PropName = "USanPham",
                TypeName = "SanPham",
                KeyName = "SanPhamID",
                MapName = ""
            });
            _DOSanPham.Configs.Add(new DOConfig
            {
                PropName = "USPInfo",
                TypeName = "SPInfo",
                KeyName = "SanPhamID",
                MapName = "SanPhamID"
            });
            _DOSanPham.Configs.Add(new DOConfig
            {
                PropName = "USPImage",
                TypeName = "SPImage",
                KeyName = "SanPhamID",
                MapName = "SanPhamID"
            });
            DOModel _DOBaoGia = new DOModel();
            _DOBaoGia.Name = "DOBaoGia";
            _DOBaoGia.DetailViewType = "GROUP";
            _DOBaoGia.Configs.Add(new DOConfig
            {
                PropName = "UBaoGia",
                TypeName = "BaoGia",
                KeyName = "BaoGiaID",
                MapName = "",
            });
            _DOBaoGia.Configs.Add(new DOConfig
            {
                PropName = "UBanHang",
                TypeName = "BanHang",
                KeyName = "BanHangID",
                MapName = "BanHangID",
            });
            DOModel _DODonHang = new DOModel();
            _DODonHang.Name = "DODonHang";
            _DODonHang.DetailViewType = "GROUP";
            _DODonHang.Configs.Add(new DOConfig
            {
                PropName = "UDonHang",
                TypeName = "DonHang",
                KeyName = "DonHangID",
                MapName = "",
            });
            _DODonHang.Configs.Add(new DOConfig
            {
                PropName = "UBanHang",
                TypeName = "BanHang",
                KeyName = "BanHangID",
                MapName = "BanHangID",
            });
            doModels.Add(_DOSanPham);
            doModels.Add(_DOBaoGia);
            doModels.Add(_DODonHang);
        }
        public DOModel getModel(string name)
        {
            return doModels.First(o => o.Name == name);
        }
    }
    public class DOSanPham
    {
        public Models.EF.SanPham USanPham { get; set; }
        public Models.EF.SPInfo USPInfo { get; set; }
        public Models.EF.SPImage USPImage { get; set; }
    }
    public class DOBaoGia
    {
        public Models.EF.BanHang UBanHang { get; set; }
        public Models.EF.BaoGia UBaoGia { get; set; }
        public List<Models.EF.BaoGiaSP> UBaoGiaSPs { get; set; }
    }
    public class DODonHang
    {
        public Models.EF.BanHang UBanHang { get; set; }
        public Models.EF.DonHang UDonHang { get; set; }
        public List<Models.EF.DonHangSP> UDonHangSPs { get; set; }
    }
}