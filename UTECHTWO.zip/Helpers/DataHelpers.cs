﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UTECHTWO.Models.EF;

namespace UTECHTWO.Helpers
{
    public class DataHelpers
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public void XuatHang()
        {
            List<DonHangSP> _donhangSPs = db.DonHangSPs.SelectRange().ToList();
            for (int i = 0; i < _donhangSPs.Count; i++)
            {
                int _nhaphangID = db.NhapHangs.Select("SanPhamID = @SanPhamID", new { SanPhamID = _donhangSPs[i].SanPhamID }).NhapHangID;
                XuatHang _xuathang = new Models.EF.XuatHang()
                {
                    DonHangSPID = _donhangSPs[i].DonHangSPID,
                    SoLuong = _donhangSPs[i].SoLuong,
                    NhapHangID = _nhaphangID
                };
                db.XuatHangs.Add(_xuathang);
            }
        }
        public void NhapHang()
        {
            List<SanPham> _sanphams = db.SanPhams.SelectRange().ToList();
            for (int i = 0; i < _sanphams.Count; i++)
            {
                List<DonHangSP> _donhangSPs = db.DonHangSPs.SelectRange("SanPhamID = @SanPhamID", new { SanPhamID = _sanphams[i].SanPhamID }).ToList();
                int _dongia = _donhangSPs.Min(o => o.DonGia).Value;
                int _sum = _donhangSPs.Sum(o => o.SoLuong).Value;
                NhapHang _nhaphang = new Models.EF.NhapHang()
                {
                    DonGia = _dongia,
                    HanSuDung = "10/2020",
                    IsDelete = false,
                    KhoID = 1,
                    MaLoHang = "201803" + _sanphams[i].MaSanPham,
                    NgayNhapHang = DateTime.Now.AddMonths(-1).AddDays(-10),
                    NhaCungCapID = 1,
                    NhaSanXuat = "GREATE MANUFACTURER",
                    SanPhamID = _sanphams[i].SanPhamID,
                    SoLuong = _sum + 1000,
                    TonKho = 1000,
                };
                db.NhapHangs.Add(_nhaphang);
            }
        }
        public void KhoKhach()
        {
            List<DonHangSP> _donhangSPs = db.DonHangSPs.SelectRange().ToList();
            for (int i = 0; i < _donhangSPs.Count; i++)
            {
                int _khachhangID = db.BanHangs.Select("BanHangID = (SELECT BanHangID FROM DonHang WHERE DonhangID = @DonhangID)", new { DonhangID = _donhangSPs[i].DonHangID}).KhachHangID.Value;
                KhoKhach _xuathang = new Models.EF.KhoKhach()
                {
                    KhachHangID = _khachhangID,
                    SanPhamID = _donhangSPs[i].SanPhamID,
                    SoLuong = _donhangSPs[i].SoLuong
                };
                db.KhoKhaches.Add(_xuathang);
            }
        }
    }
}