﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace UTECHTWO
{
    public class CaptchaImage
    {
        public Bitmap Image
        {
            get { return this.image; }
        }

        private string text;
        private int width;
        private int height;
        private System.Drawing.FontFamily fontFamily;
        private Bitmap image;

        private Random random = new Random();

        public CaptchaImage(int width, int height, System.Drawing.FontFamily fontFamily)
        {
            this.width = width;
            this.height = height;
            this.fontFamily = fontFamily;
        }
        public CaptchaImage(string s, int width, int height, System.Drawing.FontFamily fontFamily)
        {
            this.text = s;
            this.width = width;
            this.height = height;
            this.fontFamily = fontFamily;
        }
        public string CreateRandomText(int Length)
        {
            string allowedChars = "1234567890";//abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ
            char[] chars = new char[Length];
            Random rd = new Random();

            for (int i = 0; i < Length; i++)
            {
                chars[i] = allowedChars[rd.Next(0, allowedChars.Length)];
            }

            return new string(chars);
        }

        public void GenerateImage()
        {
            // Create a new 32-bit bitmap image.
            Bitmap bitmap = new Bitmap(this.width, this.height, PixelFormat.Format32bppArgb);

            // Create a graphics object for drawing.
            Graphics g = Graphics.FromImage(bitmap);
            g.PageUnit = GraphicsUnit.Pixel;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(0, 0, this.width, this.height);

            //string[] aFontNames = new string[]
            //{
            //     "Comic Sans MS",
            //     "Arial",
            //     "Times New Roman",
            //     "Georgia",
            //     "Verdana",
            //     "Geneva"
            //};
            //FontStyle[] aFontStyles = new FontStyle[]
            //{
            //     FontStyle.Bold,
            //     FontStyle.Italic,
            //     FontStyle.Regular,
            //     FontStyle.Strikeout,
            //     FontStyle.Underline
            //};
            //HatchStyle[] aHatchStyles = new HatchStyle[]
            //{
            //    HatchStyle.BackwardDiagonal, HatchStyle.Cross,
            //    HatchStyle.DashedDownwardDiagonal, HatchStyle.DashedHorizontal,
            //    HatchStyle.DashedUpwardDiagonal, HatchStyle.DashedVertical,
            //    HatchStyle.DiagonalBrick, HatchStyle.DiagonalCross,
            //    HatchStyle.Divot, HatchStyle.DottedDiamond, HatchStyle.DottedGrid,
            //    HatchStyle.ForwardDiagonal, HatchStyle.Horizontal,
            //    HatchStyle.HorizontalBrick, HatchStyle.LargeCheckerBoard,
            //    HatchStyle.LargeConfetti, HatchStyle.LargeGrid,
            //    HatchStyle.LightDownwardDiagonal, HatchStyle.LightHorizontal,
            //    HatchStyle.LightUpwardDiagonal, HatchStyle.LightVertical,
            //    HatchStyle.Max, HatchStyle.Min, HatchStyle.NarrowHorizontal,
            //    HatchStyle.NarrowVertical, HatchStyle.OutlinedDiamond,
            //    HatchStyle.Plaid, HatchStyle.Shingle, HatchStyle.SmallCheckerBoard,
            //    HatchStyle.SmallConfetti, HatchStyle.SmallGrid,
            //    HatchStyle.SolidDiamond, HatchStyle.Sphere, HatchStyle.Trellis,
            //    HatchStyle.Vertical, HatchStyle.Wave, HatchStyle.Weave,
            //    HatchStyle.WideDownwardDiagonal, HatchStyle.WideUpwardDiagonal, HatchStyle.ZigZag
            //};
            // Fill in the background.
            Random oRandom = new Random();
            HatchBrush hatchBrush = new HatchBrush(HatchStyle.Shingle, Color.LightGray, Color.White);
            //hatchBrush = new HatchBrush(aHatchStyles[oRandom.Next(aHatchStyles.Length - 1)], Color.FromArgb((oRandom.Next(100, 255)),(oRandom.Next(100, 255)), (oRandom.Next(100, 255))), Color.White);
            g.FillRectangle(hatchBrush, rect);

            // Set up the text font.
            SizeF size;
            float fontSize = rect.Height + 1;
            Font font;
            // Adjust the font size until the text fits within the image.
            do
            {
                fontSize--;
                font = new Font(this.fontFamily.Name, fontSize, GraphicsUnit.Pixel);
                size = g.MeasureString(this.text, font);
            } while (size.Width > rect.Width);

            // Set up the text format.
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;

            // Create a path using the text and warp it randomly.
            GraphicsPath path = new GraphicsPath();

            path.AddString(this.text, font.FontFamily, (int)font.Style, font.Size, rect, format);
            float v = 4F;
            PointF[] points =
            {
                new PointF(this.random.Next(rect.Width) / v, this.random.Next(rect.Height) / v),
                new PointF(rect.Width - this.random.Next(rect.Width) / v, this.random.Next(rect.Height) / v),
                new PointF(this.random.Next(rect.Width) / v, rect.Height - this.random.Next(rect.Height) / v),
                new PointF(rect.Width - this.random.Next(rect.Width) / v, rect.Height - this.random.Next(rect.Height) / v)
            };
            Matrix matrix = new Matrix();
            matrix.Translate(0F, 0F);
            path.Warp(points, rect, matrix, WarpMode.Perspective, 0F);

            // Draw the text.
            hatchBrush = new HatchBrush(HatchStyle.Shingle, Color.LightGray, Color.DarkGray);
            g.FillPath(hatchBrush, path);

            // Add some random noise.
            int m = Math.Max(rect.Width, rect.Height);
            for (int i = 0; i < (int)(rect.Width * rect.Height / 30F); i++)
            {
                int x = this.random.Next(rect.Width);
                int y = this.random.Next(rect.Height);
                int w = this.random.Next(m / 50);
                int h = this.random.Next(m / 50);
                g.FillEllipse(hatchBrush, x, y, w, h);
            }

            // Clean up.
            font.Dispose();
            hatchBrush.Dispose();
            g.Dispose();

            // Set the image.
            this.image = bitmap;
        }

        public void SetText(string text)
        {
            this.text = text;
        }
    }
    public class StringExtension
    {
        public const string uniChars =
            "àáảãạâầấẩẫậăằắẳẵặèéẻẽẹêềếểễệđìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵÀÁẢÃẠÂẦẤẨẪẬĂẰẮẲẴẶÈÉẺẼẸÊỀẾỂỄỆĐÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴÂĂĐÔƠƯ";

        public const string KoDauChars =
            "aaaaaaaaaaaaaaaaaeeeeeeeeeeediiiiiooooooooooooooooouuuuuuuuuuuyyyyyAAAAAAAAAAAAAAAAAEEEEEEEEEEEDIIIOOOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYYAADOOU";

        public string UnicodeToKoDau(string s)
        {
            string retVal = String.Empty;
            int pos;
            for (int i = 0; i < s.Length; i++)
            {
                pos = uniChars.IndexOf(s[i].ToString());
                if (pos >= 0)
                    retVal += KoDauChars[pos];
                else
                    retVal += s[i];
            }
            return retVal;
        }

        public static string UnicodeToKoDauAndGach(string s)
        {
            if (string.IsNullOrEmpty(s))
                return "";
            string retVal = String.Empty;
            int pos;

            for (int i = 0; i < s.Length; i++)
            {
                pos = uniChars.IndexOf(s[i].ToString());
                if (pos >= 0)
                    retVal += KoDauChars[pos];
                else
                    retVal += s[i];
            }
            String temp = retVal;
            for (int i = 0; i < retVal.Length; i++)
            {
                pos = Convert.ToInt32(retVal[i]);
                if (!((pos >= 97 && pos <= 122) || (pos >= 65 && pos <= 90) || (pos >= 48 && pos <= 57) || pos == 32))
                    temp = temp.Replace(retVal[i].ToString(), "");
            }
            temp = temp.Replace(" ", "-");
            while (temp.EndsWith("-"))
                temp = temp.Substring(0, temp.Length - 1);

            while (temp.IndexOf("--") >= 0)
                temp = temp.Replace("--", "-");

            retVal = temp;

            return retVal.ToLower();
        }
    }
}