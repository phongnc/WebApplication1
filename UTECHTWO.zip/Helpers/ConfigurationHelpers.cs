﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace UTECHTWO.Helpers
{
    public class ConfigurationValues
    {
        public static string SignInToken = "SSISINSPIWEBTOOL$2018";
    }
    public class ConfigurationHelpers
    {
    }
}