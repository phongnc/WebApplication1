﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Cryptography;
using System.Text;

namespace UTECHTWO.Helpers
{
    public class ApplicationHelpers
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes("#INSPIWEBTOOL" + text + "@SSIS"));
            byte[] result = md5.Hash;
            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }
        public static void SendMail(string toMail, string strSubject, string strContent, string fromMail)
        {
            try
            {
                using (System.Net.Mail.MailMessage objMailMessage = new System.Net.Mail.MailMessage())
                {
                    objMailMessage.From = new System.Net.Mail.MailAddress(fromMail, "loadkeypub");
                    objMailMessage.To.Add(new System.Net.Mail.MailAddress(toMail, "Valued Customer"));
                    objMailMessage.Subject = strSubject;
                    objMailMessage.IsBodyHtml = true;
                    objMailMessage.BodyEncoding = System.Text.Encoding.Unicode;
                    objMailMessage.Body = strContent;
                    System.Net.NetworkCredential credential = new System.Net.NetworkCredential(fromMail, "1q2w3e4r!@#");
                    System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient("smtp.zoho.com", 587);
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = credential;
                    smtpClient.EnableSsl = true;
                    smtpClient.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    try
                    {
                        smtpClient.Send(objMailMessage);
                    }
                    catch (Exception ex) { }
                }
            }
            catch (Exception ex) { }
        }
    }
}