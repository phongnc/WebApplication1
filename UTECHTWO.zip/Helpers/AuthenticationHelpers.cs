﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Net.Http;
using Newtonsoft.Json;
using UTECHTWO.Models.BO;

namespace UTECHTWO.Helpers
{
    public class AuthenticationHelpers
    {
        public static bool authenticating(string Email, string Password, bool RememberMe, HttpContextBase _currentHttpContext)
        {
            //try
            //{
            //    Models.DP.Model1 db = new Models.DP.Model1();
            //    string Hash = ApplicationHelpers.MD5Hash(Password);
            //    var auth = db.IPMUsers_Tb.Select("UserEmail = @Email AND UserPassword = @Password", new { Email = Email, Password = Password });
            //    if (auth.IPMUser_id > 0)
            //    {
            //        Models.BO.UserRecord user = new UserRecord()
            //        {
            //            UserRecordID = auth.IPMUser_id,
            //            UserRecordMD = 1,
            //            Email = auth.UserEmail,
            //            Title = auth.UserFullName,
            //            UserText = auth.UserName
            //        };
            //        setAuthCookie(_currentHttpContext, JsonConvert.SerializeObject(user));
            //        return true;
            //    }
            //}
            //catch (Exception ex) { }
            return false;
        }
        public static void setAuthCookie(HttpContextBase httpContext, string userData)
        {
            var authenticationTicket = new FormsAuthenticationTicket(1, ConfigurationValues.SignInToken, DateTime.Now, DateTime.Now.AddDays(1), true, userData);
            var encryptedTicket = FormsAuthentication.Encrypt(authenticationTicket);
            var cookie = new HttpCookie(ConfigurationValues.SignInToken, encryptedTicket);
            cookie.HttpOnly = true;
            //cookie.Secure = true;
            cookie.Expires = authenticationTicket.Expiration;
            httpContext.Response.Cookies.Add(cookie);
        }
        public static UserRecord CurrentUser(HttpContextBase _currentHttpContext)
        {
            UserRecord user = null;
            var signinTokenCookie = _currentHttpContext.Request.Cookies[ConfigurationValues.SignInToken];
            if (signinTokenCookie != null)
            {
                try
                {
                    var authenticationTicket = FormsAuthentication.Decrypt(signinTokenCookie.Value);
                    if (!authenticationTicket.Expired)
                        user = JsonConvert.DeserializeObject<UserRecord>(authenticationTicket.UserData);
                }
                catch (Exception)
                {
                    user = null;
                }
            }
            return user;
        }
        public static UserRecord ClientUser(HttpRequestMessage Request)
        {
            UserRecord user = null;
            try
            {
                var requestSignInTokenCookie = Request.Headers.GetCookies(ConfigurationValues.SignInToken).FirstOrDefault();
                for (int i = 0; i < requestSignInTokenCookie.Cookies.Count; i++)
                    if (requestSignInTokenCookie.Cookies[i].Name == ConfigurationValues.SignInToken)
                    {
                        var signinTokenCookie = requestSignInTokenCookie.Cookies[i];
                        if (signinTokenCookie != null)
                        {
                            try
                            {
                                var authenticationTicket = FormsAuthentication.Decrypt(signinTokenCookie.Value);
                                user = JsonConvert.DeserializeObject<UserRecord>(authenticationTicket.UserData);
                            }
                            catch (Exception)
                            {
                                user = null;
                            }
                        }
                    }
            }
            catch { }
            return user;
        }
        //public static Models.BO.AccountViewModel CurrentAccount(HttpContextBase _currentHttpContext)
        //{
        //    Models.BO.AccountViewModel acccount = new Models.BO.AccountViewModel();
        //    UserRecord user = CurrentUser(_currentHttpContext);
        //    if (user != null)
        //    {
        //        Models.DP.Model1 db = new Models.DP.Model1();
        //        AuthRecord auth = db.AuthRecords.Select("AuthRecordID = @AuthRecordID", new { AuthRecordID = user.UserRecordFD });
        //        acccount.Title = user.Title;
        //        acccount.Email = user.Email;
        //        acccount.AuthFromDate = auth.AuthRecordFD;
        //        acccount.AuthEndDate = auth.AuthRecordED;
        //        acccount.AccountType = ApplicationHelpers.AccountTypeTitle((int)auth.AuthValue.Value);
        //    }
        //    return acccount;
        //}
        public static bool checkLogIn(HttpContextBase _curentHttpContext)
        {
            var signinTokenCookie = _curentHttpContext.Request.Cookies[ConfigurationValues.SignInToken];
            if (signinTokenCookie != null && signinTokenCookie.Value != "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static void logOff(HttpContextBase httpContext)
        {
            var cookie = new HttpCookie(ConfigurationValues.SignInToken);
            DateTime nowDateTime = DateTime.Now;
            cookie.Expires = nowDateTime.AddDays(-1);
            httpContext.Response.Cookies.Add(cookie);
        }
    }
}