﻿//var gBizID = gBID; var gUserID = gUID; var gChucDanhID = gTID;
var gBizID = 1; var gUserID = 1; var gChucDanhID = 1;
function init(ctrl) {
    ctrl.org = "http://" + window.location.hostname + (((window.location.port)) ? (":" + window.location.port) : "") + vDir + "/";
    ctrl.api = ctrl.org + "api/";
    ctrl.url = ctrl.api + ctrl.name + "/";
    ctrl.src = ctrl.api + "Search" + ctrl.name + "/";
    ctrl.froala = [];
    //ctrl.fil = function (obj) { ctrl.skip = obj.skip; ctrl.take = obj.take; }
    //ctrl.local: local datasorce, ctrl.fil: remote load datasource agrs, ctrl.assign: update datasource, ctrl.def: init default value on create
    function doEvent(eventName) {
        console.log(eventName);
    }
    ctrl.datasource = new DevExpress.data.CustomStore({
        load: function (loadOptions) {
            var deferred = $.Deferred(),
                args = {};
            if (loadOptions.sort) {
                args.orderby = loadOptions.sort[0].selector;
                if (loadOptions.sort[0].desc)
                    args.orderby += " desc";
            }
            if (typeof _searchData !== 'undefined') args = _searchData;
            args.skip = loadOptions.skip || 0;
            args.take = loadOptions.take || 1000;
            if (ctrl.fil) ctrl.fil(args);
            if (ctrl.local) deferred.resolve(ctrl.local, { totalCount: 1 });
            else if (typeof _searchData !== 'undefined') {
                $.ajax({
                    url: ctrl.src,
                    data: args,
                    method: "PUT",
                    success: function (result) {
                        deferred.resolve(result.ResultList, { totalCount: result.ResultCount });
                    },
                    error: function () {
                        deferred.reject("Data Loading Error");
                    },
                    timeout: 100000
                });
            }
            else
                $.ajax({
                    url: ctrl.url,
                    data: args,
                    success: function (result) {
                        deferred.resolve(result.ResultList, { totalCount: result.ResultCount });
                    },
                    error: function () {
                        deferred.reject("Data Loading Error");
                    },
                    timeout: 100000
                });
            return deferred.promise();
        },
        byKey: function (key) {
            return $.getJSON(ctrl.url + encodeURIComponent(key));
        },
        insert: function (values) {
            if (ctrl.assig) ctrl.assig(values);
            return $.post(ctrl.url, values);
        },
        update: function (key, values) {
            if (ctrl.assign) { ctrl.assign(key, values); } else Object.assign(key, values);
            if (ctrl.assig) ctrl.assig(key);
            return $.ajax({
                url: ctrl.url + encodeURIComponent(ctrl.key(key)),
                method: "PUT",
                data: key
            });
        },
        remove: function (key) {
            return $.ajax({
                url: ctrl.url + encodeURIComponent(ctrl.key(key)),
                method: "DELETE",
            });
        }
    });
    //if (initMore) initMore(ctrl);
}
function bind(ctrl) {
    $("#gridContainer").dxDataGrid({
        dataSource: {
            store: ctrl.datasource
        },
        "export": {
            enabled: false,
            fileName: "export_" + ctrl.name,
            allowExportSelectedData: true
        },
        columnChooser: {
            enabled: false
        },
        rowAlternationEnabled: true,
        //columnHidingEnabled: true,
        showBorders: true,
        remoteOperations: {
            sorting: true,
            paging: true
        },
        filterRow: {
            visible: false
        },
        groupPanel: {
            visible: false
        },
        paging: {
            pageSize: 10
        },
        pager: {
            showPageSizeSelector: true,
            allowedPageSizes: [10, 20, 50],
            showInfo: true
        },
        editing: {
            mode: "popup",
            allowUpdating: true,
            allowDeleting: true,
            allowAdding: true,
            form: {
                labelLocation: "top"
            },
            popup: {
                columns: 1,
                width: 720,
                height: "auto"
            }
        },
        onToolbarPreparing: function (e) {
            //var dataGrid = e.component;
            //e.toolbarOptions.items.unshift({
            //    location: "after",
            //    widget: "dxButton",
            //    options: {
            //        icon: "upload",
            //        onClick: function () {
            //            console.log(ctrl.name);
            //            dataGrid.refresh();
            //        }
            //    }
            //});
            if (!(typeof ctrl.onToolbarPreparing == 'undefined' || !ctrl.onToolbarPreparing)) {
                return ctrl.onToolbarPreparing(e);
            }
        },
        onExporting: function (e) {
            if (!(typeof ctrl.onExporting == 'undefined' || !ctrl.onExporting)) {
                return ctrl.onExporting(e);
            }
        },
        onExported: function (e) {
            if (!(typeof ctrl.onExported == 'undefined' || !ctrl.onExported)) {
                return ctrl.onExported(e);
            }
        },
        onEditorPreparing: function (e) {
            if (e.editorWith == "dxTextArea")
                e.editorName = "dxTextArea";
            if (e.editorWith == "dxFileUploader") {
                e.editorName = "dxFileUploader";
                // use fraola for server explorer
                e.editorOptions = {
                    selectButtonText: "Select photo",
                    labelText: "",
                    accept: "image/*",
                    multiple: true,
                    uploadMode: "useForm"
                };
            }
            if (e.editorWith == "dxHtmlEditor") {
                e.editorName = "dxTextArea";
            }
        },
        onEditorPrepared: function (e) {
            if (e.editorWith == "dxHtmlEditor") {
                var $editor = e.editorElement.find("textarea");
                ctrl.froala[e.id] = e;
                $editor.froalaEditor({
                    toolbarButtons: ['bold', 'italic', 'underline', '|', 'fontFamily', 'fontSize', 'outdent', 'indent', 'clearFormatting', '|', 'insertImage', 'insertTable', 'html'],
                    charCounterCount: false,
                }).on('froalaEditor.contentChanged', function (obj, editor) {
                    ctrl.froala[editor.$oel[0].id].setValue(editor.html.get());
                }).on('froalaEditor.commands.after', function (e, editor, cmd, param1, param2) {
                    if (cmd == "html") { }
                });
            }
        },
        onCellPrepared: function (e) {
            cmdCustomize(e);
        },
        columns: ctrl.columns,
        onEditingStart: function (e) {
            doEvent("EditingStart");
        },
        onInitNewRow: function (e) {
            e.data.BizID = gBizID;
            e.data.Visible = true;
            e.data.IsDelete = false;
            e.data.BitValue = false;
            e.data.TitValue = '';
            if (ctrl.def) ctrl.def(e);
            doEvent("InitNewRow");
        },
        onRowInserting: function (e) {
            doEvent("RowInserting");
        },
        onRowInserted: function (e) {
            doEvent("RowInserted");
        },
        onRowUpdating: function (e) {
            doEvent("RowUpdating");
        },
        onRowUpdated: function (e) {
            doEvent("RowUpdated");
        },
        onRowRemoving: function (e) {
            doEvent("RowRemoving");
        },
        onRowRemoved: function (e) {
            doEvent("RowRemoved");
        },
        onContentReady: function (e) {
            if (!(typeof ctrl.onContentReady == 'undefined' || !ctrl.onContentReady)) {
                return ctrl.onContentReady(e);
            }
        }
    }).dxDataGrid("instance");
    if (ctrl.masterDetail !== undefined) { $("#gridContainer").dxDataGrid({ masterDetail: ctrl.masterDetail }); }
    if (ctrl.search !== undefined) { ctrl.search(); }
    if (ctrl.customize !== undefined) { ctrl.customize(); }
    //if (bindMore) bindMore(ctrl);
}
$(function () {
    if (typeof ctrl.initEDS == 'undefined' || !ctrl.initEDS) {
        dump(ctrl);
        init(ctrl);
        bind(ctrl);
        if (!(typeof initSearch == 'undefined' || !initSearch)) { initSearch(); }
    }
    else {
        ctrl.initEDS(function () {
            dump(ctrl);
            init(ctrl);
            bind(ctrl);
            if (!(typeof initSearch == 'undefined' || !initSearch)) { initSearch(); }
        });
    }
});
