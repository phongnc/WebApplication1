﻿var dicModel2 = [
    { "key": "SanPhamX.SanPhamMD", "value": "SanPhamX.SanPhamMD!" },
    { "key": "SanPhamX.MaSanPham", "value": "SanPhamX.MaSanPham!" },
    { "key": "SanPhamX.TenSanPham", "value": "SanPhamX.TenSanPham!" },
    { "key": "SanPhamX.DonVi", "value": "SanPhamX.DonVi!" },
    { "key": "SanPhamX.IsDelete", "value": "SanPhamX.IsDelete!" },
];
gooDics = gooDics.concat(dicModel2);
