﻿function createColumn(data) {
    Object.keys(data).forEach(function (key) {
        console.log(key);
        console.log(data[key]);
    });
}