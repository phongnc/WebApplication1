﻿function doEvent(eventName) {
    console.log(eventName);
}
function colVisible(element, info) {
    (info && info.value !== null) ? (info.value ? element.append("<div>" + "Đang sử dụng" + "</div>").css("color", "blue") : element.append("<div>" + "Đã xóa" + "</div>").css("color", "red")) : element.append("<div>" + "null" + "</div>").css("color", "orange");
}
function colIsDelete(element, info) {
    (info && info.value !== null) ? (info.value ? element.append("<div>" + "Đã xóa" + "</div>").css("color", "red") : element.append("<div>" + "Đang sử dụng" + "</div>").css("color", "blue")) : element.append("<div>" + "null" + "</div>").css("color", "orange");
}
function colBitValue(element, info) {
    (info && info.value !== null) ? (info.value ? element.append("<div>" + "Đã xóa" + "</div>").css("color", "red") : element.append("<div>" + "Đang sử dụng" + "</div>").css("color", "blue")) : element.append("<div>" + "null" + "</div>").css("color", "orange");
}
function cmdCustomize(e) {
    if (e.rowType === "data" && e.column.command === "edit") {
        var btns = $('.dx-popup-normal').find('.dx-button-text');
        var $linkedit = e.cellElement.find(".dx-link-edit"); $linkedit.text("Sửa");
        var $linkdelete = e.cellElement.find(".dx-link-delete"); $linkdelete.text("Xóa")
        try {
            if (e.row.data.Visible !== undefined) if (!e.row.data.Visible) { $linkedit.text(""); $linkdelete.text("Khôi phục"); }
        } catch (e) { };
        try {
            if (e.row.data.IsDelete !== undefined) if (e.row.data.IsDelete) { $linkedit.text(""); $linkdelete.text("Khôi phục"); }
        } catch (e) { };
        try {
            if (e.row.data.BitValue !== undefined) if (e.row.data.BitValue) { $linkedit.text(""); $linkdelete.text("Khôi phục"); }
        } catch (e) { };
        $linkdelete.on('click', function () {
            setTimeout(function () {
                var btns = $('.dx-popup-normal').find('.dx-dialog-message').first().text(($linkdelete.text() == "Xóa") ? "Bạn muốn xóa dữ liệu này?" : "Bạn muốn khôi phục dữ liệu này?");
            }, 0);
        });
    }
}
function regValue(value, field) {
    var regexTitle = /[!#$%^&*`~=|\\{}:;"'<>?]/;
    var regexDigit = /[\d]/;
    if (field == "Title")
        if (regexTitle.test(value)) { return false; }
    if (field == "Digit")
        if (!regexDigit.test(value)) { return false; }
    return true;
}
function getUrl() {
    return "http://" + window.location.hostname + (((window.location.port)) ? (":" + window.location.port) : "") + vDir + "/";
}
function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;
    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
}
function _selectedEDS(data, ref) {
    return data.filter(function (data) { return ((data.EID == ref)) });
}
function _selectedEDS2(data, ref) {
    return data.filter(function (data) { return ((data.StringValue.indexOf(ref) >= 0)) });
    return data.filter(function (data) { return ((data.StringValue == ref)) });
}
function _selectedSLA(data, ref, slas) {
    var _xdata = data.filter(function (data) { return ((data.StringValue.indexOf(ref) >= 0)) });
    var _slas;
    if (ref == "CaseTypeID") {
        try {
            var _x1 = _data.VinCSTicketSLA.CaseGroupID;
            _slas = slas.filter(function (data) { return ((data.CaseGroupID == _x1)) }).map(x => x.CaseTypeID);
        } catch (e) { _slas = []; }
    }
    if (ref == "ProductIndustryID") {
        try {
            var _x1 = _data.VinCSTicketSLA.CaseGroupID; var _x2 = _data.VinCSTicketSLA.CaseTypeID;
            _slas = slas.filter(function (data) { return ((data.CaseGroupID == _x1) && (data.CaseTypeID == _x2)) }).map(x => x.ProductIndustryID);
        } catch (e) { _slas = []; }
    }
    if (ref == "ProductCategoryID") {
        try {
            var _x1 = _data.VinCSTicketSLA.CaseGroupID; var _x2 = _data.VinCSTicketSLA.CaseTypeID; var _x3 = _data.VinCSTicketSLA.ProductIndustryID;
            _slas = slas.filter(function (data) { return ((data.CaseGroupID == _x1) && (data.CaseTypeID == _x2) && (data.ProductIndustryID == _x3)) }).map(x => x.ProductCategoryID);
        } catch (e) { _slas = []; }
    }
    return _xdata.filter(function (_data) { return ((_slas.indexOf(_data.IID) >= 0)) });
}
function edsTrans(data, text) {
    try {
        var x = data.filter(function (data) { return ((data.key == text)) });
        if (x[0].value) return x[0].value;
        else return text + "!";
    } catch (e) { return text + "!"; }
}
function gooTrans(text) {
    try {
        try { text = startDics(text); } catch (e) { }
        var x = gooDics.filter(function (data) { return ((data.key == text)) });
        if (x[0].value) return x[0].value;
        else {
            return text + "!";
        }
    } catch (e) {
        if (text.indexOf(" ") == -1) {
            var _tran1 = endDics(text); if (_tran1 !== text) return _tran1;
        }
        return text + "!";
    }
}
function _colName(data, ref) {
    try {
        var x = data.filter(function (data) { return ((data.ID == ref)) });
        if (x[0].Name) return gooTrans(x[0].Name);
        else return gooTrans(ref);
    } catch (e) { return gooTrans(ref); }
}
function _colShow(data, ref, prop) {
    try {
        var x = data.filter(function (data) { return ((data.ID == ref)) });
        if (x[0].Name) {
            try {
                if (prop == 0) { return x[0].gShow; }
                if (prop == 1) { return x[0].fShow; }
                return false;
            } catch (e) { return true; }
        }
    } catch (e) { return false; }
}
function _colStatus(data, statusid)
{
    var _status = data.filter(function (data) { return ((data.IID == statusid)) })[0];
    var status = _status.TitValue;
    if (status.indexOf("Mới tạo") >= 0)
        return "'btn btn-sm btn-success btn-outline'";
    else if (status.indexOf("Chuyển giải quyết") >= 0)
        return "'btn btn-sm btn-primary btn-outline'";
    else if (status.indexOf("Đang giải quyết") >= 0)
        return "'btn btn-sm btn-info btn-outline'";
    else if (status.indexOf("Hoàn thành") >= 0)
        return "'btn btn-sm btn-basic btn-outline'";
    else if (status.indexOf("Đóng") >= 0)
        return "'btn btn-sm btn-default btn-outline'";
}
