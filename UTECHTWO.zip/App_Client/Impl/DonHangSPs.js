﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=DonHangSP",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.DonHangSPID; },
    name: "DonHangSPs",
    columns: [
        {
            dataField: "DonHangID",
            caption: gooTrans("DonHangSP.DonHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "DonHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            caption: gooTrans("DonHangSP.SanPhamID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            caption: gooTrans("DonHangSP.SoLuong"),
        },
        {
            dataField: "DonGia",
            caption: gooTrans("DonHangSP.DonGia"),
        },
        {
            dataField: "TrangThai",
            caption: gooTrans("DonHangSP.TrangThai"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("DonHangSP.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
