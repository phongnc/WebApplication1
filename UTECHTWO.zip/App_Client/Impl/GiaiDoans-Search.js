﻿
function _giaidoan_form(_searchData, cols, isNew) {
    $("#formGiaiDoan").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "MaGiaiDoan",
            label: { text: gooTrans("GiaiDoan.MaGiaiDoan"), },
        },
        {
            dataField: "BatDau",
            label: { text: gooTrans("GiaiDoan.BatDau"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "KetThuc",
            label: { text: gooTrans("GiaiDoan.KetThuc"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
