﻿
function _spinfo_form(data, cols, isNew) {
    $("#formSPInfo").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("SPInfo.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaCungCapID",
            label: { text: gooTrans("SPInfo.NhaCungCapID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "TenSanXuat",
            label: { text: gooTrans("SPInfo.TenSanXuat"), },
        },
        {
            dataField: "SanLuong",
            label: { text: gooTrans("SPInfo.SanLuong"), },
        },
        {
            dataField: "NongDoMauSac",
            label: { text: gooTrans("SPInfo.NongDoMauSac"), },
        },
        {
            dataField: "KhoiLuongDungLuong",
            label: { text: gooTrans("SPInfo.KhoiLuongDungLuong"), },
        },
        {
            dataField: "ChungLoaiVoChua",
            label: { text: gooTrans("SPInfo.ChungLoaiVoChua"), },
        },
        {
            dataField: "PhanPhoiSanXuat",
            label: { text: gooTrans("SPInfo.PhanPhoiSanXuat"), },
        },
        {
            dataField: "GhiChu",
            label: { text: gooTrans("SPInfo.GhiChu"), },
        },
        {
            dataField: "JsonData",
            label: { text: gooTrans("SPInfo.JsonData"), },
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo SPInfo",
        type: "success",
        onClick: function (e) {
            var values = $("#formSPInfo").dxForm("instance")._options.formData;
			if (values.SPInfoID == 0) {
			    return $.post(vDir + "/api/SPInfoes/", values).done(function (x) {
			        location.href = vDir + "/SPInfoes/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/SPInfoes/" + encodeURIComponent(values.SPInfoID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/SPInfoes/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo SPInfo"); 
        }
    });
};
