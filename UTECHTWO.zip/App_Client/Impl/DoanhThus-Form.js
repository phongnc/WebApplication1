﻿
function _doanhthu_form(data, cols, isNew) {
    $("#formDoanhThu").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "DonHangSPID",
            label: { text: gooTrans("DoanhThu.DonHangSPID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "DonHangSPID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "DoanhThuDuKien",
            label: { text: gooTrans("DoanhThu.DoanhThuDuKien"), },
        },
        {
            dataField: "DoanhThuHoaDon",
            label: { text: gooTrans("DoanhThu.DoanhThuHoaDon"), },
        },
        {
            dataField: "DoanhThuThucTe",
            label: { text: gooTrans("DoanhThu.DoanhThuThucTe"), },
        },
        {
            dataField: "GhiChu",
            label: { text: gooTrans("DoanhThu.GhiChu"), },
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo DoanhThu",
        type: "success",
        onClick: function (e) {
            var values = $("#formDoanhThu").dxForm("instance")._options.formData;
			if (values.DoanhThuID == 0) {
			    return $.post(vDir + "/api/DoanhThus/", values).done(function (x) {
			        location.href = vDir + "/DoanhThus/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/DoanhThus/" + encodeURIComponent(values.DoanhThuID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/DoanhThus/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo DoanhThu"); 
        }
    });
};
