﻿
function _doanhthu_form(_searchData, cols, isNew) {
    $("#formDoanhThu").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "DonHangSPID",
            label: { text: gooTrans("DoanhThu.DonHangSPID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "DonHangSPID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "DoanhThuDuKien",
            label: { text: gooTrans("DoanhThu.DoanhThuDuKien"), },
        },
        {
            dataField: "DoanhThuHoaDon",
            label: { text: gooTrans("DoanhThu.DoanhThuHoaDon"), },
        },
        {
            dataField: "DoanhThuThucTe",
            label: { text: gooTrans("DoanhThu.DoanhThuThucTe"), },
        },
        {
            dataField: "GhiChu",
            label: { text: gooTrans("DoanhThu.GhiChu"), },
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
