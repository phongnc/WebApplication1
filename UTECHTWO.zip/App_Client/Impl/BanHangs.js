﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=BanHang",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.BanHangID; },
    name: "BanHangs",
    columns: [
        {
            dataField: "Title",
            caption: gooTrans("BanHang.Title"),
            validationRules: [
            { type: 'required', message: 'Không được để trống' },
            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },
            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }
            ],
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.Title)
                    .on('dxclick', function () {
                        window.open(vDir + '/BanHangs/Edit?id=' + options.data.BanHangID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "KhachHangID",
            caption: gooTrans("BanHang.KhachHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "LoaiDonHang",
            caption: gooTrans("BanHang.LoaiDonHang"),
        },
        {
            dataField: "GiaiDoanID",
            caption: gooTrans("BanHang.GiaiDoanID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NguoiDatHang",
            caption: gooTrans("BanHang.NguoiDatHang"),
        },
        {
            dataField: "MaBoPhan",
            caption: gooTrans("BanHang.MaBoPhan"),
        },
        {
            dataField: "TyGia",
            caption: gooTrans("BanHang.TyGia"),
        },
        {
            dataField: "LoaiChietKhau",
            caption: gooTrans("BanHang.LoaiChietKhau"),
        },
        {
            dataField: "DienGiai",
            caption: gooTrans("BanHang.DienGiai"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("BanHang.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
    ctrl.onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "addRowButton") {
                item.options.onClick = function (e) {
                    window.open(vDir + '/BanHangs/Create', '_blank');
                }
            }
        });
    }
};
