﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=DoanhThu",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.DoanhThuID; },
    name: "DoanhThus",
    columns: [
        {
            dataField: "DonHangSPID",
            caption: gooTrans("DoanhThu.DonHangSPID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "DonHangSPID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "DoanhThuDuKien",
            caption: gooTrans("DoanhThu.DoanhThuDuKien"),
        },
        {
            dataField: "DoanhThuHoaDon",
            caption: gooTrans("DoanhThu.DoanhThuHoaDon"),
        },
        {
            dataField: "DoanhThuThucTe",
            caption: gooTrans("DoanhThu.DoanhThuThucTe"),
        },
        {
            dataField: "GhiChu",
            caption: gooTrans("DoanhThu.GhiChu"),
        },
    ]
    };
};
