﻿
function _dosanpham_form(_searchData, cols, isNew) {
    $("#formDOSanPham").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            itemType: "group",
            caption: "USanPham",
            items: [
        {
            dataField: "USanPham.SanPhamMD",
            label: { text: gooTrans("USanPham.SanPham.SanPhamMD"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamMD"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USanPham.MaSanPham",
            label: { text: gooTrans("USanPham.SanPham.MaSanPham"), },
        },
        {
            dataField: "USanPham.TenSanPham",
            label: { text: gooTrans("USanPham.SanPham.TenSanPham"), },
        },
        {
            dataField: "USanPham.DonVi",
            label: { text: gooTrans("USanPham.SanPham.DonVi"), },
        },
        {
            dataField: "USanPham.IsDelete",
            label: { text: gooTrans("USanPham.SanPham.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
            ],
        },
        {
            itemType: "group",
            caption: "USPInfo",
            items: [
        {
            dataField: "USPInfo.SanPhamID",
            label: { text: gooTrans("USPInfo.SPInfo.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPInfo.NhaCungCapID",
            label: { text: gooTrans("USPInfo.SPInfo.NhaCungCapID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPInfo.TenSanXuat",
            label: { text: gooTrans("USPInfo.SPInfo.TenSanXuat"), },
        },
        {
            dataField: "USPInfo.SanLuong",
            label: { text: gooTrans("USPInfo.SPInfo.SanLuong"), },
        },
        {
            dataField: "USPInfo.NongDoMauSac",
            label: { text: gooTrans("USPInfo.SPInfo.NongDoMauSac"), },
        },
        {
            dataField: "USPInfo.KhoiLuongDungLuong",
            label: { text: gooTrans("USPInfo.SPInfo.KhoiLuongDungLuong"), },
        },
        {
            dataField: "USPInfo.ChungLoaiVoChua",
            label: { text: gooTrans("USPInfo.SPInfo.ChungLoaiVoChua"), },
        },
        {
            dataField: "USPInfo.PhanPhoiSanXuat",
            label: { text: gooTrans("USPInfo.SPInfo.PhanPhoiSanXuat"), },
        },
        {
            dataField: "USPInfo.GhiChu",
            label: { text: gooTrans("USPInfo.SPInfo.GhiChu"), },
        },
        {
            dataField: "USPInfo.JsonData",
            label: { text: gooTrans("USPInfo.SPInfo.JsonData"), },
            visible: false,
        },
            ],
        },
        {
            itemType: "group",
            caption: "USPImage",
            items: [
        {
            dataField: "USPImage.SanPhamID",
            label: { text: gooTrans("USPImage.SPImage.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPImage.SPImageMoreID",
            label: { text: gooTrans("USPImage.SPImage.SPImageMoreID"), },
        },
        {
            dataField: "USPImage.MatTruoc",
            label: { text: gooTrans("USPImage.SPImage.MatTruoc"), },
        },
        {
            dataField: "USPImage.MatSau",
            label: { text: gooTrans("USPImage.SPImage.MatSau"), },
        },
        {
            dataField: "USPImage.MatTren",
            label: { text: gooTrans("USPImage.SPImage.MatTren"), },
        },
        {
            dataField: "USPImage.DongGoi1",
            label: { text: gooTrans("USPImage.SPImage.DongGoi1"), },
        },
        {
            dataField: "USPImage.DongGoi2",
            label: { text: gooTrans("USPImage.SPImage.DongGoi2"), },
        },
        {
            dataField: "USPImage.AnhKhac",
            label: { text: gooTrans("USPImage.SPImage.AnhKhac"), },
        },
            ],
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
