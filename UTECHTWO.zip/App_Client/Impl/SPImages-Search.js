﻿
function _spimage_form(_searchData, cols, isNew) {
    $("#formSPImage").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("SPImage.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SPImageMoreID",
            label: { text: gooTrans("SPImage.SPImageMoreID"), },
        },
        {
            dataField: "MatTruoc",
            label: { text: gooTrans("SPImage.MatTruoc"), },
        },
        {
            dataField: "MatSau",
            label: { text: gooTrans("SPImage.MatSau"), },
        },
        {
            dataField: "MatTren",
            label: { text: gooTrans("SPImage.MatTren"), },
        },
        {
            dataField: "DongGoi1",
            label: { text: gooTrans("SPImage.DongGoi1"), },
        },
        {
            dataField: "DongGoi2",
            label: { text: gooTrans("SPImage.DongGoi2"), },
        },
        {
            dataField: "AnhKhac",
            label: { text: gooTrans("SPImage.AnhKhac"), },
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
