﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=SPInfo",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.SPInfoID; },
    name: "SPInfoes",
    columns: [
        {
            dataField: "SanPhamID",
            caption: gooTrans("SPInfo.SanPhamID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaCungCapID",
            caption: gooTrans("SPInfo.NhaCungCapID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "TenSanXuat",
            caption: gooTrans("SPInfo.TenSanXuat"),
        },
        {
            dataField: "SanLuong",
            caption: gooTrans("SPInfo.SanLuong"),
        },
        {
            dataField: "NongDoMauSac",
            caption: gooTrans("SPInfo.NongDoMauSac"),
        },
        {
            dataField: "KhoiLuongDungLuong",
            caption: gooTrans("SPInfo.KhoiLuongDungLuong"),
        },
        {
            dataField: "ChungLoaiVoChua",
            caption: gooTrans("SPInfo.ChungLoaiVoChua"),
        },
        {
            dataField: "PhanPhoiSanXuat",
            caption: gooTrans("SPInfo.PhanPhoiSanXuat"),
        },
        {
            dataField: "GhiChu",
            caption: gooTrans("SPInfo.GhiChu"),
        },
        {
            dataField: "JsonData",
            caption: gooTrans("SPInfo.JsonData"),
            visible: false,
            formItem: { visible: false },
        },
    ]
    };
};
