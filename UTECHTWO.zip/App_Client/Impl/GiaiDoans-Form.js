﻿
function _giaidoan_form(data, cols, isNew) {
    $("#formGiaiDoan").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "MaGiaiDoan",
            label: { text: gooTrans("GiaiDoan.MaGiaiDoan"), },
        },
        {
            dataField: "BatDau",
            label: { text: gooTrans("GiaiDoan.BatDau"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "KetThuc",
            label: { text: gooTrans("GiaiDoan.KetThuc"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo GiaiDoan",
        type: "success",
        onClick: function (e) {
            var values = $("#formGiaiDoan").dxForm("instance")._options.formData;
			if (values.GiaiDoanID == 0) {
			    return $.post(vDir + "/api/GiaiDoans/", values).done(function (x) {
			        location.href = vDir + "/GiaiDoans/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/GiaiDoans/" + encodeURIComponent(values.GiaiDoanID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/GiaiDoans/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo GiaiDoan"); 
        }
    });
};
