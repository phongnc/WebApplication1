﻿
function _khachhang_form(_searchData, cols, isNew) {
    $("#formKhachHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "MaKhachHang",
            label: { text: gooTrans("KhachHang.MaKhachHang"), },
        },
        {
            dataField: "TenKhachHang",
            label: { text: gooTrans("KhachHang.TenKhachHang"), },
        },
        {
            dataField: "DiaChi",
            label: { text: gooTrans("KhachHang.DiaChi"), },
        },
        {
            dataField: "MST",
            label: { text: gooTrans("KhachHang.MST"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("KhachHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
