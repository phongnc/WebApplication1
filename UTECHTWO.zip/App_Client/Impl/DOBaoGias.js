﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=BaoGia,BanHang,",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.UBaoGia.BaoGiaID; },
    assign: function (key, values) { Object.assign(key.UBaoGia, values.UBaoGia);Object.assign(key.UBanHang, values.UBanHang); },
    name: "DOBaoGias",
    search: function() { return _dobaogia_search(); },
    columns: [
        {
            dataField: "UBaoGia.BanHangID",
            caption: gooTrans("UBaoGia.BaoGia.BanHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBaoGia.MaBaoGia",
            caption: gooTrans("UBaoGia.BaoGia.MaBaoGia"),
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.UBaoGia.MaBaoGia)
                    .on('dxclick', function () {
                        window.open(vDir + '/DOBaoGias/Edit?id=' + options.data.UBaoGia.BaoGiaID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "UBaoGia.NgayBaoGia",
            caption: gooTrans("UBaoGia.BaoGia.NgayBaoGia"),
            dataType: "datetime",
        },
        {
            dataField: "UBaoGia.LanSuaDoi",
            caption: gooTrans("UBaoGia.BaoGia.LanSuaDoi"),
        },
        {
            dataField: "UBaoGia.TrangThai",
            caption: gooTrans("UBaoGia.BaoGia.TrangThai"),
        },
        {
            dataField: "UBaoGia.CreatedDate",
            caption: gooTrans("UBaoGia.BaoGia.CreatedDate"),
            dataType: "datetime",
        },
        {
            dataField: "UBaoGia.ModifiedDate",
            caption: gooTrans("UBaoGia.BaoGia.ModifiedDate"),
            dataType: "datetime",
        },
        {
            dataField: "UBaoGia.CreatedUID",
            caption: gooTrans("UBaoGia.BaoGia.CreatedUID"),
        },
        {
            dataField: "UBaoGia.ModifiedUID",
            caption: gooTrans("UBaoGia.BaoGia.ModifiedUID"),
        },
        {
            dataField: "UBaoGia.IsDelete",
            caption: gooTrans("UBaoGia.BaoGia.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
        {
            dataField: "UBanHang.Title",
            caption: gooTrans("UBanHang.BanHang.Title"),
            validationRules: [
            { type: 'required', message: 'Không được để trống' },
            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },
            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }
            ],
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.Title)
                    .on('dxclick', function () {
                        window.open(vDir + '/DOBaoGias/Edit?id=' + options.data.BanHangID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "UBanHang.KhachHangID",
            caption: gooTrans("UBanHang.BanHang.KhachHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.LoaiDonHang",
            caption: gooTrans("UBanHang.BanHang.LoaiDonHang"),
        },
        {
            dataField: "UBanHang.GiaiDoanID",
            caption: gooTrans("UBanHang.BanHang.GiaiDoanID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.NguoiDatHang",
            caption: gooTrans("UBanHang.BanHang.NguoiDatHang"),
        },
        {
            dataField: "UBanHang.MaBoPhan",
            caption: gooTrans("UBanHang.BanHang.MaBoPhan"),
        },
        {
            dataField: "UBanHang.TyGia",
            caption: gooTrans("UBanHang.BanHang.TyGia"),
        },
        {
            dataField: "UBanHang.LoaiChietKhau",
            caption: gooTrans("UBanHang.BanHang.LoaiChietKhau"),
        },
        {
            dataField: "UBanHang.DienGiai",
            caption: gooTrans("UBanHang.BanHang.DienGiai"),
        },
        {
            dataField: "UBanHang.IsDelete",
            caption: gooTrans("UBanHang.BanHang.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
    ctrl.onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "addRowButton") {
                item.options.onClick = function (e) {
                    window.open(vDir + '/DOBaoGias/Create', '_blank');
                }
            }
        });
    }
};
