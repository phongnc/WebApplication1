﻿
var ctrl = {}
function dump() {
    ctrl = {
    key: function(obj) { return obj.UserID; },
    name: "Users",
    columns: [
        {
            dataField: "Email",
            caption: gooTrans("User.Email"),
        },
        {
            dataField: "Password",
            caption: gooTrans("User.Password"),
        },
    ]
    };
};
