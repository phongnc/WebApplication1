﻿
function _khokhach_form(data, cols, isNew) {
    $("#formKhoKhach").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "KhachHangID",
            label: { text: gooTrans("KhoKhach.KhachHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("KhoKhach.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("KhoKhach.SoLuong"), },
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo KhoKhach",
        type: "success",
        onClick: function (e) {
            var values = $("#formKhoKhach").dxForm("instance")._options.formData;
			if (values.KhoKhachID == 0) {
			    return $.post(vDir + "/api/KhoKhaches/", values).done(function (x) {
			        location.href = vDir + "/KhoKhaches/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/KhoKhaches/" + encodeURIComponent(values.KhoKhachID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/KhoKhaches/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo KhoKhach"); 
        }
    });
};
