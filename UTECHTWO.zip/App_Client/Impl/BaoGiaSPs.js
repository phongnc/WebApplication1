﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=BaoGiaSP",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.BaoGiaSPID; },
    name: "BaoGiaSPs",
    columns: [
        {
            dataField: "BaoGiaID",
            caption: gooTrans("BaoGiaSP.BaoGiaID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "BaoGiaID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            caption: gooTrans("BaoGiaSP.SanPhamID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            caption: gooTrans("BaoGiaSP.SoLuong"),
        },
        {
            dataField: "DonGia",
            caption: gooTrans("BaoGiaSP.DonGia"),
        },
        {
            dataField: "TrangThai",
            caption: gooTrans("BaoGiaSP.TrangThai"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("BaoGiaSP.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
