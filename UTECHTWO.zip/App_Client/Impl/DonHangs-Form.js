﻿
function _donhang_form(data, cols, isNew) {
    $("#formDonHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "BanHangID",
            label: { text: gooTrans("DonHang.BanHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaDonHang",
            label: { text: gooTrans("DonHang.MaDonHang"), },
        },
        {
            dataField: "NgayDonHang",
            label: { text: gooTrans("DonHang.NgayDonHang"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "LanSuaDoi",
            label: { text: gooTrans("DonHang.LanSuaDoi"), },
        },
        {
            dataField: "TrangThai",
            label: { text: gooTrans("DonHang.TrangThai"), },
        },
        {
            dataField: "CreatedDate",
            label: { text: gooTrans("DonHang.CreatedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "ModifiedDate",
            label: { text: gooTrans("DonHang.ModifiedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "CreatedUID",
            label: { text: gooTrans("DonHang.CreatedUID"), },
        },
        {
            dataField: "ModifiedUID",
            label: { text: gooTrans("DonHang.ModifiedUID"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("DonHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo DonHang",
        type: "success",
        onClick: function (e) {
            var values = $("#formDonHang").dxForm("instance")._options.formData;
			if (values.DonHangID == 0) {
			    return $.post(vDir + "/api/DonHangs/", values).done(function (x) {
			        location.href = vDir + "/DonHangs/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/DonHangs/" + encodeURIComponent(values.DonHangID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/DonHangs/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo DonHang"); 
        }
    });
};
