﻿
var ctrl = {}
function dump() {
    ctrl = {
    key: function(obj) { return obj.KhoID; },
    name: "Khoes",
    columns: [
        {
            dataField: "MaKho",
            caption: gooTrans("Kho.MaKho"),
        },
        {
            dataField: "TenKho",
            caption: gooTrans("Kho.TenKho"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("Kho.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
