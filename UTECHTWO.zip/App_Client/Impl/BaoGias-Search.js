﻿
function _baogia_form(_searchData, cols, isNew) {
    $("#formBaoGia").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "BanHangID",
            label: { text: gooTrans("BaoGia.BanHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaBaoGia",
            label: { text: gooTrans("BaoGia.MaBaoGia"), },
        },
        {
            dataField: "NgayBaoGia",
            label: { text: gooTrans("BaoGia.NgayBaoGia"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "LanSuaDoi",
            label: { text: gooTrans("BaoGia.LanSuaDoi"), },
        },
        {
            dataField: "TrangThai",
            label: { text: gooTrans("BaoGia.TrangThai"), },
        },
        {
            dataField: "CreatedDate",
            label: { text: gooTrans("BaoGia.CreatedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "ModifiedDate",
            label: { text: gooTrans("BaoGia.ModifiedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "CreatedUID",
            label: { text: gooTrans("BaoGia.CreatedUID"), },
        },
        {
            dataField: "ModifiedUID",
            label: { text: gooTrans("BaoGia.ModifiedUID"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("BaoGia.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
