﻿
function _kho_form(data, cols, isNew) {
    $("#formKho").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "MaKho",
            label: { text: gooTrans("Kho.MaKho"), },
        },
        {
            dataField: "TenKho",
            label: { text: gooTrans("Kho.TenKho"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("Kho.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo Kho",
        type: "success",
        onClick: function (e) {
            var values = $("#formKho").dxForm("instance")._options.formData;
			if (values.KhoID == 0) {
			    return $.post(vDir + "/api/Khoes/", values).done(function (x) {
			        location.href = vDir + "/Khoes/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/Khoes/" + encodeURIComponent(values.KhoID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/Khoes/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo Kho"); 
        }
    });
};
