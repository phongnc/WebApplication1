﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=NhapHang",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.NhapHangID; },
    name: "NhapHangs",
    columns: [
        {
            dataField: "KhoID",
            caption: gooTrans("NhapHang.KhoID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "KhoID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            caption: gooTrans("NhapHang.SanPhamID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaCungCapID",
            caption: gooTrans("NhapHang.NhaCungCapID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaSanXuat",
            caption: gooTrans("NhapHang.NhaSanXuat"),
        },
        {
            dataField: "MaLoHang",
            caption: gooTrans("NhapHang.MaLoHang"),
        },
        {
            dataField: "SoLuong",
            caption: gooTrans("NhapHang.SoLuong"),
        },
        {
            dataField: "TonKho",
            caption: gooTrans("NhapHang.TonKho"),
        },
        {
            dataField: "DonGia",
            caption: gooTrans("NhapHang.DonGia"),
        },
        {
            dataField: "HanSuDung",
            caption: gooTrans("NhapHang.HanSuDung"),
        },
        {
            dataField: "NgayNhapHang",
            caption: gooTrans("NhapHang.NgayNhapHang"),
            dataType: "datetime",
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("NhapHang.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
