﻿
function _loaisanpham_form(data, cols, isNew) {
    $("#formLoaiSanPham").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "MaLoaiSanPham",
            label: { text: gooTrans("LoaiSanPham.MaLoaiSanPham"), },
        },
        {
            dataField: "TenLoaiSanPham",
            label: { text: gooTrans("LoaiSanPham.TenLoaiSanPham"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("LoaiSanPham.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo LoaiSanPham",
        type: "success",
        onClick: function (e) {
            var values = $("#formLoaiSanPham").dxForm("instance")._options.formData;
			if (values.LoaiSanPhamID == 0) {
			    return $.post(vDir + "/api/LoaiSanPhams/", values).done(function (x) {
			        location.href = vDir + "/LoaiSanPhams/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/LoaiSanPhams/" + encodeURIComponent(values.LoaiSanPhamID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/LoaiSanPhams/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo LoaiSanPham"); 
        }
    });
};
