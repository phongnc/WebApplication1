﻿
var ctrl = {}
function dump() {
    ctrl = {
    key: function(obj) { return obj.KhachHangID; },
    name: "KhachHangs",
    columns: [
        {
            dataField: "MaKhachHang",
            caption: gooTrans("KhachHang.MaKhachHang"),
        },
        {
            dataField: "TenKhachHang",
            caption: gooTrans("KhachHang.TenKhachHang"),
        },
        {
            dataField: "DiaChi",
            caption: gooTrans("KhachHang.DiaChi"),
        },
        {
            dataField: "MST",
            caption: gooTrans("KhachHang.MST"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("KhachHang.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
