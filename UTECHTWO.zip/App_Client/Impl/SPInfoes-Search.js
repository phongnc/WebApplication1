﻿
function _spinfo_form(_searchData, cols, isNew) {
    $("#formSPInfo").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("SPInfo.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaCungCapID",
            label: { text: gooTrans("SPInfo.NhaCungCapID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "TenSanXuat",
            label: { text: gooTrans("SPInfo.TenSanXuat"), },
        },
        {
            dataField: "SanLuong",
            label: { text: gooTrans("SPInfo.SanLuong"), },
        },
        {
            dataField: "NongDoMauSac",
            label: { text: gooTrans("SPInfo.NongDoMauSac"), },
        },
        {
            dataField: "KhoiLuongDungLuong",
            label: { text: gooTrans("SPInfo.KhoiLuongDungLuong"), },
        },
        {
            dataField: "ChungLoaiVoChua",
            label: { text: gooTrans("SPInfo.ChungLoaiVoChua"), },
        },
        {
            dataField: "PhanPhoiSanXuat",
            label: { text: gooTrans("SPInfo.PhanPhoiSanXuat"), },
        },
        {
            dataField: "GhiChu",
            label: { text: gooTrans("SPInfo.GhiChu"), },
        },
        {
            dataField: "JsonData",
            label: { text: gooTrans("SPInfo.JsonData"), },
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
