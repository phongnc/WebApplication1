﻿
function _xuathang_form(_searchData, cols, isNew) {
    $("#formXuatHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "NhapHangID",
            label: { text: gooTrans("XuatHang.NhapHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhapHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "DonHangSPID",
            label: { text: gooTrans("XuatHang.DonHangSPID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "DonHangSPID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("XuatHang.SoLuong"), },
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
