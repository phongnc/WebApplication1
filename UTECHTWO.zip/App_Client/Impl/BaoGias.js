﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=BaoGia",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.BaoGiaID; },
    name: "BaoGias",
    columns: [
        {
            dataField: "BanHangID",
            caption: gooTrans("BaoGia.BanHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaBaoGia",
            caption: gooTrans("BaoGia.MaBaoGia"),
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.MaBaoGia)
                    .on('dxclick', function () {
                        window.open(vDir + '/BaoGias/Edit?id=' + options.data.BaoGiaID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "NgayBaoGia",
            caption: gooTrans("BaoGia.NgayBaoGia"),
            dataType: "datetime",
        },
        {
            dataField: "LanSuaDoi",
            caption: gooTrans("BaoGia.LanSuaDoi"),
        },
        {
            dataField: "TrangThai",
            caption: gooTrans("BaoGia.TrangThai"),
        },
        {
            dataField: "CreatedDate",
            caption: gooTrans("BaoGia.CreatedDate"),
            dataType: "datetime",
        },
        {
            dataField: "ModifiedDate",
            caption: gooTrans("BaoGia.ModifiedDate"),
            dataType: "datetime",
        },
        {
            dataField: "CreatedUID",
            caption: gooTrans("BaoGia.CreatedUID"),
        },
        {
            dataField: "ModifiedUID",
            caption: gooTrans("BaoGia.ModifiedUID"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("BaoGia.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
    ctrl.onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "addRowButton") {
                item.options.onClick = function (e) {
                    window.open(vDir + '/BaoGias/Create', '_blank');
                }
            }
        });
    }
};
