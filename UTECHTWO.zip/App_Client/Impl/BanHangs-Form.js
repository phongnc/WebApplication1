﻿
function _banhang_form(data, cols, isNew) {
    $("#formBanHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "Title",
            label: { text: gooTrans("BanHang.Title"), },
            validationRules: [
            { type: 'required', message: 'Không được để trống' },
            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },
            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }
            ],
        },
        {
            dataField: "KhachHangID",
            label: { text: gooTrans("BanHang.KhachHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "LoaiDonHang",
            label: { text: gooTrans("BanHang.LoaiDonHang"), },
        },
        {
            dataField: "GiaiDoanID",
            label: { text: gooTrans("BanHang.GiaiDoanID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NguoiDatHang",
            label: { text: gooTrans("BanHang.NguoiDatHang"), },
        },
        {
            dataField: "MaBoPhan",
            label: { text: gooTrans("BanHang.MaBoPhan"), },
        },
        {
            dataField: "TyGia",
            label: { text: gooTrans("BanHang.TyGia"), },
        },
        {
            dataField: "LoaiChietKhau",
            label: { text: gooTrans("BanHang.LoaiChietKhau"), },
        },
        {
            dataField: "DienGiai",
            label: { text: gooTrans("BanHang.DienGiai"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("BanHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo BanHang",
        type: "success",
        onClick: function (e) {
            var values = $("#formBanHang").dxForm("instance")._options.formData;
			if (values.BanHangID == 0) {
			    return $.post(vDir + "/api/BanHangs/", values).done(function (x) {
			        location.href = vDir + "/BanHangs/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/BanHangs/" + encodeURIComponent(values.BanHangID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/BanHangs/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo BanHang"); 
        }
    });
};
