﻿
function _kho_form(_searchData, cols, isNew) {
    $("#formKho").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "MaKho",
            label: { text: gooTrans("Kho.MaKho"), },
        },
        {
            dataField: "TenKho",
            label: { text: gooTrans("Kho.TenKho"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("Kho.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
