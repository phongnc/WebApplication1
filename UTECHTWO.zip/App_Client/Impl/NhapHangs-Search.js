﻿
function _nhaphang_form(_searchData, cols, isNew) {
    $("#formNhapHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "KhoID",
            label: { text: gooTrans("NhapHang.KhoID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "KhoID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("NhapHang.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaCungCapID",
            label: { text: gooTrans("NhapHang.NhaCungCapID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaSanXuat",
            label: { text: gooTrans("NhapHang.NhaSanXuat"), },
        },
        {
            dataField: "MaLoHang",
            label: { text: gooTrans("NhapHang.MaLoHang"), },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("NhapHang.SoLuong"), },
        },
        {
            dataField: "TonKho",
            label: { text: gooTrans("NhapHang.TonKho"), },
        },
        {
            dataField: "DonGia",
            label: { text: gooTrans("NhapHang.DonGia"), },
        },
        {
            dataField: "HanSuDung",
            label: { text: gooTrans("NhapHang.HanSuDung"), },
        },
        {
            dataField: "NgayNhapHang",
            label: { text: gooTrans("NhapHang.NgayNhapHang"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("NhapHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
