﻿
var ctrl = {}
function dump() {
    ctrl = {
    key: function(obj) { return obj.SanPhamID; },
    name: "SanPhamXes",
    columns: [
        {
            dataField: "SanPhamMD",
            caption: gooTrans("SanPhamX.SanPhamMD"),
        },
        {
            dataField: "MaSanPham",
            caption: gooTrans("SanPhamX.MaSanPham"),
        },
        {
            dataField: "TenSanPham",
            caption: gooTrans("SanPhamX.TenSanPham"),
        },
        {
            dataField: "DonVi",
            caption: gooTrans("SanPhamX.DonVi"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("SanPhamX.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
