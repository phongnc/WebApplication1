﻿
function _khachhang_form(data, cols, isNew) {
    $("#formKhachHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "MaKhachHang",
            label: { text: gooTrans("KhachHang.MaKhachHang"), },
        },
        {
            dataField: "TenKhachHang",
            label: { text: gooTrans("KhachHang.TenKhachHang"), },
        },
        {
            dataField: "DiaChi",
            label: { text: gooTrans("KhachHang.DiaChi"), },
        },
        {
            dataField: "MST",
            label: { text: gooTrans("KhachHang.MST"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("KhachHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo KhachHang",
        type: "success",
        onClick: function (e) {
            var values = $("#formKhachHang").dxForm("instance")._options.formData;
			if (values.KhachHangID == 0) {
			    return $.post(vDir + "/api/KhachHangs/", values).done(function (x) {
			        location.href = vDir + "/KhachHangs/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/KhachHangs/" + encodeURIComponent(values.KhachHangID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/KhachHangs/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo KhachHang"); 
        }
    });
};
