﻿
function _sanpham_form(data, cols, isNew) {
    $("#formSanPham").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamMD",
            label: { text: gooTrans("SanPham.SanPhamMD"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamMD"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaSanPham",
            label: { text: gooTrans("SanPham.MaSanPham"), },
        },
        {
            dataField: "TenSanPham",
            label: { text: gooTrans("SanPham.TenSanPham"), },
        },
        {
            dataField: "DonVi",
            label: { text: gooTrans("SanPham.DonVi"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("SanPham.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo SanPham",
        type: "success",
        onClick: function (e) {
            var values = $("#formSanPham").dxForm("instance")._options.formData;
			if (values.SanPhamID == 0) {
			    return $.post(vDir + "/api/SanPhams/", values).done(function (x) {
			        location.href = vDir + "/SanPhams/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/SanPhams/" + encodeURIComponent(values.SanPhamID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/SanPhams/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo SanPham"); 
        }
    });
};
