﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=DonHang",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.DonHangID; },
    name: "DonHangs",
    columns: [
        {
            dataField: "BanHangID",
            caption: gooTrans("DonHang.BanHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaDonHang",
            caption: gooTrans("DonHang.MaDonHang"),
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.MaDonHang)
                    .on('dxclick', function () {
                        window.open(vDir + '/DonHangs/Edit?id=' + options.data.DonHangID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "NgayDonHang",
            caption: gooTrans("DonHang.NgayDonHang"),
            dataType: "datetime",
        },
        {
            dataField: "LanSuaDoi",
            caption: gooTrans("DonHang.LanSuaDoi"),
        },
        {
            dataField: "TrangThai",
            caption: gooTrans("DonHang.TrangThai"),
        },
        {
            dataField: "CreatedDate",
            caption: gooTrans("DonHang.CreatedDate"),
            dataType: "datetime",
        },
        {
            dataField: "ModifiedDate",
            caption: gooTrans("DonHang.ModifiedDate"),
            dataType: "datetime",
        },
        {
            dataField: "CreatedUID",
            caption: gooTrans("DonHang.CreatedUID"),
        },
        {
            dataField: "ModifiedUID",
            caption: gooTrans("DonHang.ModifiedUID"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("DonHang.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
    ctrl.onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "addRowButton") {
                item.options.onClick = function (e) {
                    window.open(vDir + '/DonHangs/Create', '_blank');
                }
            }
        });
    }
};
