﻿
function _dobaogia_form(_searchData, cols, isNew) {
    $("#formDOBaoGia").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            itemType: "group",
            caption: "UBaoGia",
            items: [
        {
            dataField: "UBaoGia.BanHangID",
            label: { text: gooTrans("UBaoGia.BaoGia.BanHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBaoGia.MaBaoGia",
            label: { text: gooTrans("UBaoGia.BaoGia.MaBaoGia"), },
        },
        {
            dataField: "UBaoGia.NgayBaoGia",
            label: { text: gooTrans("UBaoGia.BaoGia.NgayBaoGia"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "UBaoGia.LanSuaDoi",
            label: { text: gooTrans("UBaoGia.BaoGia.LanSuaDoi"), },
        },
        {
            dataField: "UBaoGia.TrangThai",
            label: { text: gooTrans("UBaoGia.BaoGia.TrangThai"), },
        },
        {
            dataField: "UBaoGia.CreatedDate",
            label: { text: gooTrans("UBaoGia.BaoGia.CreatedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "UBaoGia.ModifiedDate",
            label: { text: gooTrans("UBaoGia.BaoGia.ModifiedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "UBaoGia.CreatedUID",
            label: { text: gooTrans("UBaoGia.BaoGia.CreatedUID"), },
        },
        {
            dataField: "UBaoGia.ModifiedUID",
            label: { text: gooTrans("UBaoGia.BaoGia.ModifiedUID"), },
        },
        {
            dataField: "UBaoGia.IsDelete",
            label: { text: gooTrans("UBaoGia.BaoGia.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
            ],
        },
        {
            itemType: "group",
            caption: "UBanHang",
            items: [
        {
            dataField: "UBanHang.Title",
            label: { text: gooTrans("UBanHang.BanHang.Title"), },
            validationRules: [
            { type: 'required', message: 'Không được để trống' },
            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },
            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }
            ],
        },
        {
            dataField: "UBanHang.KhachHangID",
            label: { text: gooTrans("UBanHang.BanHang.KhachHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.LoaiDonHang",
            label: { text: gooTrans("UBanHang.BanHang.LoaiDonHang"), },
        },
        {
            dataField: "UBanHang.GiaiDoanID",
            label: { text: gooTrans("UBanHang.BanHang.GiaiDoanID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.NguoiDatHang",
            label: { text: gooTrans("UBanHang.BanHang.NguoiDatHang"), },
        },
        {
            dataField: "UBanHang.MaBoPhan",
            label: { text: gooTrans("UBanHang.BanHang.MaBoPhan"), },
        },
        {
            dataField: "UBanHang.TyGia",
            label: { text: gooTrans("UBanHang.BanHang.TyGia"), },
        },
        {
            dataField: "UBanHang.LoaiChietKhau",
            label: { text: gooTrans("UBanHang.BanHang.LoaiChietKhau"), },
        },
        {
            dataField: "UBanHang.DienGiai",
            label: { text: gooTrans("UBanHang.BanHang.DienGiai"), },
        },
        {
            dataField: "UBanHang.IsDelete",
            label: { text: gooTrans("UBanHang.BanHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
            ],
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
