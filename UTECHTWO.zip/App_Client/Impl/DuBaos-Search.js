﻿
function _dubao_form(_searchData, cols, isNew) {
    $("#formDuBao").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "KhachHangID",
            label: { text: gooTrans("DuBao.KhachHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("DuBao.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "GiaiDoanID",
            label: { text: gooTrans("DuBao.GiaiDoanID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("DuBao.SoLuong"), },
        },
        {
            dataField: "DonGia",
            label: { text: gooTrans("DuBao.DonGia"), },
        },
        {
            dataField: "TrangThai",
            label: { text: gooTrans("DuBao.TrangThai"), },
        },
        {
            dataField: "CreatedDate",
            label: { text: gooTrans("DuBao.CreatedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "ModifiedDate",
            label: { text: gooTrans("DuBao.ModifiedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "CreatedUID",
            label: { text: gooTrans("DuBao.CreatedUID"), },
        },
        {
            dataField: "ModifiedUID",
            label: { text: gooTrans("DuBao.ModifiedUID"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("DuBao.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
