﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=XuatHang",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.XuatHangID; },
    name: "XuatHangs",
    columns: [
        {
            dataField: "NhapHangID",
            caption: gooTrans("XuatHang.NhapHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "NhapHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "DonHangSPID",
            caption: gooTrans("XuatHang.DonHangSPID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "DonHangSPID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            caption: gooTrans("XuatHang.SoLuong"),
        },
    ]
    };
};
