﻿
function _xuathang_form(data, cols, isNew) {
    $("#formXuatHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "NhapHangID",
            label: { text: gooTrans("XuatHang.NhapHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhapHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "DonHangSPID",
            label: { text: gooTrans("XuatHang.DonHangSPID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "DonHangSPID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("XuatHang.SoLuong"), },
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo XuatHang",
        type: "success",
        onClick: function (e) {
            var values = $("#formXuatHang").dxForm("instance")._options.formData;
			if (values.XuatHangID == 0) {
			    return $.post(vDir + "/api/XuatHangs/", values).done(function (x) {
			        location.href = vDir + "/XuatHangs/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/XuatHangs/" + encodeURIComponent(values.XuatHangID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/XuatHangs/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo XuatHang"); 
        }
    });
};
