﻿
function _user_form(data, cols, isNew) {
    $("#formUser").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "Email",
            label: { text: gooTrans("User.Email"), },
        },
        {
            dataField: "Password",
            label: { text: gooTrans("User.Password"), },
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo User",
        type: "success",
        onClick: function (e) {
            var values = $("#formUser").dxForm("instance")._options.formData;
			if (values.UserID == 0) {
			    return $.post(vDir + "/api/Users/", values).done(function (x) {
			        location.href = vDir + "/Users/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/Users/" + encodeURIComponent(values.UserID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/Users/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo User"); 
        }
    });
};
