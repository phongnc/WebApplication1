﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=DuBao",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.DuBaoID; },
    name: "DuBaos",
    columns: [
        {
            dataField: "KhachHangID",
            caption: gooTrans("DuBao.KhachHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            caption: gooTrans("DuBao.SanPhamID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "GiaiDoanID",
            caption: gooTrans("DuBao.GiaiDoanID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            caption: gooTrans("DuBao.SoLuong"),
        },
        {
            dataField: "DonGia",
            caption: gooTrans("DuBao.DonGia"),
        },
        {
            dataField: "TrangThai",
            caption: gooTrans("DuBao.TrangThai"),
        },
        {
            dataField: "CreatedDate",
            caption: gooTrans("DuBao.CreatedDate"),
            dataType: "datetime",
        },
        {
            dataField: "ModifiedDate",
            caption: gooTrans("DuBao.ModifiedDate"),
            dataType: "datetime",
        },
        {
            dataField: "CreatedUID",
            caption: gooTrans("DuBao.CreatedUID"),
        },
        {
            dataField: "ModifiedUID",
            caption: gooTrans("DuBao.ModifiedUID"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("DuBao.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
