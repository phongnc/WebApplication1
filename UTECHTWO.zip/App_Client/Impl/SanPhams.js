﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=SanPham",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.SanPhamID; },
    name: "SanPhams",
    columns: [
        {
            dataField: "SanPhamMD",
            caption: gooTrans("SanPham.SanPhamMD"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamMD"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaSanPham",
            caption: gooTrans("SanPham.MaSanPham"),
        },
        {
            dataField: "TenSanPham",
            caption: gooTrans("SanPham.TenSanPham"),
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.TenSanPham)
                    .on('dxclick', function () {
                        window.open(vDir + '/SanPhams/Edit?id=' + options.data.SanPhamID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "DonVi",
            caption: gooTrans("SanPham.DonVi"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("SanPham.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
    ctrl.onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "addRowButton") {
                item.options.onClick = function (e) {
                    window.open(vDir + '/SanPhams/Create', '_blank');
                }
            }
        });
    }
};
