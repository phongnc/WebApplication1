﻿
function _dodonhang_form(_searchData, cols, isNew) {
    $("#formDODonHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            itemType: "group",
            caption: "UDonHang",
            items: [
        {
            dataField: "UDonHang.BanHangID",
            label: { text: gooTrans("UDonHang.DonHang.BanHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UDonHang.MaDonHang",
            label: { text: gooTrans("UDonHang.DonHang.MaDonHang"), },
        },
        {
            dataField: "UDonHang.NgayDonHang",
            label: { text: gooTrans("UDonHang.DonHang.NgayDonHang"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "UDonHang.LanSuaDoi",
            label: { text: gooTrans("UDonHang.DonHang.LanSuaDoi"), },
        },
        {
            dataField: "UDonHang.TrangThai",
            label: { text: gooTrans("UDonHang.DonHang.TrangThai"), },
        },
        {
            dataField: "UDonHang.CreatedDate",
            label: { text: gooTrans("UDonHang.DonHang.CreatedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "UDonHang.ModifiedDate",
            label: { text: gooTrans("UDonHang.DonHang.ModifiedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "UDonHang.CreatedUID",
            label: { text: gooTrans("UDonHang.DonHang.CreatedUID"), },
        },
        {
            dataField: "UDonHang.ModifiedUID",
            label: { text: gooTrans("UDonHang.DonHang.ModifiedUID"), },
        },
        {
            dataField: "UDonHang.IsDelete",
            label: { text: gooTrans("UDonHang.DonHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
            ],
        },
        {
            itemType: "group",
            caption: "UBanHang",
            items: [
        {
            dataField: "UBanHang.Title",
            label: { text: gooTrans("UBanHang.BanHang.Title"), },
            validationRules: [
            { type: 'required', message: 'Không được để trống' },
            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },
            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }
            ],
        },
        {
            dataField: "UBanHang.KhachHangID",
            label: { text: gooTrans("UBanHang.BanHang.KhachHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.LoaiDonHang",
            label: { text: gooTrans("UBanHang.BanHang.LoaiDonHang"), },
        },
        {
            dataField: "UBanHang.GiaiDoanID",
            label: { text: gooTrans("UBanHang.BanHang.GiaiDoanID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.NguoiDatHang",
            label: { text: gooTrans("UBanHang.BanHang.NguoiDatHang"), },
        },
        {
            dataField: "UBanHang.MaBoPhan",
            label: { text: gooTrans("UBanHang.BanHang.MaBoPhan"), },
        },
        {
            dataField: "UBanHang.TyGia",
            label: { text: gooTrans("UBanHang.BanHang.TyGia"), },
        },
        {
            dataField: "UBanHang.LoaiChietKhau",
            label: { text: gooTrans("UBanHang.BanHang.LoaiChietKhau"), },
        },
        {
            dataField: "UBanHang.DienGiai",
            label: { text: gooTrans("UBanHang.BanHang.DienGiai"), },
        },
        {
            dataField: "UBanHang.IsDelete",
            label: { text: gooTrans("UBanHang.BanHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
            ],
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
