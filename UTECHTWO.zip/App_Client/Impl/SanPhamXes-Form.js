﻿
function _sanphamx_form(data, cols, isNew) {
    $("#formSanPhamX").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamMD",
            label: { text: gooTrans("SanPhamX.SanPhamMD"), },
        },
        {
            dataField: "MaSanPham",
            label: { text: gooTrans("SanPhamX.MaSanPham"), },
        },
        {
            dataField: "TenSanPham",
            label: { text: gooTrans("SanPhamX.TenSanPham"), },
        },
        {
            dataField: "DonVi",
            label: { text: gooTrans("SanPhamX.DonVi"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("SanPhamX.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo SanPhamX",
        type: "success",
        onClick: function (e) {
            var values = $("#formSanPhamX").dxForm("instance")._options.formData;
			if (values.SanPhamID == 0) {
			    return $.post(vDir + "/api/SanPhamXes/", values).done(function (x) {
			        location.href = vDir + "/SanPhamXes/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/SanPhamXes/" + encodeURIComponent(values.SanPhamID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/SanPhamXes/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo SanPhamX"); 
        }
    });
};
