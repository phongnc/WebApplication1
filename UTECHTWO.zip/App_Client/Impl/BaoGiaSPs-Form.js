﻿
function _baogiasp_form(data, cols, isNew) {
    $("#formBaoGiaSP").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "BaoGiaID",
            label: { text: gooTrans("BaoGiaSP.BaoGiaID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "BaoGiaID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("BaoGiaSP.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("BaoGiaSP.SoLuong"), },
        },
        {
            dataField: "DonGia",
            label: { text: gooTrans("BaoGiaSP.DonGia"), },
        },
        {
            dataField: "TrangThai",
            label: { text: gooTrans("BaoGiaSP.TrangThai"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("BaoGiaSP.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo BaoGiaSP",
        type: "success",
        onClick: function (e) {
            var values = $("#formBaoGiaSP").dxForm("instance")._options.formData;
			if (values.BaoGiaSPID == 0) {
			    return $.post(vDir + "/api/BaoGiaSPs/", values).done(function (x) {
			        location.href = vDir + "/BaoGiaSPs/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/BaoGiaSPs/" + encodeURIComponent(values.BaoGiaSPID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/BaoGiaSPs/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo BaoGiaSP"); 
        }
    });
};
