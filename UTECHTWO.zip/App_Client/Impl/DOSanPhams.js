﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=SanPham,SPInfo,SPImage,",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.USanPham.SanPhamID; },
    assign: function (key, values) { Object.assign(key.USanPham, values.USanPham);Object.assign(key.USPInfo, values.USPInfo);Object.assign(key.USPImage, values.USPImage); },
    name: "DOSanPhams",
    search: function() { return _dosanpham_search(); },
    columns: [
        {
            dataField: "USanPham.SanPhamMD",
            caption: gooTrans("USanPham.SanPham.SanPhamMD"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamMD"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USanPham.MaSanPham",
            caption: gooTrans("USanPham.SanPham.MaSanPham"),
        },
        {
            dataField: "USanPham.TenSanPham",
            caption: gooTrans("USanPham.SanPham.TenSanPham"),
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.USanPham.TenSanPham)
                    .on('dxclick', function () {
                        window.open(vDir + '/DOSanPhams/Edit?id=' + options.data.USanPham.SanPhamID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "USanPham.DonVi",
            caption: gooTrans("USanPham.SanPham.DonVi"),
        },
        {
            dataField: "USanPham.IsDelete",
            caption: gooTrans("USanPham.SanPham.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
        {
            dataField: "USPInfo.SanPhamID",
            caption: gooTrans("USPInfo.SPInfo.SanPhamID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPInfo.NhaCungCapID",
            caption: gooTrans("USPInfo.SPInfo.NhaCungCapID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPInfo.TenSanXuat",
            caption: gooTrans("USPInfo.SPInfo.TenSanXuat"),
        },
        {
            dataField: "USPInfo.SanLuong",
            caption: gooTrans("USPInfo.SPInfo.SanLuong"),
        },
        {
            dataField: "USPInfo.NongDoMauSac",
            caption: gooTrans("USPInfo.SPInfo.NongDoMauSac"),
        },
        {
            dataField: "USPInfo.KhoiLuongDungLuong",
            caption: gooTrans("USPInfo.SPInfo.KhoiLuongDungLuong"),
        },
        {
            dataField: "USPInfo.ChungLoaiVoChua",
            caption: gooTrans("USPInfo.SPInfo.ChungLoaiVoChua"),
        },
        {
            dataField: "USPInfo.PhanPhoiSanXuat",
            caption: gooTrans("USPInfo.SPInfo.PhanPhoiSanXuat"),
        },
        {
            dataField: "USPInfo.GhiChu",
            caption: gooTrans("USPInfo.SPInfo.GhiChu"),
        },
        {
            dataField: "USPInfo.JsonData",
            caption: gooTrans("USPInfo.SPInfo.JsonData"),
            visible: false,
            formItem: { visible: false },
        },
        {
            dataField: "USPImage.SanPhamID",
            caption: gooTrans("USPImage.SPImage.SanPhamID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPImage.SPImageMoreID",
            caption: gooTrans("USPImage.SPImage.SPImageMoreID"),
        },
        {
            dataField: "USPImage.MatTruoc",
            caption: gooTrans("USPImage.SPImage.MatTruoc"),
        },
        {
            dataField: "USPImage.MatSau",
            caption: gooTrans("USPImage.SPImage.MatSau"),
        },
        {
            dataField: "USPImage.MatTren",
            caption: gooTrans("USPImage.SPImage.MatTren"),
        },
        {
            dataField: "USPImage.DongGoi1",
            caption: gooTrans("USPImage.SPImage.DongGoi1"),
        },
        {
            dataField: "USPImage.DongGoi2",
            caption: gooTrans("USPImage.SPImage.DongGoi2"),
        },
        {
            dataField: "USPImage.AnhKhac",
            caption: gooTrans("USPImage.SPImage.AnhKhac"),
        },
    ]
    };
    ctrl.onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "addRowButton") {
                item.options.onClick = function (e) {
                    window.open(vDir + '/DOSanPhams/Create', '_blank');
                }
            }
        });
    }
};
