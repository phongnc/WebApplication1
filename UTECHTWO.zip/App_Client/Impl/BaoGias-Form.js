﻿
function _baogia_form(data, cols, isNew) {
    $("#formBaoGia").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "BanHangID",
            label: { text: gooTrans("BaoGia.BanHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaBaoGia",
            label: { text: gooTrans("BaoGia.MaBaoGia"), },
        },
        {
            dataField: "NgayBaoGia",
            label: { text: gooTrans("BaoGia.NgayBaoGia"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "LanSuaDoi",
            label: { text: gooTrans("BaoGia.LanSuaDoi"), },
        },
        {
            dataField: "TrangThai",
            label: { text: gooTrans("BaoGia.TrangThai"), },
        },
        {
            dataField: "CreatedDate",
            label: { text: gooTrans("BaoGia.CreatedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "ModifiedDate",
            label: { text: gooTrans("BaoGia.ModifiedDate"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "CreatedUID",
            label: { text: gooTrans("BaoGia.CreatedUID"), },
        },
        {
            dataField: "ModifiedUID",
            label: { text: gooTrans("BaoGia.ModifiedUID"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("BaoGia.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo BaoGia",
        type: "success",
        onClick: function (e) {
            var values = $("#formBaoGia").dxForm("instance")._options.formData;
			if (values.BaoGiaID == 0) {
			    return $.post(vDir + "/api/BaoGias/", values).done(function (x) {
			        location.href = vDir + "/BaoGias/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/BaoGias/" + encodeURIComponent(values.BaoGiaID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/BaoGias/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo BaoGia"); 
        }
    });
};
