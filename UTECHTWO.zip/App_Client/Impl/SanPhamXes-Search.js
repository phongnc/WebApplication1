﻿
function _sanphamx_form(_searchData, cols, isNew) {
    $("#formSanPhamX").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamMD",
            label: { text: gooTrans("SanPhamX.SanPhamMD"), },
        },
        {
            dataField: "MaSanPham",
            label: { text: gooTrans("SanPhamX.MaSanPham"), },
        },
        {
            dataField: "TenSanPham",
            label: { text: gooTrans("SanPhamX.TenSanPham"), },
        },
        {
            dataField: "DonVi",
            label: { text: gooTrans("SanPhamX.DonVi"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("SanPhamX.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
