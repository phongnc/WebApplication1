﻿
function _nhaphang_form(data, cols, isNew) {
    $("#formNhapHang").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "KhoID",
            label: { text: gooTrans("NhapHang.KhoID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "KhoID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("NhapHang.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaCungCapID",
            label: { text: gooTrans("NhapHang.NhaCungCapID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "NhaSanXuat",
            label: { text: gooTrans("NhapHang.NhaSanXuat"), },
        },
        {
            dataField: "MaLoHang",
            label: { text: gooTrans("NhapHang.MaLoHang"), },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("NhapHang.SoLuong"), },
        },
        {
            dataField: "TonKho",
            label: { text: gooTrans("NhapHang.TonKho"), },
        },
        {
            dataField: "DonGia",
            label: { text: gooTrans("NhapHang.DonGia"), },
        },
        {
            dataField: "HanSuDung",
            label: { text: gooTrans("NhapHang.HanSuDung"), },
        },
        {
            dataField: "NgayNhapHang",
            label: { text: gooTrans("NhapHang.NgayNhapHang"), },
            dataType: "datetime",
            editorType: "dxDateBox",
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("NhapHang.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo NhapHang",
        type: "success",
        onClick: function (e) {
            var values = $("#formNhapHang").dxForm("instance")._options.formData;
			if (values.NhapHangID == 0) {
			    return $.post(vDir + "/api/NhapHangs/", values).done(function (x) {
			        location.href = vDir + "/NhapHangs/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/NhapHangs/" + encodeURIComponent(values.NhapHangID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/NhapHangs/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo NhapHang"); 
        }
    });
};
