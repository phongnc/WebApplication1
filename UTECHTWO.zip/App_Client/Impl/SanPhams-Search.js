﻿
function _sanpham_form(_searchData, cols, isNew) {
    $("#formSanPham").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamMD",
            label: { text: gooTrans("SanPham.SanPhamMD"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamMD"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "MaSanPham",
            label: { text: gooTrans("SanPham.MaSanPham"), },
        },
        {
            dataField: "TenSanPham",
            label: { text: gooTrans("SanPham.TenSanPham"), },
        },
        {
            dataField: "DonVi",
            label: { text: gooTrans("SanPham.DonVi"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("SanPham.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
