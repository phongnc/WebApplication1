﻿
var ctrl = {}
function dump() {
    ctrl = {
    key: function(obj) { return obj.LoaiSanPhamID; },
    name: "LoaiSanPhams",
    columns: [
        {
            dataField: "MaLoaiSanPham",
            caption: gooTrans("LoaiSanPham.MaLoaiSanPham"),
        },
        {
            dataField: "TenLoaiSanPham",
            caption: gooTrans("LoaiSanPham.TenLoaiSanPham"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("LoaiSanPham.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
