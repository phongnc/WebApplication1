﻿
var ctrl = {}
function dump() {
    ctrl = {
    key: function(obj) { return obj.NhaCungCapID; },
    name: "NhaCungCaps",
    columns: [
        {
            dataField: "MaNhaCungCap",
            caption: gooTrans("NhaCungCap.MaNhaCungCap"),
        },
        {
            dataField: "TenNhaCungCap",
            caption: gooTrans("NhaCungCap.TenNhaCungCap"),
        },
        {
            dataField: "DiaChi",
            caption: gooTrans("NhaCungCap.DiaChi"),
        },
        {
            dataField: "MST",
            caption: gooTrans("NhaCungCap.MST"),
        },
        {
            dataField: "IsDelete",
            caption: gooTrans("NhaCungCap.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
};
