﻿
function _nhacungcap_form(_searchData, cols, isNew) {
    $("#formNhaCungCap").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: _searchData,
        labelLocation: "top",
        items: [
        {
            dataField: "MaNhaCungCap",
            label: { text: gooTrans("NhaCungCap.MaNhaCungCap"), },
        },
        {
            dataField: "TenNhaCungCap",
            label: { text: gooTrans("NhaCungCap.TenNhaCungCap"), },
        },
        {
            dataField: "DiaChi",
            label: { text: gooTrans("NhaCungCap.DiaChi"), },
        },
        {
            dataField: "MST",
            label: { text: gooTrans("NhaCungCap.MST"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("NhaCungCap.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#searchButton").dxButton({
        text: "Tìm kiếm",
        type: "success",
        onClick: function (e) {
            //localStorage.setItem('_searchData', JSON.stringify(_searchData));
            var grid = $("#gridContainer").dxDataGrid('instance');
            //ctrl.datasource.load();
            grid.refresh();
        }
    });
};
