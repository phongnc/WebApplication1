﻿
function _donhangsp_form(data, cols, isNew) {
    $("#formDonHangSP").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "DonHangID",
            label: { text: gooTrans("DonHangSP.DonHangID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "DonHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("DonHangSP.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SoLuong",
            label: { text: gooTrans("DonHangSP.SoLuong"), },
        },
        {
            dataField: "DonGia",
            label: { text: gooTrans("DonHangSP.DonGia"), },
        },
        {
            dataField: "TrangThai",
            label: { text: gooTrans("DonHangSP.TrangThai"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("DonHangSP.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo DonHangSP",
        type: "success",
        onClick: function (e) {
            var values = $("#formDonHangSP").dxForm("instance")._options.formData;
			if (values.DonHangSPID == 0) {
			    return $.post(vDir + "/api/DonHangSPs/", values).done(function (x) {
			        location.href = vDir + "/DonHangSPs/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/DonHangSPs/" + encodeURIComponent(values.DonHangSPID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/DonHangSPs/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo DonHangSP"); 
        }
    });
};
