﻿
function _dosanpham_form(data, cols, isNew) {
    $("#formDOSanPham").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            itemType: "group",
            caption: "USanPham",
            items: [
        {
            dataField: "USanPham.SanPhamMD",
            label: { text: gooTrans("USanPham.SanPham.SanPhamMD"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamMD"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USanPham.MaSanPham",
            label: { text: gooTrans("USanPham.SanPham.MaSanPham"), },
        },
        {
            dataField: "USanPham.TenSanPham",
            label: { text: gooTrans("USanPham.SanPham.TenSanPham"), },
        },
        {
            dataField: "USanPham.DonVi",
            label: { text: gooTrans("USanPham.SanPham.DonVi"), },
        },
        {
            dataField: "USanPham.IsDelete",
            label: { text: gooTrans("USanPham.SanPham.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
            ],
        },
        {
            itemType: "group",
            caption: "USPInfo",
            items: [
        {
            dataField: "USPInfo.SanPhamID",
            label: { text: gooTrans("USPInfo.SPInfo.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPInfo.NhaCungCapID",
            label: { text: gooTrans("USPInfo.SPInfo.NhaCungCapID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "NhaCungCapID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPInfo.TenSanXuat",
            label: { text: gooTrans("USPInfo.SPInfo.TenSanXuat"), },
        },
        {
            dataField: "USPInfo.SanLuong",
            label: { text: gooTrans("USPInfo.SPInfo.SanLuong"), },
        },
        {
            dataField: "USPInfo.NongDoMauSac",
            label: { text: gooTrans("USPInfo.SPInfo.NongDoMauSac"), },
        },
        {
            dataField: "USPInfo.KhoiLuongDungLuong",
            label: { text: gooTrans("USPInfo.SPInfo.KhoiLuongDungLuong"), },
        },
        {
            dataField: "USPInfo.ChungLoaiVoChua",
            label: { text: gooTrans("USPInfo.SPInfo.ChungLoaiVoChua"), },
        },
        {
            dataField: "USPInfo.PhanPhoiSanXuat",
            label: { text: gooTrans("USPInfo.SPInfo.PhanPhoiSanXuat"), },
        },
        {
            dataField: "USPInfo.GhiChu",
            label: { text: gooTrans("USPInfo.SPInfo.GhiChu"), },
        },
        {
            dataField: "USPInfo.JsonData",
            label: { text: gooTrans("USPInfo.SPInfo.JsonData"), },
            visible: false,
        },
            ],
        },
        {
            itemType: "group",
            caption: "USPImage",
            items: [
        {
            dataField: "USPImage.SanPhamID",
            label: { text: gooTrans("USPImage.SPImage.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "USPImage.SPImageMoreID",
            label: { text: gooTrans("USPImage.SPImage.SPImageMoreID"), },
        },
        {
            dataField: "USPImage.MatTruoc",
            label: { text: gooTrans("USPImage.SPImage.MatTruoc"), },
        },
        {
            dataField: "USPImage.MatSau",
            label: { text: gooTrans("USPImage.SPImage.MatSau"), },
        },
        {
            dataField: "USPImage.MatTren",
            label: { text: gooTrans("USPImage.SPImage.MatTren"), },
        },
        {
            dataField: "USPImage.DongGoi1",
            label: { text: gooTrans("USPImage.SPImage.DongGoi1"), },
        },
        {
            dataField: "USPImage.DongGoi2",
            label: { text: gooTrans("USPImage.SPImage.DongGoi2"), },
        },
        {
            dataField: "USPImage.AnhKhac",
            label: { text: gooTrans("USPImage.SPImage.AnhKhac"), },
        },
            ],
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo DOSanPham",
        type: "success",
        onClick: function (e) {
            var values = $("#formDOSanPham").dxForm("instance")._options.formData;
			if (values.USanPham.SanPhamID == 0) {
			    return $.post(vDir + "/api/DOSanPhams/", values).done(function (x) {
			        location.href = vDir + "/DOSanPhams/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/DOSanPhams/" + encodeURIComponent(values.USanPham.SanPhamID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/DOSanPhams/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo DOSanPham"); 
        }
    });
};
