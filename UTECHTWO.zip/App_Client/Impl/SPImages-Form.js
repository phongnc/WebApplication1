﻿
function _spimage_form(data, cols, isNew) {
    $("#formSPImage").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "SanPhamID",
            label: { text: gooTrans("SPImage.SanPhamID"), },
            editorType: "dxSelectBox",
            editorOptions: {
                onValueChanged: function (data) {
                    doEvent("dxSelectBox.onValueChanged");
                },
                searchEnabled: true,
                dataSource: _selectedEDS2(_options, "SanPhamID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "SPImageMoreID",
            label: { text: gooTrans("SPImage.SPImageMoreID"), },
        },
        {
            dataField: "MatTruoc",
            label: { text: gooTrans("SPImage.MatTruoc"), },
        },
        {
            dataField: "MatSau",
            label: { text: gooTrans("SPImage.MatSau"), },
        },
        {
            dataField: "MatTren",
            label: { text: gooTrans("SPImage.MatTren"), },
        },
        {
            dataField: "DongGoi1",
            label: { text: gooTrans("SPImage.DongGoi1"), },
        },
        {
            dataField: "DongGoi2",
            label: { text: gooTrans("SPImage.DongGoi2"), },
        },
        {
            dataField: "AnhKhac",
            label: { text: gooTrans("SPImage.AnhKhac"), },
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo SPImage",
        type: "success",
        onClick: function (e) {
            var values = $("#formSPImage").dxForm("instance")._options.formData;
			if (values.SPImageID == 0) {
			    return $.post(vDir + "/api/SPImages/", values).done(function (x) {
			        location.href = vDir + "/SPImages/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/SPImages/" + encodeURIComponent(values.SPImageID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/SPImages/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo SPImage"); 
        }
    });
};
