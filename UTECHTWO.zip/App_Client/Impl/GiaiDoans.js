﻿
var ctrl = {}
function dump() {
    ctrl = {
    key: function(obj) { return obj.GiaiDoanID; },
    name: "GiaiDoans",
    columns: [
        {
            dataField: "MaGiaiDoan",
            caption: gooTrans("GiaiDoan.MaGiaiDoan"),
        },
        {
            dataField: "BatDau",
            caption: gooTrans("GiaiDoan.BatDau"),
            dataType: "datetime",
        },
        {
            dataField: "KetThuc",
            caption: gooTrans("GiaiDoan.KetThuc"),
            dataType: "datetime",
        },
    ]
    };
};
