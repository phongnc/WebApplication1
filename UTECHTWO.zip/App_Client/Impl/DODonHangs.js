﻿
var _options = {}; var ctrl = {};
ctrl.initEDS = function (callback) {
    $.ajax({
        url: vDir + "/api/EnumRecords/?EID=0&isList=true&theString=DonHang,BanHang,",
        data: {take: 1001},
        success: function (result) {
            _options = result;
            callback();
        },
        error: function () {
        },
        timeout: 5000
    });
}
function dump() {
    ctrl = {
    key: function(obj) { return obj.UDonHang.DonHangID; },
    assign: function (key, values) { Object.assign(key.UDonHang, values.UDonHang);Object.assign(key.UBanHang, values.UBanHang); },
    name: "DODonHangs",
    search: function() { return _dodonhang_search(); },
    columns: [
        {
            dataField: "UDonHang.BanHangID",
            caption: gooTrans("UDonHang.DonHang.BanHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "BanHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UDonHang.MaDonHang",
            caption: gooTrans("UDonHang.DonHang.MaDonHang"),
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.UDonHang.MaDonHang)
                    .on('dxclick', function () {
                        window.open(vDir + '/DODonHangs/Edit?id=' + options.data.UDonHang.DonHangID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "UDonHang.NgayDonHang",
            caption: gooTrans("UDonHang.DonHang.NgayDonHang"),
            dataType: "datetime",
        },
        {
            dataField: "UDonHang.LanSuaDoi",
            caption: gooTrans("UDonHang.DonHang.LanSuaDoi"),
        },
        {
            dataField: "UDonHang.TrangThai",
            caption: gooTrans("UDonHang.DonHang.TrangThai"),
        },
        {
            dataField: "UDonHang.CreatedDate",
            caption: gooTrans("UDonHang.DonHang.CreatedDate"),
            dataType: "datetime",
        },
        {
            dataField: "UDonHang.ModifiedDate",
            caption: gooTrans("UDonHang.DonHang.ModifiedDate"),
            dataType: "datetime",
        },
        {
            dataField: "UDonHang.CreatedUID",
            caption: gooTrans("UDonHang.DonHang.CreatedUID"),
        },
        {
            dataField: "UDonHang.ModifiedUID",
            caption: gooTrans("UDonHang.DonHang.ModifiedUID"),
        },
        {
            dataField: "UDonHang.IsDelete",
            caption: gooTrans("UDonHang.DonHang.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
        {
            dataField: "UBanHang.Title",
            caption: gooTrans("UBanHang.BanHang.Title"),
            validationRules: [
            { type: 'required', message: 'Không được để trống' },
            { type: 'stringLength', min: 1, max: 250, message: 'Không được vượt quá 250 ký tự' },
            { type: 'custom', validationCallback: function (data) { return regValue(data.value, 'Title'); }, message: 'Không được sử dụng các ký tự đặc biệt' }
            ],
            cellTemplate: function (container, options) {
                $('<a/>').text(options.data.Title)
                    .on('dxclick', function () {
                        window.open(vDir + '/DODonHangs/Edit?id=' + options.data.BanHangID, '_blank');
                    }).appendTo(container);
            },
        },
        {
            dataField: "UBanHang.KhachHangID",
            caption: gooTrans("UBanHang.BanHang.KhachHangID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "KhachHangID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.LoaiDonHang",
            caption: gooTrans("UBanHang.BanHang.LoaiDonHang"),
        },
        {
            dataField: "UBanHang.GiaiDoanID",
            caption: gooTrans("UBanHang.BanHang.GiaiDoanID"),
            lookup: {
                dataSource: _selectedEDS2(_options, "GiaiDoanID"),
                valueExpr: 'IID',
                displayExpr: 'TitValue',
            },
        },
        {
            dataField: "UBanHang.NguoiDatHang",
            caption: gooTrans("UBanHang.BanHang.NguoiDatHang"),
        },
        {
            dataField: "UBanHang.MaBoPhan",
            caption: gooTrans("UBanHang.BanHang.MaBoPhan"),
        },
        {
            dataField: "UBanHang.TyGia",
            caption: gooTrans("UBanHang.BanHang.TyGia"),
        },
        {
            dataField: "UBanHang.LoaiChietKhau",
            caption: gooTrans("UBanHang.BanHang.LoaiChietKhau"),
        },
        {
            dataField: "UBanHang.DienGiai",
            caption: gooTrans("UBanHang.BanHang.DienGiai"),
        },
        {
            dataField: "UBanHang.IsDelete",
            caption: gooTrans("UBanHang.BanHang.IsDelete"),
            dataType: "boolean",
            cellTemplate: function (element, info) {
                colIsDelete(element, info);
            },
            formItem: { visible: false },
        },
    ]
    };
    ctrl.onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "addRowButton") {
                item.options.onClick = function (e) {
                    window.open(vDir + '/DODonHangs/Create', '_blank');
                }
            }
        });
    }
};
