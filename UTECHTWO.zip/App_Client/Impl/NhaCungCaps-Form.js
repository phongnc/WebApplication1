﻿
function _nhacungcap_form(data, cols, isNew) {
    $("#formNhaCungCap").dxForm({
        colCount: cols,
        readOnly: !isNew,
        showBorders: true,
        formData: data,
        labelLocation: "top",
        items: [
        {
            dataField: "MaNhaCungCap",
            label: { text: gooTrans("NhaCungCap.MaNhaCungCap"), },
        },
        {
            dataField: "TenNhaCungCap",
            label: { text: gooTrans("NhaCungCap.TenNhaCungCap"), },
        },
        {
            dataField: "DiaChi",
            label: { text: gooTrans("NhaCungCap.DiaChi"), },
        },
        {
            dataField: "MST",
            label: { text: gooTrans("NhaCungCap.MST"), },
        },
        {
            dataField: "IsDelete",
            label: { text: gooTrans("NhaCungCap.IsDelete"), },
            dataType: "boolean",
            editorType: "dxCheckBox",
            visible: false,
        },
        ],
    });
    $("#button").dxButton({
        text: "Tạo NhaCungCap",
        type: "success",
        onClick: function (e) {
            var values = $("#formNhaCungCap").dxForm("instance")._options.formData;
			if (values.NhaCungCapID == 0) {
			    return $.post(vDir + "/api/NhaCungCaps/", values).done(function (x) {
			        location.href = vDir + "/NhaCungCaps/";
			    });
			}
			else {
			    return $.ajax({
			        url: vDir + "/api/NhaCungCaps/" + encodeURIComponent(values.NhaCungCapID),
			        method: "PUT",
			        data: values,
			        success: function (x) {
						location.href = vDir + "/NhaCungCaps/";
			        },
			    });
			}
			alert("Có lỗi trong việc tạo NhaCungCap"); 
        }
    });
};
