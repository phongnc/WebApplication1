﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class EnumRecordsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        public IQueryable<Models.DO.EObject> GetEnumRecords(int EID, bool isList, string theString)
        {
            //if (EIDs.Length == 0) try { EIDs = Newtonsoft.Json.JsonConvert.DeserializeObject<int[]>(theString); } catch { }
            List<Models.DO.EObject> result = new List<Models.DO.EObject>();
            if (string.IsNullOrEmpty(theString)) return result.AsQueryable();
            if ((theString.Length > 2) && (theString.Contains(",")))
            {
                string[] theStrings = theString.Split(new char[] { ',' });
                for (int i = 0; i < theStrings.Length; i++)
                    if (!string.IsNullOrEmpty(theStrings[i]))
                        GetTheString(theStrings[i], ref result);
            }
            else
            {
                GetTheString(theString, ref result);
            }
            return result.AsQueryable();
        }
        public void GetTheString(string theString, ref List<Models.DO.EObject> result)
        {
            switch (theString)
            {
                case "SanPham":
                    var x01 = db.LoaiSanPhams.MorphRange("", null, "LoaiSanPhamID,TenLoaiSanPham").ToList();
                    for (int i = 0; i < x01.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamMD",
                            IID = x01[i].LoaiSanPhamID,
                            TitValue = x01[i].TenLoaiSanPham
                        });
                    }
                    var x02 = db.NhaCungCaps.MorphRange("", null, "NhaCungCapID,TenNhaCungCap").ToList();
                    for (int i = 0; i < x02.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "NhaCungCapID",
                            IID = x02[i].NhaCungCapID,
                            TitValue = x02[i].TenNhaCungCap
                        });
                    }
                    break;
                case "BanHang":
                    var x11 = db.KhachHangs.MorphRange("", null, "KhachHangID,TenKhachHang").ToList();
                    for (int i = 0; i < x11.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhachHangID",
                            IID = x11[i].KhachHangID,
                            TitValue = x11[i].TenKhachHang
                        });
                    }
                    var x12 = db.GiaiDoans.MorphRange("", null, "GiaiDoanID,MaGiaiDoan").ToList();
                    for (int i = 0; i < x12.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "GiaiDoanID",
                            IID = x12[i].GiaiDoanID,
                            TitValue = x12[i].MaGiaiDoan
                        });
                    }
                    break;
                case "BaoGia":
                    var x21 = db.BanHangs.MorphRange("", null, "BanHangID,Title").ToList();
                    for (int i = 0; i < x21.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "BanHangID",
                            IID = x21[i].BanHangID,
                            TitValue = x21[i].Title
                        });
                    }
                    break;
                case "BaoGiaSP":
                    var x22 = db.BaoGias.MorphRange("", null, "BaoGiaID,MaBaoGia").ToList();
                    for (int i = 0; i < x22.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "BaoGiaID",
                            IID = x22[i].BaoGiaID,
                            TitValue = x22[i].MaBaoGia
                        });
                    }
                    var x23 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x23.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x23[i].SanPhamID,
                            TitValue = x23[i].TenSanPham
                        });
                    }
                    break;
                case "DoanhThu":
                    var x13 = db.DonHangSPs.MorphRange("", null, "DonHangSPID,SanPhamID").ToList();
                    for (int i = 0; i < x13.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "DonHangSPID",
                            IID = x13[i].DonHangSPID,
                            TitValue = x13[i].SanPhamID.ToString()
                        });
                    }
                    break;
                case "DonHang":
                    var x24 = db.BanHangs.MorphRange("", null, "BanHangID,Title").ToList();
                    for (int i = 0; i < x24.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "BanHangID",
                            IID = x24[i].BanHangID,
                            TitValue = x24[i].Title
                        });
                    }
                    break;
                case "DonHangSP":
                    var x25 = db.DonHangs.MorphRange("", null, "DonHangID,MaDonHang").ToList();
                    for (int i = 0; i < x25.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "DonHangID",
                            IID = x25[i].DonHangID,
                            TitValue = x25[i].MaDonHang
                        });
                    }
                    var x26 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x26.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x26[i].SanPhamID,
                            TitValue = x26[i].TenSanPham
                        });
                    }
                    break;
                case "DuBao":
                    var x14 = db.KhachHangs.MorphRange("", null, "KhachHangID,TenKhachHang").ToList();
                    for (int i = 0; i < x14.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhachHangID",
                            IID = x14[i].KhachHangID,
                            TitValue = x14[i].TenKhachHang
                        });
                    }
                    var x15 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x15.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x15[i].SanPhamID,
                            TitValue = x15[i].TenSanPham
                        });
                    }
                    var x16 = db.GiaiDoans.MorphRange("", null, "GiaiDoanID,MaGiaiDoan").ToList();
                    for (int i = 0; i < x16.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "GiaiDoanID",
                            IID = x16[i].GiaiDoanID,
                            TitValue = x16[i].MaGiaiDoan
                        });
                    }
                    break;
                case "KhoKhach":
                    var x17 = db.KhachHangs.MorphRange("", null, "KhachHangID,TenKhachHang").ToList();
                    for (int i = 0; i < x17.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhachHangID",
                            IID = x17[i].KhachHangID,
                            TitValue = x17[i].TenKhachHang
                        });
                    }
                    var x18 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x18.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x18[i].SanPhamID,
                            TitValue = x18[i].TenSanPham
                        });
                    }
                    break;
                case "NhapHang":
                    var x31 = db.Khoes.MorphRange("", null, "KhoID,TenKho").ToList();
                    for (int i = 0; i < x31.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "KhoID",
                            IID = x31[i].KhoID,
                            TitValue = x31[i].TenKho
                        });
                    }
                    var x32 = db.SanPhams.MorphRange("", null, "SanPhamID,TenSanPham").ToList();
                    for (int i = 0; i < x31.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "SanPhamID",
                            IID = x32[i].SanPhamID,
                            TitValue = x32[i].TenSanPham
                        });
                    }
                    var x33 = db.NhaCungCaps.MorphRange("", null, "NhaCungCapID,TenNhaCungCap").ToList();
                    for (int i = 0; i < x33.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "NhaCungCapID",
                            IID = x33[i].NhaCungCapID,
                            TitValue = x33[i].TenNhaCungCap
                        });
                    }
                    break;
                case "XuatHang":
                    var x34 = db.DonHangSPs.MorphRange("", null, "DonHangSPID,SanPhamID").ToList();
                    for (int i = 0; i < x34.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "DonHangSPID",
                            IID = x34[i].DonHangSPID,
                            TitValue = x34[i].SanPhamID.ToString()
                        });
                    }
                    var x35 = db.NhapHangs.MorphRange("", null, "NhapHangID,MaLoHang").ToList();
                    for (int i = 0; i < x35.Count(); i++)
                    {
                        result.Add(new Models.DO.EObject()
                        {
                            StringValue = "NhapHangID",
                            IID = x35[i].NhapHangID,
                            TitValue = x35[i].MaLoHang
                        });
                    }
                    break;
            }
        }
    }
}
