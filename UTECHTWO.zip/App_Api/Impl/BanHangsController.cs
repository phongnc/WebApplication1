﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchBanHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/BanHangs
        public Models.DP.DpSelectResult<Models.EF.BanHang> PutSearchBanHangs(Models.SO.SearchBanHang biz)
        {
            db.BanHangs.SkipRows = biz.skip;
            db.BanHangs.TakeRows = biz.take;
            return db.BanHangs.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class BanHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/BanHangs
        public Models.DP.DpSelectResult<Models.EF.BanHang> GetBanHangs(int skip = 0, int take = 10)
        {
            db.BanHangs.SkipRows = skip;
            db.BanHangs.TakeRows = take;
            return db.BanHangs.SelectResult();
        }
        // GET: api/BanHangs/5
        [ResponseType(typeof(Models.EF.BanHang))]
        public IHttpActionResult GetBanHang(int id)
        {
            Models.EF.BanHang biz = db.BanHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/BanHangs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBanHang(int id, Models.EF.BanHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.BanHangID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.BanHangs.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BanHangExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/BanHangs
        [ResponseType(typeof(Models.EF.BanHang))]
        public IHttpActionResult PostBanHang(Models.EF.BanHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.BanHangs.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.BanHangID }, biz);
        }
        // DELETE: api/BanHangs/5
        [ResponseType(typeof(Models.EF.BanHang))]
        public IHttpActionResult DeleteBanHang(int id)
        {
            Models.EF.BanHang biz = db.BanHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.BanHangs.Update(biz);
            //db.BanHangs.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool BanHangExists(int id)
        {
            return db.BanHangs.Count(id) > 0;
        }
    }
}
