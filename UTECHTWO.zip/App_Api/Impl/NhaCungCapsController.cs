﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchNhaCungCapsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/NhaCungCaps
        public Models.DP.DpSelectResult<Models.EF.NhaCungCap> PutSearchNhaCungCaps(Models.SO.SearchNhaCungCap biz)
        {
            db.NhaCungCaps.SkipRows = biz.skip;
            db.NhaCungCaps.TakeRows = biz.take;
            return db.NhaCungCaps.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class NhaCungCapsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/NhaCungCaps
        public Models.DP.DpSelectResult<Models.EF.NhaCungCap> GetNhaCungCaps(int skip = 0, int take = 10)
        {
            db.NhaCungCaps.SkipRows = skip;
            db.NhaCungCaps.TakeRows = take;
            return db.NhaCungCaps.SelectResult();
        }
        // GET: api/NhaCungCaps/5
        [ResponseType(typeof(Models.EF.NhaCungCap))]
        public IHttpActionResult GetNhaCungCap(int id)
        {
            Models.EF.NhaCungCap biz = db.NhaCungCaps.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/NhaCungCaps/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutNhaCungCap(int id, Models.EF.NhaCungCap biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.NhaCungCapID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.NhaCungCaps.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!NhaCungCapExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/NhaCungCaps
        [ResponseType(typeof(Models.EF.NhaCungCap))]
        public IHttpActionResult PostNhaCungCap(Models.EF.NhaCungCap biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.NhaCungCaps.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.NhaCungCapID }, biz);
        }
        // DELETE: api/NhaCungCaps/5
        [ResponseType(typeof(Models.EF.NhaCungCap))]
        public IHttpActionResult DeleteNhaCungCap(int id)
        {
            Models.EF.NhaCungCap biz = db.NhaCungCaps.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.NhaCungCaps.Update(biz);
            //db.NhaCungCaps.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool NhaCungCapExists(int id)
        {
            return db.NhaCungCaps.Count(id) > 0;
        }
    }
}
