﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchSanPhamsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SanPhams
        public Models.DP.DpSelectResult<Models.EF.SanPham> PutSearchSanPhams(Models.SO.SearchSanPham biz)
        {
            db.SanPhams.SkipRows = biz.skip;
            db.SanPhams.TakeRows = biz.take;
            return db.SanPhams.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class SanPhamsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SanPhams
        public Models.DP.DpSelectResult<Models.EF.SanPham> GetSanPhams(int skip = 0, int take = 10)
        {
            db.SanPhams.SkipRows = skip;
            db.SanPhams.TakeRows = take;
            return db.SanPhams.SelectResult();
        }
        // GET: api/SanPhams/5
        [ResponseType(typeof(Models.EF.SanPham))]
        public IHttpActionResult GetSanPham(int id)
        {
            Models.EF.SanPham biz = db.SanPhams.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/SanPhams/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSanPham(int id, Models.EF.SanPham biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.SanPhamID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.SanPhams.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SanPhamExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/SanPhams
        [ResponseType(typeof(Models.EF.SanPham))]
        public IHttpActionResult PostSanPham(Models.EF.SanPham biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.SanPhams.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.SanPhamID }, biz);
        }
        // DELETE: api/SanPhams/5
        [ResponseType(typeof(Models.EF.SanPham))]
        public IHttpActionResult DeleteSanPham(int id)
        {
            Models.EF.SanPham biz = db.SanPhams.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.SanPhams.Update(biz);
            //db.SanPhams.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool SanPhamExists(int id)
        {
            return db.SanPhams.Count(id) > 0;
        }
    }
}
