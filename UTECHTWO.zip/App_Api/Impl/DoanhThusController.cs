﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchDoanhThusController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DoanhThus
        public Models.DP.DpSelectResult<Models.EF.DoanhThu> PutSearchDoanhThus(Models.SO.SearchDoanhThu biz)
        {
            db.DoanhThus.SkipRows = biz.skip;
            db.DoanhThus.TakeRows = biz.take;
            return db.DoanhThus.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class DoanhThusController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DoanhThus
        public Models.DP.DpSelectResult<Models.EF.DoanhThu> GetDoanhThus(int skip = 0, int take = 10)
        {
            db.DoanhThus.SkipRows = skip;
            db.DoanhThus.TakeRows = take;
            return db.DoanhThus.SelectResult();
        }
        // GET: api/DoanhThus/5
        [ResponseType(typeof(Models.EF.DoanhThu))]
        public IHttpActionResult GetDoanhThu(int id)
        {
            Models.EF.DoanhThu biz = db.DoanhThus.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/DoanhThus/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDoanhThu(int id, Models.EF.DoanhThu biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.DoanhThuID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.DoanhThus.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DoanhThuExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/DoanhThus
        [ResponseType(typeof(Models.EF.DoanhThu))]
        public IHttpActionResult PostDoanhThu(Models.EF.DoanhThu biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.DoanhThus.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.DoanhThuID }, biz);
        }
        // DELETE: api/DoanhThus/5
        [ResponseType(typeof(Models.EF.DoanhThu))]
        public IHttpActionResult DeleteDoanhThu(int id)
        {
            Models.EF.DoanhThu biz = db.DoanhThus.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.DoanhThus.Update(biz);
            //db.DoanhThus.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool DoanhThuExists(int id)
        {
            return db.DoanhThus.Count(id) > 0;
        }
    }
}
