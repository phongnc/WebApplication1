﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchKhachHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/KhachHangs
        public Models.DP.DpSelectResult<Models.EF.KhachHang> PutSearchKhachHangs(Models.SO.SearchKhachHang biz)
        {
            db.KhachHangs.SkipRows = biz.skip;
            db.KhachHangs.TakeRows = biz.take;
            return db.KhachHangs.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class KhachHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/KhachHangs
        public Models.DP.DpSelectResult<Models.EF.KhachHang> GetKhachHangs(int skip = 0, int take = 10)
        {
            db.KhachHangs.SkipRows = skip;
            db.KhachHangs.TakeRows = take;
            return db.KhachHangs.SelectResult();
        }
        // GET: api/KhachHangs/5
        [ResponseType(typeof(Models.EF.KhachHang))]
        public IHttpActionResult GetKhachHang(int id)
        {
            Models.EF.KhachHang biz = db.KhachHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/KhachHangs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutKhachHang(int id, Models.EF.KhachHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.KhachHangID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.KhachHangs.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!KhachHangExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/KhachHangs
        [ResponseType(typeof(Models.EF.KhachHang))]
        public IHttpActionResult PostKhachHang(Models.EF.KhachHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.KhachHangs.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.KhachHangID }, biz);
        }
        // DELETE: api/KhachHangs/5
        [ResponseType(typeof(Models.EF.KhachHang))]
        public IHttpActionResult DeleteKhachHang(int id)
        {
            Models.EF.KhachHang biz = db.KhachHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.KhachHangs.Update(biz);
            //db.KhachHangs.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool KhachHangExists(int id)
        {
            return db.KhachHangs.Count(id) > 0;
        }
    }
}
