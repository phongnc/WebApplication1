﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchLoaiSanPhamsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/LoaiSanPhams
        public Models.DP.DpSelectResult<Models.EF.LoaiSanPham> PutSearchLoaiSanPhams(Models.SO.SearchLoaiSanPham biz)
        {
            db.LoaiSanPhams.SkipRows = biz.skip;
            db.LoaiSanPhams.TakeRows = biz.take;
            return db.LoaiSanPhams.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class LoaiSanPhamsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/LoaiSanPhams
        public Models.DP.DpSelectResult<Models.EF.LoaiSanPham> GetLoaiSanPhams(int skip = 0, int take = 10)
        {
            db.LoaiSanPhams.SkipRows = skip;
            db.LoaiSanPhams.TakeRows = take;
            return db.LoaiSanPhams.SelectResult();
        }
        // GET: api/LoaiSanPhams/5
        [ResponseType(typeof(Models.EF.LoaiSanPham))]
        public IHttpActionResult GetLoaiSanPham(int id)
        {
            Models.EF.LoaiSanPham biz = db.LoaiSanPhams.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/LoaiSanPhams/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutLoaiSanPham(int id, Models.EF.LoaiSanPham biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.LoaiSanPhamID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.LoaiSanPhams.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LoaiSanPhamExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/LoaiSanPhams
        [ResponseType(typeof(Models.EF.LoaiSanPham))]
        public IHttpActionResult PostLoaiSanPham(Models.EF.LoaiSanPham biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.LoaiSanPhams.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.LoaiSanPhamID }, biz);
        }
        // DELETE: api/LoaiSanPhams/5
        [ResponseType(typeof(Models.EF.LoaiSanPham))]
        public IHttpActionResult DeleteLoaiSanPham(int id)
        {
            Models.EF.LoaiSanPham biz = db.LoaiSanPhams.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.LoaiSanPhams.Update(biz);
            //db.LoaiSanPhams.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool LoaiSanPhamExists(int id)
        {
            return db.LoaiSanPhams.Count(id) > 0;
        }
    }
}
