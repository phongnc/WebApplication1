﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchNhapHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/NhapHangs
        public Models.DP.DpSelectResult<Models.EF.NhapHang> PutSearchNhapHangs(Models.SO.SearchNhapHang biz)
        {
            db.NhapHangs.SkipRows = biz.skip;
            db.NhapHangs.TakeRows = biz.take;
            return db.NhapHangs.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class NhapHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/NhapHangs
        public Models.DP.DpSelectResult<Models.EF.NhapHang> GetNhapHangs(int skip = 0, int take = 10)
        {
            db.NhapHangs.SkipRows = skip;
            db.NhapHangs.TakeRows = take;
            return db.NhapHangs.SelectResult();
        }
        // GET: api/NhapHangs/5
        [ResponseType(typeof(Models.EF.NhapHang))]
        public IHttpActionResult GetNhapHang(int id)
        {
            Models.EF.NhapHang biz = db.NhapHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/NhapHangs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutNhapHang(int id, Models.EF.NhapHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.NhapHangID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.NhapHangs.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!NhapHangExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/NhapHangs
        [ResponseType(typeof(Models.EF.NhapHang))]
        public IHttpActionResult PostNhapHang(Models.EF.NhapHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.NhapHangs.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.NhapHangID }, biz);
        }
        // DELETE: api/NhapHangs/5
        [ResponseType(typeof(Models.EF.NhapHang))]
        public IHttpActionResult DeleteNhapHang(int id)
        {
            Models.EF.NhapHang biz = db.NhapHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.NhapHangs.Update(biz);
            //db.NhapHangs.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool NhapHangExists(int id)
        {
            return db.NhapHangs.Count(id) > 0;
        }
    }
}
