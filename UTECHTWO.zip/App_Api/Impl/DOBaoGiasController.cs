﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.DO;
namespace UTECHTWO.Api
{
    public partial class SearchDOBaoGiasController : ApiController
    {
        private Models.DP.DPBaoGias db = new Models.DP.DPBaoGias();
        // GET: api/DOBaoGias
        public Models.DP.DpSelectResult<Models.DO.DOBaoGia> PutSearchDOBaoGias(Models.SO.SearchDOBaoGia biz)
        {
            db.UBaoGia.SkipRows = biz.skip;
            db.UBaoGia.TakeRows = biz.take;
            db.SkipRows = biz.skip;
            db.TakeRows = biz.take;
            return db.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class DOBaoGiasController : ApiController
    {
        private Models.DP.DPBaoGias db = new Models.DP.DPBaoGias();
        // GET: api/DOBaoGias
        public Models.DP.DpSelectResult<Models.DO.DOBaoGia> GetDOBaoGias(int skip = 0, int take = 10)
        {
            db.UBaoGia.SkipRows = skip;
            db.UBaoGia.TakeRows = take;
            return db.SelectResult();
        }
        // GET: api/DOBaoGias/5
        [ResponseType(typeof(Models.DO.DOBaoGia))]
        public IHttpActionResult GetDOBaoGia(int id)
        {
            Models.DO.DOBaoGia biz = db.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/DOBaoGias/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDOBaoGia(int id, Models.DO.DOBaoGia biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.UBaoGia.BaoGiaID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DOBaoGiaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/DOBaoGias
        [ResponseType(typeof(Models.DO.DOBaoGia))]
        public IHttpActionResult PostDOBaoGia(Models.DO.DOBaoGia biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.UBaoGia.BaoGiaID }, biz);
        }
        // DELETE: api/DOBaoGias/5
        [ResponseType(typeof(Models.DO.DOBaoGia))]
        public IHttpActionResult DeleteDOBaoGia(int id)
        {
            Models.DO.DOBaoGia biz = db.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.Update(biz);
            //db.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool DOBaoGiaExists(int id)
        {
            return db.UBaoGia.Count(id) > 0;
        }
    }
}
