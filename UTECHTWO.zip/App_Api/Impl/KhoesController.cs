﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchKhoesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/Khoes
        public Models.DP.DpSelectResult<Models.EF.Kho> PutSearchKhoes(Models.SO.SearchKho biz)
        {
            db.Khoes.SkipRows = biz.skip;
            db.Khoes.TakeRows = biz.take;
            return db.Khoes.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class KhoesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/Khoes
        public Models.DP.DpSelectResult<Models.EF.Kho> GetKhoes(int skip = 0, int take = 10)
        {
            db.Khoes.SkipRows = skip;
            db.Khoes.TakeRows = take;
            return db.Khoes.SelectResult();
        }
        // GET: api/Khoes/5
        [ResponseType(typeof(Models.EF.Kho))]
        public IHttpActionResult GetKho(int id)
        {
            Models.EF.Kho biz = db.Khoes.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/Khoes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutKho(int id, Models.EF.Kho biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.KhoID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.Khoes.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!KhoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/Khoes
        [ResponseType(typeof(Models.EF.Kho))]
        public IHttpActionResult PostKho(Models.EF.Kho biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.Khoes.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.KhoID }, biz);
        }
        // DELETE: api/Khoes/5
        [ResponseType(typeof(Models.EF.Kho))]
        public IHttpActionResult DeleteKho(int id)
        {
            Models.EF.Kho biz = db.Khoes.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.Khoes.Update(biz);
            //db.Khoes.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool KhoExists(int id)
        {
            return db.Khoes.Count(id) > 0;
        }
    }
}
