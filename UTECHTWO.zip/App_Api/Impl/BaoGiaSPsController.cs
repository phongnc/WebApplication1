﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchBaoGiaSPsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/BaoGiaSPs
        public Models.DP.DpSelectResult<Models.EF.BaoGiaSP> PutSearchBaoGiaSPs(Models.SO.SearchBaoGiaSP biz)
        {
            db.BaoGiaSPs.SkipRows = biz.skip;
            db.BaoGiaSPs.TakeRows = biz.take;
            return db.BaoGiaSPs.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class BaoGiaSPsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/BaoGiaSPs
        public Models.DP.DpSelectResult<Models.EF.BaoGiaSP> GetBaoGiaSPs(int skip = 0, int take = 10)
        {
            db.BaoGiaSPs.SkipRows = skip;
            db.BaoGiaSPs.TakeRows = take;
            return db.BaoGiaSPs.SelectResult();
        }
        // GET: api/BaoGiaSPs/5
        [ResponseType(typeof(Models.EF.BaoGiaSP))]
        public IHttpActionResult GetBaoGiaSP(int id)
        {
            Models.EF.BaoGiaSP biz = db.BaoGiaSPs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/BaoGiaSPs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBaoGiaSP(int id, Models.EF.BaoGiaSP biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.BaoGiaSPID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.BaoGiaSPs.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BaoGiaSPExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/BaoGiaSPs
        [ResponseType(typeof(Models.EF.BaoGiaSP))]
        public IHttpActionResult PostBaoGiaSP(Models.EF.BaoGiaSP biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.BaoGiaSPs.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.BaoGiaSPID }, biz);
        }
        // DELETE: api/BaoGiaSPs/5
        [ResponseType(typeof(Models.EF.BaoGiaSP))]
        public IHttpActionResult DeleteBaoGiaSP(int id)
        {
            Models.EF.BaoGiaSP biz = db.BaoGiaSPs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.BaoGiaSPs.Update(biz);
            //db.BaoGiaSPs.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool BaoGiaSPExists(int id)
        {
            return db.BaoGiaSPs.Count(id) > 0;
        }
    }
}
