﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.DO;
namespace UTECHTWO.Api
{
    public partial class SearchDOSanPhamsController : ApiController
    {
        private Models.DP.DPSanPhams db = new Models.DP.DPSanPhams();
        // GET: api/DOSanPhams
        public Models.DP.DpSelectResult<Models.DO.DOSanPham> PutSearchDOSanPhams(Models.SO.SearchDOSanPham biz)
        {
            db.USanPham.SkipRows = biz.skip;
            db.USanPham.TakeRows = biz.take;
            db.SkipRows = biz.skip;
            db.TakeRows = biz.take;
            return db.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class DOSanPhamsController : ApiController
    {
        private Models.DP.DPSanPhams db = new Models.DP.DPSanPhams();
        // GET: api/DOSanPhams
        public Models.DP.DpSelectResult<Models.DO.DOSanPham> GetDOSanPhams(int skip = 0, int take = 10)
        {
            db.USanPham.SkipRows = skip;
            db.USanPham.TakeRows = take;
            return db.SelectResult();
        }
        // GET: api/DOSanPhams/5
        [ResponseType(typeof(Models.DO.DOSanPham))]
        public IHttpActionResult GetDOSanPham(int id)
        {
            Models.DO.DOSanPham biz = db.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/DOSanPhams/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDOSanPham(int id, Models.DO.DOSanPham biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.USanPham.SanPhamID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DOSanPhamExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/DOSanPhams
        [ResponseType(typeof(Models.DO.DOSanPham))]
        public IHttpActionResult PostDOSanPham(Models.DO.DOSanPham biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.USanPham.SanPhamID }, biz);
        }
        // DELETE: api/DOSanPhams/5
        [ResponseType(typeof(Models.DO.DOSanPham))]
        public IHttpActionResult DeleteDOSanPham(int id)
        {
            Models.DO.DOSanPham biz = db.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.Update(biz);
            //db.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool DOSanPhamExists(int id)
        {
            return db.USanPham.Count(id) > 0;
        }
    }
}
