﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchSanPhamXesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SanPhamXes
        public Models.DP.DpSelectResult<Models.EF.SanPhamX> PutSearchSanPhamXes(Models.SO.SearchSanPhamX biz)
        {
            db.SanPhamXes.SkipRows = biz.skip;
            db.SanPhamXes.TakeRows = biz.take;
            return db.SanPhamXes.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class SanPhamXesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SanPhamXes
        public Models.DP.DpSelectResult<Models.EF.SanPhamX> GetSanPhamXes(int skip = 0, int take = 10)
        {
            db.SanPhamXes.SkipRows = skip;
            db.SanPhamXes.TakeRows = take;
            return db.SanPhamXes.SelectResult();
        }
        // GET: api/SanPhamXes/5
        [ResponseType(typeof(Models.EF.SanPhamX))]
        public IHttpActionResult GetSanPhamX(int id)
        {
            Models.EF.SanPhamX biz = db.SanPhamXes.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/SanPhamXes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSanPhamX(int id, Models.EF.SanPhamX biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.SanPhamID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.SanPhamXes.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SanPhamXExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/SanPhamXes
        [ResponseType(typeof(Models.EF.SanPhamX))]
        public IHttpActionResult PostSanPhamX(Models.EF.SanPhamX biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.SanPhamXes.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.SanPhamID }, biz);
        }
        // DELETE: api/SanPhamXes/5
        [ResponseType(typeof(Models.EF.SanPhamX))]
        public IHttpActionResult DeleteSanPhamX(int id)
        {
            Models.EF.SanPhamX biz = db.SanPhamXes.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.SanPhamXes.Update(biz);
            //db.SanPhamXes.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool SanPhamXExists(int id)
        {
            return db.SanPhamXes.Count(id) > 0;
        }
    }
}
