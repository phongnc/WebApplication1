﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchSPImagesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SPImages
        public Models.DP.DpSelectResult<Models.EF.SPImage> PutSearchSPImages(Models.SO.SearchSPImage biz)
        {
            db.SPImages.SkipRows = biz.skip;
            db.SPImages.TakeRows = biz.take;
            return db.SPImages.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class SPImagesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SPImages
        public Models.DP.DpSelectResult<Models.EF.SPImage> GetSPImages(int skip = 0, int take = 10)
        {
            db.SPImages.SkipRows = skip;
            db.SPImages.TakeRows = take;
            return db.SPImages.SelectResult();
        }
        // GET: api/SPImages/5
        [ResponseType(typeof(Models.EF.SPImage))]
        public IHttpActionResult GetSPImage(int id)
        {
            Models.EF.SPImage biz = db.SPImages.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/SPImages/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSPImage(int id, Models.EF.SPImage biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.SPImageID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.SPImages.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SPImageExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/SPImages
        [ResponseType(typeof(Models.EF.SPImage))]
        public IHttpActionResult PostSPImage(Models.EF.SPImage biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.SPImages.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.SPImageID }, biz);
        }
        // DELETE: api/SPImages/5
        [ResponseType(typeof(Models.EF.SPImage))]
        public IHttpActionResult DeleteSPImage(int id)
        {
            Models.EF.SPImage biz = db.SPImages.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.SPImages.Update(biz);
            //db.SPImages.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool SPImageExists(int id)
        {
            return db.SPImages.Count(id) > 0;
        }
    }
}
