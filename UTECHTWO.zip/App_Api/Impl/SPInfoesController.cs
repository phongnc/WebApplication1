﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchSPInfoesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SPInfoes
        public Models.DP.DpSelectResult<Models.EF.SPInfo> PutSearchSPInfoes(Models.SO.SearchSPInfo biz)
        {
            db.SPInfoes.SkipRows = biz.skip;
            db.SPInfoes.TakeRows = biz.take;
            return db.SPInfoes.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class SPInfoesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/SPInfoes
        public Models.DP.DpSelectResult<Models.EF.SPInfo> GetSPInfoes(int skip = 0, int take = 10)
        {
            db.SPInfoes.SkipRows = skip;
            db.SPInfoes.TakeRows = take;
            return db.SPInfoes.SelectResult();
        }
        // GET: api/SPInfoes/5
        [ResponseType(typeof(Models.EF.SPInfo))]
        public IHttpActionResult GetSPInfo(int id)
        {
            Models.EF.SPInfo biz = db.SPInfoes.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/SPInfoes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSPInfo(int id, Models.EF.SPInfo biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.SPInfoID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.SPInfoes.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SPInfoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/SPInfoes
        [ResponseType(typeof(Models.EF.SPInfo))]
        public IHttpActionResult PostSPInfo(Models.EF.SPInfo biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.SPInfoes.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.SPInfoID }, biz);
        }
        // DELETE: api/SPInfoes/5
        [ResponseType(typeof(Models.EF.SPInfo))]
        public IHttpActionResult DeleteSPInfo(int id)
        {
            Models.EF.SPInfo biz = db.SPInfoes.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.SPInfoes.Update(biz);
            //db.SPInfoes.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool SPInfoExists(int id)
        {
            return db.SPInfoes.Count(id) > 0;
        }
    }
}
