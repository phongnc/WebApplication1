﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.DO;
namespace UTECHTWO.Api
{
    public partial class SearchDODonHangsController : ApiController
    {
        private Models.DP.DPDonHangs db = new Models.DP.DPDonHangs();
        // GET: api/DODonHangs
        public Models.DP.DpSelectResult<Models.DO.DODonHang> PutSearchDODonHangs(Models.SO.SearchDODonHang biz)
        {
            db.UDonHang.SkipRows = biz.skip;
            db.UDonHang.TakeRows = biz.take;
            db.SkipRows = biz.skip;
            db.TakeRows = biz.take;
            return db.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class DODonHangsController : ApiController
    {
        private Models.DP.DPDonHangs db = new Models.DP.DPDonHangs();
        // GET: api/DODonHangs
        public Models.DP.DpSelectResult<Models.DO.DODonHang> GetDODonHangs(int skip = 0, int take = 10)
        {
            db.UDonHang.SkipRows = skip;
            db.UDonHang.TakeRows = take;
            return db.SelectResult();
        }
        // GET: api/DODonHangs/5
        [ResponseType(typeof(Models.DO.DODonHang))]
        public IHttpActionResult GetDODonHang(int id)
        {
            Models.DO.DODonHang biz = db.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/DODonHangs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDODonHang(int id, Models.DO.DODonHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.UDonHang.DonHangID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DODonHangExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/DODonHangs
        [ResponseType(typeof(Models.DO.DODonHang))]
        public IHttpActionResult PostDODonHang(Models.DO.DODonHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.UDonHang.DonHangID }, biz);
        }
        // DELETE: api/DODonHangs/5
        [ResponseType(typeof(Models.DO.DODonHang))]
        public IHttpActionResult DeleteDODonHang(int id)
        {
            Models.DO.DODonHang biz = db.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.Update(biz);
            //db.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool DODonHangExists(int id)
        {
            return db.UDonHang.Count(id) > 0;
        }
    }
}
