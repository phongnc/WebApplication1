﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchDonHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DonHangs
        public Models.DP.DpSelectResult<Models.EF.DonHang> PutSearchDonHangs(Models.SO.SearchDonHang biz)
        {
            db.DonHangs.SkipRows = biz.skip;
            db.DonHangs.TakeRows = biz.take;
            return db.DonHangs.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class DonHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DonHangs
        public Models.DP.DpSelectResult<Models.EF.DonHang> GetDonHangs(int skip = 0, int take = 10)
        {
            db.DonHangs.SkipRows = skip;
            db.DonHangs.TakeRows = take;
            return db.DonHangs.SelectResult();
        }
        // GET: api/DonHangs/5
        [ResponseType(typeof(Models.EF.DonHang))]
        public IHttpActionResult GetDonHang(int id)
        {
            Models.EF.DonHang biz = db.DonHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/DonHangs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDonHang(int id, Models.EF.DonHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.DonHangID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.DonHangs.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DonHangExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/DonHangs
        [ResponseType(typeof(Models.EF.DonHang))]
        public IHttpActionResult PostDonHang(Models.EF.DonHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.DonHangs.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.DonHangID }, biz);
        }
        // DELETE: api/DonHangs/5
        [ResponseType(typeof(Models.EF.DonHang))]
        public IHttpActionResult DeleteDonHang(int id)
        {
            Models.EF.DonHang biz = db.DonHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.DonHangs.Update(biz);
            //db.DonHangs.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool DonHangExists(int id)
        {
            return db.DonHangs.Count(id) > 0;
        }
    }
}
