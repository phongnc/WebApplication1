﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchDonHangSPsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DonHangSPs
        public Models.DP.DpSelectResult<Models.EF.DonHangSP> PutSearchDonHangSPs(Models.SO.SearchDonHangSP biz)
        {
            db.DonHangSPs.SkipRows = biz.skip;
            db.DonHangSPs.TakeRows = biz.take;
            return db.DonHangSPs.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class DonHangSPsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DonHangSPs
        public Models.DP.DpSelectResult<Models.EF.DonHangSP> GetDonHangSPs(int skip = 0, int take = 10)
        {
            db.DonHangSPs.SkipRows = skip;
            db.DonHangSPs.TakeRows = take;
            return db.DonHangSPs.SelectResult();
        }
        // GET: api/DonHangSPs/5
        [ResponseType(typeof(Models.EF.DonHangSP))]
        public IHttpActionResult GetDonHangSP(int id)
        {
            Models.EF.DonHangSP biz = db.DonHangSPs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/DonHangSPs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDonHangSP(int id, Models.EF.DonHangSP biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.DonHangSPID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.DonHangSPs.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DonHangSPExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/DonHangSPs
        [ResponseType(typeof(Models.EF.DonHangSP))]
        public IHttpActionResult PostDonHangSP(Models.EF.DonHangSP biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.DonHangSPs.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.DonHangSPID }, biz);
        }
        // DELETE: api/DonHangSPs/5
        [ResponseType(typeof(Models.EF.DonHangSP))]
        public IHttpActionResult DeleteDonHangSP(int id)
        {
            Models.EF.DonHangSP biz = db.DonHangSPs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.DonHangSPs.Update(biz);
            //db.DonHangSPs.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool DonHangSPExists(int id)
        {
            return db.DonHangSPs.Count(id) > 0;
        }
    }
}
