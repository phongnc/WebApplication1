﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchDuBaosController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DuBaos
        public Models.DP.DpSelectResult<Models.EF.DuBao> PutSearchDuBaos(Models.SO.SearchDuBao biz)
        {
            db.DuBaos.SkipRows = biz.skip;
            db.DuBaos.TakeRows = biz.take;
            return db.DuBaos.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class DuBaosController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/DuBaos
        public Models.DP.DpSelectResult<Models.EF.DuBao> GetDuBaos(int skip = 0, int take = 10)
        {
            db.DuBaos.SkipRows = skip;
            db.DuBaos.TakeRows = take;
            return db.DuBaos.SelectResult();
        }
        // GET: api/DuBaos/5
        [ResponseType(typeof(Models.EF.DuBao))]
        public IHttpActionResult GetDuBao(int id)
        {
            Models.EF.DuBao biz = db.DuBaos.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/DuBaos/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDuBao(int id, Models.EF.DuBao biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.DuBaoID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.DuBaos.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DuBaoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/DuBaos
        [ResponseType(typeof(Models.EF.DuBao))]
        public IHttpActionResult PostDuBao(Models.EF.DuBao biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.DuBaos.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.DuBaoID }, biz);
        }
        // DELETE: api/DuBaos/5
        [ResponseType(typeof(Models.EF.DuBao))]
        public IHttpActionResult DeleteDuBao(int id)
        {
            Models.EF.DuBao biz = db.DuBaos.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.DuBaos.Update(biz);
            //db.DuBaos.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool DuBaoExists(int id)
        {
            return db.DuBaos.Count(id) > 0;
        }
    }
}
