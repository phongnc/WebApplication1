﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchKhoKhachesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/KhoKhaches
        public Models.DP.DpSelectResult<Models.EF.KhoKhach> PutSearchKhoKhaches(Models.SO.SearchKhoKhach biz)
        {
            db.KhoKhaches.SkipRows = biz.skip;
            db.KhoKhaches.TakeRows = biz.take;
            return db.KhoKhaches.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class KhoKhachesController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/KhoKhaches
        public Models.DP.DpSelectResult<Models.EF.KhoKhach> GetKhoKhaches(int skip = 0, int take = 10)
        {
            db.KhoKhaches.SkipRows = skip;
            db.KhoKhaches.TakeRows = take;
            return db.KhoKhaches.SelectResult();
        }
        // GET: api/KhoKhaches/5
        [ResponseType(typeof(Models.EF.KhoKhach))]
        public IHttpActionResult GetKhoKhach(int id)
        {
            Models.EF.KhoKhach biz = db.KhoKhaches.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/KhoKhaches/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutKhoKhach(int id, Models.EF.KhoKhach biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.KhoKhachID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.KhoKhaches.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!KhoKhachExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/KhoKhaches
        [ResponseType(typeof(Models.EF.KhoKhach))]
        public IHttpActionResult PostKhoKhach(Models.EF.KhoKhach biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.KhoKhaches.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.KhoKhachID }, biz);
        }
        // DELETE: api/KhoKhaches/5
        [ResponseType(typeof(Models.EF.KhoKhach))]
        public IHttpActionResult DeleteKhoKhach(int id)
        {
            Models.EF.KhoKhach biz = db.KhoKhaches.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.KhoKhaches.Update(biz);
            //db.KhoKhaches.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool KhoKhachExists(int id)
        {
            return db.KhoKhaches.Count(id) > 0;
        }
    }
}
