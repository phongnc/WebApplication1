﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchXuatHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/XuatHangs
        public Models.DP.DpSelectResult<Models.EF.XuatHang> PutSearchXuatHangs(Models.SO.SearchXuatHang biz)
        {
            db.XuatHangs.SkipRows = biz.skip;
            db.XuatHangs.TakeRows = biz.take;
            return db.XuatHangs.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class XuatHangsController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/XuatHangs
        public Models.DP.DpSelectResult<Models.EF.XuatHang> GetXuatHangs(int skip = 0, int take = 10)
        {
            db.XuatHangs.SkipRows = skip;
            db.XuatHangs.TakeRows = take;
            return db.XuatHangs.SelectResult();
        }
        // GET: api/XuatHangs/5
        [ResponseType(typeof(Models.EF.XuatHang))]
        public IHttpActionResult GetXuatHang(int id)
        {
            Models.EF.XuatHang biz = db.XuatHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/XuatHangs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutXuatHang(int id, Models.EF.XuatHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.XuatHangID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.XuatHangs.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!XuatHangExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/XuatHangs
        [ResponseType(typeof(Models.EF.XuatHang))]
        public IHttpActionResult PostXuatHang(Models.EF.XuatHang biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.XuatHangs.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.XuatHangID }, biz);
        }
        // DELETE: api/XuatHangs/5
        [ResponseType(typeof(Models.EF.XuatHang))]
        public IHttpActionResult DeleteXuatHang(int id)
        {
            Models.EF.XuatHang biz = db.XuatHangs.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.XuatHangs.Update(biz);
            //db.XuatHangs.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool XuatHangExists(int id)
        {
            return db.XuatHangs.Count(id) > 0;
        }
    }
}
