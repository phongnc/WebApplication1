﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchGiaiDoansController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/GiaiDoans
        public Models.DP.DpSelectResult<Models.EF.GiaiDoan> PutSearchGiaiDoans(Models.SO.SearchGiaiDoan biz)
        {
            db.GiaiDoans.SkipRows = biz.skip;
            db.GiaiDoans.TakeRows = biz.take;
            return db.GiaiDoans.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class GiaiDoansController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/GiaiDoans
        public Models.DP.DpSelectResult<Models.EF.GiaiDoan> GetGiaiDoans(int skip = 0, int take = 10)
        {
            db.GiaiDoans.SkipRows = skip;
            db.GiaiDoans.TakeRows = take;
            return db.GiaiDoans.SelectResult();
        }
        // GET: api/GiaiDoans/5
        [ResponseType(typeof(Models.EF.GiaiDoan))]
        public IHttpActionResult GetGiaiDoan(int id)
        {
            Models.EF.GiaiDoan biz = db.GiaiDoans.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/GiaiDoans/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutGiaiDoan(int id, Models.EF.GiaiDoan biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.GiaiDoanID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.GiaiDoans.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GiaiDoanExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/GiaiDoans
        [ResponseType(typeof(Models.EF.GiaiDoan))]
        public IHttpActionResult PostGiaiDoan(Models.EF.GiaiDoan biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.GiaiDoans.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.GiaiDoanID }, biz);
        }
        // DELETE: api/GiaiDoans/5
        [ResponseType(typeof(Models.EF.GiaiDoan))]
        public IHttpActionResult DeleteGiaiDoan(int id)
        {
            Models.EF.GiaiDoan biz = db.GiaiDoans.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.GiaiDoans.Update(biz);
            //db.GiaiDoans.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool GiaiDoanExists(int id)
        {
            return db.GiaiDoans.Count(id) > 0;
        }
    }
}
