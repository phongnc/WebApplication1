﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchUsersController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/Users
        public Models.DP.DpSelectResult<Models.EF.User> PutSearchUsers(Models.SO.SearchUser biz)
        {
            db.Users.SkipRows = biz.skip;
            db.Users.TakeRows = biz.take;
            return db.Users.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class UsersController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/Users
        public Models.DP.DpSelectResult<Models.EF.User> GetUsers(int skip = 0, int take = 10)
        {
            db.Users.SkipRows = skip;
            db.Users.TakeRows = take;
            return db.Users.SelectResult();
        }
        // GET: api/Users/5
        [ResponseType(typeof(Models.EF.User))]
        public IHttpActionResult GetUser(int id)
        {
            Models.EF.User biz = db.Users.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/Users/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutUser(int id, Models.EF.User biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.UserID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.Users.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/Users
        [ResponseType(typeof(Models.EF.User))]
        public IHttpActionResult PostUser(Models.EF.User biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.Users.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.UserID }, biz);
        }
        // DELETE: api/Users/5
        [ResponseType(typeof(Models.EF.User))]
        public IHttpActionResult DeleteUser(int id)
        {
            Models.EF.User biz = db.Users.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.Users.Update(biz);
            //db.Users.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool UserExists(int id)
        {
            return db.Users.Count(id) > 0;
        }
    }
}
