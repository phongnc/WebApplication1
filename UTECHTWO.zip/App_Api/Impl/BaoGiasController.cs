﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UTECHTWO.Models.EF;
namespace UTECHTWO.Api
{
    public partial class SearchBaoGiasController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/BaoGias
        public Models.DP.DpSelectResult<Models.EF.BaoGia> PutSearchBaoGias(Models.SO.SearchBaoGia biz)
        {
            db.BaoGias.SkipRows = biz.skip;
            db.BaoGias.TakeRows = biz.take;
            return db.BaoGias.SelectResult(biz.OrderCondition(), biz.ConditionString(), biz.ConditionObject());
        }
    }
    public partial class BaoGiasController : ApiController
    {
        private Models.DP.Model1 db = new Models.DP.Model1();
        // GET: api/BaoGias
        public Models.DP.DpSelectResult<Models.EF.BaoGia> GetBaoGias(int skip = 0, int take = 10)
        {
            db.BaoGias.SkipRows = skip;
            db.BaoGias.TakeRows = take;
            return db.BaoGias.SelectResult();
        }
        // GET: api/BaoGias/5
        [ResponseType(typeof(Models.EF.BaoGia))]
        public IHttpActionResult GetBaoGia(int id)
        {
            Models.EF.BaoGia biz = db.BaoGias.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            return Ok(biz);
        }
        // PUT: api/BaoGias/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBaoGia(int id, Models.EF.BaoGia biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != biz.BaoGiaID)
            {
                return BadRequest();
            }
            //db.Entry(biz).State = EntityState.Modified;
            try
            {
                db.BaoGias.Update(biz);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BaoGiaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }
        // POST: api/BaoGias
        [ResponseType(typeof(Models.EF.BaoGia))]
        public IHttpActionResult PostBaoGia(Models.EF.BaoGia biz)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //biz.BitValue = true;
            biz = db.BaoGias.Add(biz);
            //db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = biz.BaoGiaID }, biz);
        }
        // DELETE: api/BaoGias/5
        [ResponseType(typeof(Models.EF.BaoGia))]
        public IHttpActionResult DeleteBaoGia(int id)
        {
            Models.EF.BaoGia biz = db.BaoGias.Find(id);
            if (biz == null)
            {
                return NotFound();
            }
            //biz.BitValue = !biz.BitValue;
            db.BaoGias.Update(biz);
            //db.BaoGias.Remove(biz);
            //db.SaveChanges();
            return Ok(biz);
        }
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        private bool BaoGiaExists(int id)
        {
            return db.BaoGias.Count(id) > 0;
        }
    }
}
