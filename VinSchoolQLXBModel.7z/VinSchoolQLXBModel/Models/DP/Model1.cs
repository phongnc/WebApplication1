﻿
using System.Collections.Generic;
using VinSchoolQLXB.Models.EF;
using Dapper.DataClient;

namespace VinSchoolQLXB.Models.DP
{
    public class Model1
    {
        public DpSet<DKXBHocSinh> DKXBHocSinhs { get; set; }
        public DpSet<AppMember> AppMembers { get; set; }
        public DpSet<AppUser> AppUsers { get; set; }
        public DpSet<BusHocSinh> BusHocSinhs { get; set; }
        public DpSet<BusHocSinhLog> BusHocSinhLogs { get; set; }
        public DpSet<CosoHe> CosoHes { get; set; }
        public DpSet<CosoTruong> CosoTruongs { get; set; }
        public DpSet<Diem> Diems { get; set; }
        public DpSet<HocSinh> HocSinhs { get; set; }
        public DpSet<Huyen> Huyens { get; set; }
        public DpSet<KhuVuc> KhuVucs { get; set; }
        public DpSet<Tinh> Tinhs { get; set; }
        public DpSet<Tuyen> Tuyens { get; set; }
        public DpSet<TuyenDiem> TuyenDiems { get; set; }
        public DpSet<TuyenDiemLog> TuyenDiemLogs { get; set; }
        public DpSet<TuyenLog> TuyenLogs { get; set; }
        public DpSet<Xa> Xas { get; set; }
        public DpSet<XeCompany> XeCompanies { get; set; }
        public DpSet<XeDriver> XeDrivers { get; set; }
        public DpSet<XeManager> XeManagers { get; set; }
        public DpSet<XeVehice> XeVehices { get; set; }
        public Model1()
        {
            string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Model1"].ToString();
            DKXBHocSinhs = new DpSet<DKXBHocSinh>()
            {
                ConnectionString = _ConnectionString,
                TableName = "DKXBHocSinh",
                IdentityColumn = "DKXBHocSinhID",
                Columns = new List<string>() { "MaHocSinh", "Nam_hoc", "HoTen", "Tai_dau", "DKXBAction", "CosoTruongID", "CosoHeID", "ID_khu_vuc", "ID_diem_don", "ID_diem_tra", "ID_khu_vuc0", "ID_diem_don0", "ID_diem_tra0", "Khoang_cach", "ID_tinh", "ID_huyen", "ID_xa", "ID_tinh0", "ID_huyen0", "ID_xa0", "Dia_chi", "Ngay_dk", "Hinh_thuc_gs", "Hinh_thuc_hs", "Ma_hoc_sinh_ace", "Ho_ten_ace", "DKXBStatus", "JsonData", "CreatedDate", }
            };
            AppMembers = new DpSet<AppMember>()
            {
                ConnectionString = _ConnectionString,
                TableName = "AppMember",
                IdentityColumn = "AppMemberID",
                Columns = new List<string>() { "HoTen","MaVG","Valued","TinhTrang", }
            };
            AppUsers = new DpSet<AppUser>()
            {
                ConnectionString = _ConnectionString,
                TableName = "AppUser",
                IdentityColumn = "AppUserID",
                Columns = new List<string>() { "MaHocSinh","Email","Password","Valued","CreatedDate","TrangThai", }
            };
            BusHocSinhs = new DpSet<BusHocSinh>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BusHocSinh",
                IdentityColumn = "BusHocSinhID",
                Columns = new List<string>() { "HocSinhID","TuyenID","DiemDonID","DiemTraID","CreatedDate","ModifiedDate","TrangThai", }
            };
            BusHocSinhLogs = new DpSet<BusHocSinhLog>()
            {
                ConnectionString = _ConnectionString,
                TableName = "BusHocSinhLog",
                IdentityColumn = "BusHocSinhLogID",
                Columns = new List<string>() { "BusHocSinhID","JsonData","CreatedUID","CreatedDate", }
            };
            CosoHes = new DpSet<CosoHe>()
            {
                ConnectionString = _ConnectionString,
                TableName = "CosoHe",
                IdentityColumn = "CosoHeID",
                Columns = new List<string>() { "CosoTruongID","ADMID","TenHe","TrangThai", }
            };
            CosoTruongs = new DpSet<CosoTruong>()
            {
                ConnectionString = _ConnectionString,
                TableName = "CosoTruong",
                IdentityColumn = "CosoTruongID",
                Columns = new List<string>() { "ADMID","TenTruong","TrangThai", }
            };
            Diems = new DpSet<Diem>()
            {
                ConnectionString = _ConnectionString,
                TableName = "Diem",
                IdentityColumn = "DiemID",
                Columns = new List<string>() { "TinhID","HuyenID","XaID","DuongPho","SoNha","KhuVucID","MoTa","DiemDon","DiemTra","LoaiDiem","TrangThai", }
            };
            HocSinhs = new DpSet<HocSinh>()
            {
                ConnectionString = _ConnectionString,
                TableName = "HocSinh",
                IdentityColumn = "HocSinhID",
                Columns = new List<string>() { "MaHocSinh","HoTen","Phone","GhiChu","TrangThai", }
            };
            Huyens = new DpSet<Huyen>()
            {
                ConnectionString = _ConnectionString,
                TableName = "Huyen",
                IdentityColumn = "HuyenID",
                Columns = new List<string>() { "TinhID","TenHuyen","TrangThai", }
            };
            KhuVucs = new DpSet<KhuVuc>()
            {
                ConnectionString = _ConnectionString,
                TableName = "KhuVuc",
                IdentityColumn = "KhuVucID",
                Columns = new List<string>() { "CosoTruongID","CosoHeID","TenKhuVuc","MaKhuVuc","TrangThai", }
            };
            Tinhs = new DpSet<Tinh>()
            {
                ConnectionString = _ConnectionString,
                TableName = "Tinh",
                IdentityColumn = "TinhID",
                Columns = new List<string>() { "TenTinh","MaTinh","TrangThai", }
            };
            Tuyens = new DpSet<Tuyen>()
            {
                ConnectionString = _ConnectionString,
                TableName = "Tuyen",
                IdentityColumn = "TuyenID",
                Columns = new List<string>() { "XeVehiceID","XeDriverID","XeManagerID","MaTuyen","GhiChu","TrangThai", }
            };
            TuyenDiems = new DpSet<TuyenDiem>()
            {
                ConnectionString = _ConnectionString,
                TableName = "TuyenDiem",
                IdentityColumn = "TuyenDiemID",
                Columns = new List<string>() { "TuyenID","DiemID","GioDon","GioTra","GioDenTruong","SoHocSinh","TrangThai", }
            };
            TuyenDiemLogs = new DpSet<TuyenDiemLog>()
            {
                ConnectionString = _ConnectionString,
                TableName = "TuyenDiemLog",
                IdentityColumn = "TuyenDiemLogID",
                Columns = new List<string>() { "TuyenDiemID","JsonData","CreatedUID","CreatedDate", }
            };
            TuyenLogs = new DpSet<TuyenLog>()
            {
                ConnectionString = _ConnectionString,
                TableName = "TuyenLog",
                IdentityColumn = "TuyenLogID",
                Columns = new List<string>() { "TuyenID","JsonData","CreatedUID","CreatedDate", }
            };
            Xas = new DpSet<Xa>()
            {
                ConnectionString = _ConnectionString,
                TableName = "Xa",
                IdentityColumn = "XaID",
                Columns = new List<string>() { "HuyenID","TenXa","TrangThai", }
            };
            XeCompanies = new DpSet<XeCompany>()
            {
                ConnectionString = _ConnectionString,
                TableName = "XeCompany",
                IdentityColumn = "XeCompanyID",
                Columns = new List<string>() { "Ten","TrangThai", }
            };
            XeDrivers = new DpSet<XeDriver>()
            {
                ConnectionString = _ConnectionString,
                TableName = "XeDriver",
                IdentityColumn = "XeDriverID",
                Columns = new List<string>() { "XeCompanyID","HoTen","MaVG","Phone","TrangThai", }
            };
            XeManagers = new DpSet<XeManager>()
            {
                ConnectionString = _ConnectionString,
                TableName = "XeManager",
                IdentityColumn = "XeManagerID",
                Columns = new List<string>() { "XeCompanyID","HoTen","MaVG","Phone","TrangThai", }
            };
            XeVehices = new DpSet<XeVehice>()
            {
                ConnectionString = _ConnectionString,
                TableName = "XeVehice",
                IdentityColumn = "XeVehiceID",
                Columns = new List<string>() { "XeCompanyID","LoaiXe","BienSo","TinhTrang","TrangThai", }
            };
        }
    };
};
