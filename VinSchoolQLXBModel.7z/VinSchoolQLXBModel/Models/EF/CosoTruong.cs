namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CosoTruong")]
    public partial class CosoTruong
    {
        public int CosoTruongID { get; set; }

        public int? ADMID { get; set; }

        public string TenTruong { get; set; }

        public bool TrangThai { get; set; }
    }
}
