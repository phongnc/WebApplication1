namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Diem")]
    public partial class Diem
    {
        public int DiemID { get; set; }

        public int? TinhID { get; set; }

        public int? HuyenID { get; set; }

        public int? XaID { get; set; }

        public string DuongPho { get; set; }

        public string SoNha { get; set; }

        public int? KhuVucID { get; set; }

        public string MoTa { get; set; }

        public string DiemDon { get; set; }

        public string DiemTra { get; set; }

        public int? LoaiDiem { get; set; }

        public bool? TrangThai { get; set; }
    }
}
