namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("XeVehice")]
    public partial class XeVehice
    {
        public int XeVehiceID { get; set; }

        public int XeCompanyID { get; set; }

        public string LoaiXe { get; set; }

        public string BienSo { get; set; }

        public string TinhTrang { get; set; }

        public bool? TrangThai { get; set; }
    }
}
