namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DMCoSo")]
    public partial class DMCoSo
    {
        [Key]
        public int ID_co_so { get; set; }

        [Required]
        [StringLength(5)]
        public string Ma_co_so { get; set; }

        [Required]
        [StringLength(50)]
        public string Ten_co_so { get; set; }

        public int ID_kv { get; set; }

        [StringLength(50)]
        public string Ma_mien { get; set; }

        public bool Trang_thai { get; set; }

        public int? Thu_tu { get; set; }
    }
}
