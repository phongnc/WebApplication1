namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TuyenDiem")]
    public partial class TuyenDiem
    {
        public int TuyenDiemID { get; set; }

        public int TuyenID { get; set; }

        public int DiemID { get; set; }

        public string GioDon { get; set; }

        public string GioTra { get; set; }

        public string GioDenTruong { get; set; }

        public int? SoHocSinh { get; set; }

        public bool? TrangThai { get; set; }
    }
}
