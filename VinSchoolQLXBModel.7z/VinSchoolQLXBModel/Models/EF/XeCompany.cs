namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("XeCompany")]
    public partial class XeCompany
    {
        public int XeCompanyID { get; set; }

        public string Ten { get; set; }

        public bool? TrangThai { get; set; }
    }
}
