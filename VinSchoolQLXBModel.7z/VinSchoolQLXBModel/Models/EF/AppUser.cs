namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AppUser")]
    public partial class AppUser
    {
        public int AppUserID { get; set; }

        public string MaHocSinh { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public int? Valued { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }

        public bool? TrangThai { get; set; }
    }
}
