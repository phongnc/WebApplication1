namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DMHuyen")]
    public partial class DMHuyen
    {
        [Key]
        [StringLength(6)]
        public string ID_huyen { get; set; }

        [Required]
        [StringLength(4)]
        public string ID_tinh { get; set; }

        [Required]
        [StringLength(30)]
        public string Ten_huyen { get; set; }

        [StringLength(50)]
        public string Ten_huyen_en { get; set; }
    }
}
