namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DMCapHoc")]
    public partial class DMCapHoc
    {
        [Key]
        public int ID_cap_hoc { get; set; }

        [Required]
        [StringLength(5)]
        public string Ma_cap_hoc { get; set; }

        [Required]
        [StringLength(100)]
        public string Ten_cap_hoc { get; set; }

        [Required]
        [StringLength(200)]
        public string Mo_ta { get; set; }

        public int ID_co_so { get; set; }

        public int ID_trinh_do { get; set; }

        [StringLength(500)]
        public string Ten_diem_truong { get; set; }

        [StringLength(500)]
        public string Dia_chi { get; set; }

        [StringLength(15)]
        public string So_dien_thoai { get; set; }

        [StringLength(10)]
        public string Ext { get; set; }

        [StringLength(10)]
        public string Ext_TS { get; set; }

        [StringLength(20)]
        public string So_tai_khoan { get; set; }

        [StringLength(15)]
        public string Dien_thoai_gd { get; set; }

        [StringLength(250)]
        public string Ten_ngan_hang { get; set; }

        [StringLength(150)]
        public string Ten_tk { get; set; }

        [StringLength(500)]
        public string Email_nha_truong { get; set; }

        public bool Trang_thai { get; set; }
    }
}
