namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("KhuVuc")]
    public partial class KhuVuc
    {
        public int KhuVucID { get; set; }

        public int? CosoTruongID { get; set; }

        public int? CosoHeID { get; set; }

        public string TenKhuVuc { get; set; }

        public string MaKhuVuc { get; set; }

        public bool? TrangThai { get; set; }
    }
}
