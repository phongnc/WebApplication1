namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AppMember")]
    public partial class AppMember
    {
        public int AppMemberID { get; set; }

        public string HoTen { get; set; }

        public string MaVG { get; set; }

        public int? Valued { get; set; }

        public bool? TinhTrang { get; set; }
    }
}
