namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DMTinh")]
    public partial class DMTinh
    {
        [Key]
        [StringLength(50)]
        public string ID_tinh { get; set; }

        [StringLength(50)]
        public string Ten_tinh { get; set; }

        [StringLength(50)]
        public string Ten_tinh_en { get; set; }
    }
}
