namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Tables_vw
    {
        [Key]
        [Column(Order = 0)]
        public string Table_Name { get; set; }

        [Key]
        [Column(Order = 1)]
        public DateTime Date_Modified { get; set; }

        [Key]
        [Column(Order = 2)]
        public DateTime Date_Created { get; set; }
    }
}
