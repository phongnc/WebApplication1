namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BusHocSinh")]
    public partial class BusHocSinh
    {
        public int BusHocSinhID { get; set; }

        public int? HocSinhID { get; set; }

        public int? TuyenID { get; set; }

        public int? DiemDonID { get; set; }

        public int? DiemTraID { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ModifiedDate { get; set; }

        public int? TrangThai { get; set; }
    }
}
