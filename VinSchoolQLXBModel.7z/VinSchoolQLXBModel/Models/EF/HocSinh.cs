namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HocSinh")]
    public partial class HocSinh
    {
        public int HocSinhID { get; set; }

        public string MaHocSinh { get; set; }

        public string HoTen { get; set; }

        public string Phone { get; set; }

        public string GhiChu { get; set; }

        public bool? TrangThai { get; set; }
    }
}
