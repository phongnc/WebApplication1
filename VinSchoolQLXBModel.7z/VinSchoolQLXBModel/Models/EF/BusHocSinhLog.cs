namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BusHocSinhLog")]
    public partial class BusHocSinhLog
    {
        public int BusHocSinhLogID { get; set; }

        public int BusHocSinhID { get; set; }

        public string JsonData { get; set; }

        public int? CreatedUID { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }
    }
}
