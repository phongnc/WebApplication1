namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<DKXBHocSinh> DKXBHocSinhs { get; set; }
        public virtual DbSet<AppMember> AppMembers { get; set; }
        public virtual DbSet<AppUser> AppUsers { get; set; }
        public virtual DbSet<BusHocSinh> BusHocSinhs { get; set; }
        public virtual DbSet<BusHocSinhLog> BusHocSinhLogs { get; set; }
        public virtual DbSet<CosoHe> CosoHes { get; set; }
        public virtual DbSet<CosoTruong> CosoTruongs { get; set; }
        public virtual DbSet<Diem> Diems { get; set; }
        public virtual DbSet<HocSinh> HocSinhs { get; set; }
        public virtual DbSet<Huyen> Huyens { get; set; }
        public virtual DbSet<KhuVuc> KhuVucs { get; set; }
        public virtual DbSet<Tinh> Tinhs { get; set; }
        public virtual DbSet<Tuyen> Tuyens { get; set; }
        public virtual DbSet<TuyenDiem> TuyenDiems { get; set; }
        public virtual DbSet<TuyenDiemLog> TuyenDiemLogs { get; set; }
        public virtual DbSet<TuyenLog> TuyenLogs { get; set; }
        public virtual DbSet<Xa> Xas { get; set; }
        public virtual DbSet<XeCompany> XeCompanies { get; set; }
        public virtual DbSet<XeDriver> XeDrivers { get; set; }
        public virtual DbSet<XeManager> XeManagers { get; set; }
        public virtual DbSet<XeVehice> XeVehices { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DKXBHocSinh>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);
            modelBuilder.Entity<AppUser>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<BusHocSinh>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<BusHocSinh>()
                .Property(e => e.ModifiedDate)
                .HasPrecision(0);

            modelBuilder.Entity<BusHocSinhLog>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<TuyenDiemLog>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<TuyenLog>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);
        }
    }
}
