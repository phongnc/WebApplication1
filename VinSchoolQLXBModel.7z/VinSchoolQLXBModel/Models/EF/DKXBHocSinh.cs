namespace VinSchoolQLXB.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DKXBHocSinh")]
    public partial class DKXBHocSinh
    {
        public int DKXBHocSinhID { get; set; }

        public string MaHocSinh { get; set; }

        public string Nam_hoc { get; set; }

        public string HoTen { get; set; }

        public string Tai_dau { get; set; }

        public int? DKXBAction { get; set; }

        public int? CosoTruongID { get; set; }

        public int? CosoHeID { get; set; }

        public string ID_khu_vuc { get; set; }

        public string ID_diem_don { get; set; }

        public string ID_diem_tra { get; set; }

        public string ID_khu_vuc0 { get; set; }

        public string ID_diem_don0 { get; set; }

        public string ID_diem_tra0 { get; set; }

        public string Khoang_cach { get; set; }

        public string ID_tinh { get; set; }

        public string ID_huyen { get; set; }

        public string ID_xa { get; set; }

        public string ID_tinh0 { get; set; }

        public string ID_huyen0 { get; set; }

        public string ID_xa0 { get; set; }

        public string Dia_chi { get; set; }

        public string Ngay_dk { get; set; }

        public string Hinh_thuc_gs { get; set; }

        public string Hinh_thuc_hs { get; set; }

        public string Ma_hoc_sinh_ace { get; set; }

        public string Ho_ten_ace { get; set; }

        public int? DKXBStatus { get; set; }

        public string JsonData { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }
    }
}
