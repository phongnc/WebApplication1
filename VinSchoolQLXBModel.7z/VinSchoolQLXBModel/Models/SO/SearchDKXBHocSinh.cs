﻿using System.Collections.Generic;
using Dapper;

namespace VinSchoolQLXB.Models.SO
{
    public class SearchDKXBHocSinh : Models.EF.DKXBHocSinh
    {
        public int take { get; set; }
        public int skip { get; set; }
        public SearchDKXBHocSinh()
        {
            //TODO:
        }
        public string OrderCondition()
        {
            string _orderCondition =  "";
            return _orderCondition;
        }
        public string ConditionString()
        {
            string _conditionString = "";
            List<string> _conditionList = new List<string>();
            try { if (DKXBAction > 0) _conditionList.Add("DKXBAction = @DKXBAction"); } catch { }
            try { if (CosoTruongID > 0) _conditionList.Add("CosoTruongID = @CosoTruongID"); } catch { }
            try { if (CosoHeID > 0) _conditionList.Add("CosoHeID = @CosoHeID"); } catch { }
            try { if ((!string.IsNullOrEmpty(ID_khu_vuc)) && (int.Parse(ID_khu_vuc) > 0)) _conditionList.Add("ID_khu_vuc = @ID_khu_vuc"); } catch { }
            try { if (DKXBStatus > 0) _conditionList.Add("DKXBStatus = @DKXBStatus"); } catch { }
            if (_conditionList.Count > 0) _conditionString = string.Join(" AND ", _conditionList);
            return _conditionString;
        }
        public object ConditionObject()
        {
            return new {
                DKXBAction = DKXBAction,
                CosoTruongID = CosoTruongID,
                CosoHeID = CosoHeID,
                ID_khu_vuc = new DbString() { Value = ID_khu_vuc, IsAnsi = false, Length = 10 },
                DKXBStatus = DKXBStatus,
            };
        }
    }
}
