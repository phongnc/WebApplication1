namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Admin_APIKey
    {
        [Key]
        public long AppID { get; set; }

        [StringLength(100)]
        public string AppSecret { get; set; }

        [StringLength(50)]
        public string AppName { get; set; }

        public string RSA_PrivateKey { get; set; }

        public string RSA_PublicKey { get; set; }

        public DateTime? CreateDate { get; set; }

        public bool? Visible { get; set; }

        public int? UserCreate { get; set; }
    }
}
