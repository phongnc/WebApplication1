namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Product_Industry
    {
        [Key]
        public int ProductIndustryID { get; set; }

        public int DomainID { get; set; }

        [StringLength(250)]
        public string Title { get; set; }

        public bool IsDelete { get; set; }

        [StringLength(50)]
        public string ProductIndustryCode { get; set; }

        [StringLength(500)]
        public string IndustryDescription { get; set; }
    }
}
