namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Product_Category
    {
        [Key]
        public int ProductCategoryID { get; set; }

        public int DomainID { get; set; }

        [StringLength(250)]
        public string Title { get; set; }

        public bool IsDelete { get; set; }

        [StringLength(50)]
        public string ProductCategoryCode { get; set; }

        [StringLength(500)]
        public string CategoryDescription { get; set; }
    }
}
