namespace ConsoleApplication1.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<Admin_APIKey> Admin_APIKey { get; set; }
        public virtual DbSet<AdminAction> AdminActions { get; set; }
        public virtual DbSet<AdminController> AdminControllers { get; set; }
        public virtual DbSet<AdminRole_Action> AdminRole_Action { get; set; }
        public virtual DbSet<AdminRole> AdminRoles { get; set; }
        public virtual DbSet<AdminUser_Cisco> AdminUser_Cisco { get; set; }
        public virtual DbSet<AdminUser_Role> AdminUser_Role { get; set; }
        public virtual DbSet<AdminUser> AdminUsers { get; set; }
        public virtual DbSet<Columns_tb> Columns_tb { get; set; }
        public virtual DbSet<Customer_CallHistory> Customer_CallHistory { get; set; }
        public virtual DbSet<Customer_Datas> Customer_Datas { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Domain_ChucDanh> Domain_ChucDanh { get; set; }
        public virtual DbSet<Domain_ChucDanh_Role> Domain_ChucDanh_Role { get; set; }
        public virtual DbSet<Domain_CuaHang> Domain_CuaHang { get; set; }
        public virtual DbSet<Domain_PhongBan> Domain_PhongBan { get; set; }
        public virtual DbSet<Domain> Domains { get; set; }
        public virtual DbSet<Product_Category> Product_Category { get; set; }
        public virtual DbSet<Product_Industry> Product_Industry { get; set; }
        public virtual DbSet<Tables_tb> Tables_tb { get; set; }
        public virtual DbSet<Templates_tb> Templates_tb { get; set; }
        public virtual DbSet<Ticket_Action_Object> Ticket_Action_Object { get; set; }
        public virtual DbSet<Ticket_ActionHistory> Ticket_ActionHistory { get; set; }
        public virtual DbSet<Ticket_Actions> Ticket_Actions { get; set; }
        public virtual DbSet<Ticket_Groups> Ticket_Groups { get; set; }
        public virtual DbSet<Ticket_Publishers> Ticket_Publishers { get; set; }
        public virtual DbSet<Ticket_Status> Ticket_Status { get; set; }
        public virtual DbSet<Ticket_StatusHistory> Ticket_StatusHistory { get; set; }
        public virtual DbSet<Ticket_Types> Ticket_Types { get; set; }
        public virtual DbSet<Ticket> Tickets { get; set; }
        public virtual DbSet<Columns_vw> Columns_vw { get; set; }
        public virtual DbSet<Tables_vw> Tables_vw { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin_APIKey>()
                .Property(e => e.AppSecret)
                .IsUnicode(false);

            modelBuilder.Entity<Admin_APIKey>()
                .Property(e => e.RSA_PrivateKey)
                .IsUnicode(false);

            modelBuilder.Entity<Admin_APIKey>()
                .Property(e => e.RSA_PublicKey)
                .IsUnicode(false);

            modelBuilder.Entity<AdminAction>()
                .Property(e => e.ActionName)
                .IsUnicode(false);

            modelBuilder.Entity<AdminAction>()
                .Property(e => e.CssIcon)
                .IsUnicode(false);

            modelBuilder.Entity<AdminController>()
                .Property(e => e.ControllerName)
                .IsUnicode(false);

            modelBuilder.Entity<AdminController>()
                .Property(e => e.CssIcon)
                .IsUnicode(false);

            modelBuilder.Entity<AdminUser_Cisco>()
                .Property(e => e.CiscoCode)
                .IsUnicode(false);

            modelBuilder.Entity<AdminUser>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<AdminUser>()
                .Property(e => e.NickName)
                .IsUnicode(false);

            modelBuilder.Entity<AdminUser>()
                .Property(e => e.Phone)
                .IsUnicode(false);

            modelBuilder.Entity<AdminUser>()
                .Property(e => e.CaLamViec)
                .IsUnicode(false);

            modelBuilder.Entity<AdminUser>()
                .Property(e => e.CiscoNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AdminUser>()
                .Property(e => e.CiscoAgent)
                .IsUnicode(false);

            modelBuilder.Entity<Columns_tb>()
                .Property(e => e.Table_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Columns_tb>()
                .Property(e => e.Column_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Columns_tb>()
                .Property(e => e.Use_As)
                .IsUnicode(false);

            modelBuilder.Entity<Customer_CallHistory>()
                .Property(e => e.PhoneNo)
                .IsUnicode(false);

            modelBuilder.Entity<Customer_CallHistory>()
                .Property(e => e.CiscoNo)
                .IsUnicode(false);

            modelBuilder.Entity<Customer_CallHistory>()
                .Property(e => e.LogDateTime)
                .HasPrecision(0);

            modelBuilder.Entity<Customer_Datas>()
                .Property(e => e.DateOfBirth)
                .HasPrecision(0);

            modelBuilder.Entity<Customer_Datas>()
                .Property(e => e.LastContactedOn)
                .HasPrecision(0);

            modelBuilder.Entity<Customer_Datas>()
                .Property(e => e.LastCampaignOn)
                .HasPrecision(0);

            modelBuilder.Entity<Customer>()
                .Property(e => e.CustomerCode)
                .IsUnicode(false);

            modelBuilder.Entity<Customer>()
                .Property(e => e.PhoneNo)
                .IsUnicode(false);

            modelBuilder.Entity<Customer>()
                .Property(e => e.SecondPhoneNo)
                .IsUnicode(false);

            modelBuilder.Entity<Customer>()
                .Property(e => e.VinGroupCardNo)
                .IsUnicode(false);

            modelBuilder.Entity<Domain_CuaHang>()
                .Property(e => e.SDT)
                .IsUnicode(false);

            modelBuilder.Entity<Domain_PhongBan>()
                .Property(e => e.LienHe)
                .IsUnicode(false);

            modelBuilder.Entity<Domain_PhongBan>()
                .Property(e => e.PhongBanCode)
                .IsUnicode(false);

            modelBuilder.Entity<Product_Category>()
                .Property(e => e.ProductCategoryCode)
                .IsUnicode(false);

            modelBuilder.Entity<Product_Industry>()
                .Property(e => e.ProductIndustryCode)
                .IsUnicode(false);

            modelBuilder.Entity<Tables_tb>()
                .Property(e => e.Use_As)
                .IsUnicode(false);

            modelBuilder.Entity<Templates_tb>()
                .Property(e => e.Template_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Ticket_ActionHistory>()
                .Property(e => e.LogDateTime)
                .HasPrecision(0);

            modelBuilder.Entity<Ticket_Publishers>()
                .Property(e => e.TaiKhoan)
                .IsUnicode(false);

            modelBuilder.Entity<Ticket_Publishers>()
                .Property(e => e.TicketPublisherICode)
                .IsUnicode(false);

            modelBuilder.Entity<Ticket_StatusHistory>()
                .Property(e => e.LogDateTime)
                .HasPrecision(0);

            modelBuilder.Entity<Ticket_Types>()
                .Property(e => e.Code)
                .IsUnicode(false);

            modelBuilder.Entity<Ticket>()
                .Property(e => e.TicketCode)
                .IsUnicode(false);

            modelBuilder.Entity<Ticket>()
                .Property(e => e.PhoneInOrder)
                .IsUnicode(false);

            modelBuilder.Entity<Ticket>()
                .Property(e => e.PhoneOfCall)
                .IsUnicode(false);

            modelBuilder.Entity<Ticket>()
                .Property(e => e.CreatedDate)
                .HasPrecision(0);

            modelBuilder.Entity<Ticket>()
                .Property(e => e.ModifiedDate)
                .HasPrecision(0);
        }
    }
}
