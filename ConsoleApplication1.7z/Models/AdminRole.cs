namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AdminRole
    {
        [Key]
        public int AURID { get; set; }

        [StringLength(50)]
        public string RoleName { get; set; }

        public DateTime? CreateDate { get; set; }

        public bool? Visible { get; set; }

        public int? LastUpdatedUserID { get; set; }
    }
}
