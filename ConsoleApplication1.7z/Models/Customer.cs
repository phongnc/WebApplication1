namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Customer
    {
        public int CustomerID { get; set; }

        [StringLength(20)]
        public string CustomerCode { get; set; }

        public int DomainID { get; set; }

        [StringLength(250)]
        public string Title { get; set; }

        [StringLength(25)]
        public string PhoneNo { get; set; }

        [StringLength(25)]
        public string SecondPhoneNo { get; set; }

        [StringLength(25)]
        public string VinGroupCardNo { get; set; }

        [StringLength(250)]
        public string Address { get; set; }

        [StringLength(1024)]
        public string Description { get; set; }

        [StringLength(1024)]
        public string Description1 { get; set; }

        [StringLength(1024)]
        public string JsonData { get; set; }

        public bool IsBlock { get; set; }

        public bool IsDelete { get; set; }
    }
}
