namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AdminUser
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int UID { get; set; }

        public int? CityID { get; set; }

        [StringLength(250)]
        public string Name { get; set; }

        public DateTime? CreateDate { get; set; }

        public int? AUTID { get; set; }

        public int? ManagerID { get; set; }

        public bool? Visible { get; set; }

        public int? LastUpdatedUserID { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [StringLength(50)]
        public string NickName { get; set; }

        [StringLength(50)]
        public string Phone { get; set; }

        [StringLength(50)]
        public string CaLamViec { get; set; }

        [StringLength(50)]
        public string CiscoNumber { get; set; }

        [StringLength(50)]
        public string CiscoAgent { get; set; }

        [StringLength(250)]
        public string JsonData { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserID { get; set; }
    }
}
