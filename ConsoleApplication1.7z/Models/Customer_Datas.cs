namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Customer_Datas
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CustomerID { get; set; }

        [StringLength(50)]
        public string PersonalID { get; set; }

        public int? Gender { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DateOfBirth { get; set; }

        public int? ProvinceID { get; set; }

        public int? DistrictID { get; set; }

        public int? WardID { get; set; }

        public int? CardLevel { get; set; }

        public long? Point { get; set; }

        public double? TotalSales { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastContactedOn { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastCampaignOn { get; set; }
    }
}
