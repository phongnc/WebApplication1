namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Ticket_Publishers
    {
        [Key]
        public int TicketPublisherID { get; set; }

        public int DomainID { get; set; }

        [StringLength(250)]
        public string Title { get; set; }

        [StringLength(50)]
        public string TaiKhoan { get; set; }

        [StringLength(250)]
        public string Description { get; set; }

        public bool IsDelete { get; set; }

        [StringLength(50)]
        public string TicketPublisherICode { get; set; }
    }
}
