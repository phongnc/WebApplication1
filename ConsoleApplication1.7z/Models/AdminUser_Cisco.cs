namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AdminUser_Cisco
    {
        public int ID { get; set; }

        public int UID { get; set; }

        public int? CiscoID { get; set; }

        [StringLength(50)]
        public string CiscoCode { get; set; }
    }
}
