namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AdminController")]
    public partial class AdminController
    {
        [Key]
        public int AUCID { get; set; }

        [Required]
        [StringLength(100)]
        public string ControllerName { get; set; }

        [StringLength(100)]
        public string ControllerDisplayName { get; set; }

        [StringLength(100)]
        public string CssIcon { get; set; }

        public DateTime? CreateDate { get; set; }

        public int? Sort { get; set; }

        public bool? Visible { get; set; }

        public int? LastUpdatedUserID { get; set; }

        public DateTime? LastUpdated { get; set; }
    }
}
