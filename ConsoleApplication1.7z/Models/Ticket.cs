namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Ticket
    {
        [Key]
        public int TID { get; set; }

        [StringLength(50)]
        public string TicketCode { get; set; }

        public int? OwnerID { get; set; }

        public int? DomainID { get; set; }

        public int? DomainPhongBanID { get; set; }

        public int? TicketPublisherID { get; set; }

        public int? TicketTypeID { get; set; }

        public int? ProductIndustryID { get; set; }

        public int? ProductCategoryID { get; set; }

        [StringLength(500)]
        public string ProductType { get; set; }

        public int? Priority { get; set; }

        [StringLength(15)]
        public string PhoneInOrder { get; set; }

        [StringLength(15)]
        public string PhoneOfCall { get; set; }

        [StringLength(500)]
        public string Title { get; set; }

        public string Description { get; set; }

        public string Solution { get; set; }

        public string Comment { get; set; }

        public int? Ranking { get; set; }

        public int? DomainCuaHangID { get; set; }

        public int? QLSVUID { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime ModifiedDate { get; set; }

        public int CreatedUID { get; set; }

        public int ModifiedUID { get; set; }

        public int? TicketStatusID { get; set; }

        public int? TicketGroupID { get; set; }

        [StringLength(1024)]
        public string JsonData { get; set; }
    }
}
