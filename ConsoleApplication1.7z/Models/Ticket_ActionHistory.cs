namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Ticket_ActionHistory
    {
        public int ID { get; set; }

        public int TID { get; set; }

        public int UID { get; set; }

        [Required]
        public string LogData { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime LogDateTime { get; set; }
    }
}
