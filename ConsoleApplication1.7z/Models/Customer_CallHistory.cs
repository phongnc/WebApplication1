namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Customer_CallHistory
    {
        public int ID { get; set; }

        public int? TID { get; set; }

        public int? UID { get; set; }

        [StringLength(20)]
        public string PhoneNo { get; set; }

        [StringLength(20)]
        public string CiscoNo { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LogDateTime { get; set; }
    }
}
