namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Ticket_Types
    {
        [Key]
        public int TicketTypeID { get; set; }

        public int DomainID { get; set; }

        public int TicketGroupID { get; set; }

        [StringLength(250)]
        public string Title { get; set; }

        [StringLength(15)]
        public string Code { get; set; }

        public int TGXL { get; set; }

        public bool IsDelete { get; set; }

        [StringLength(500)]
        public string TypeDescription { get; set; }
    }
}
