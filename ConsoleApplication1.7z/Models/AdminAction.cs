namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AdminAction")]
    public partial class AdminAction
    {
        [Key]
        public int AUAID { get; set; }

        public int AUCID { get; set; }

        [Required]
        [StringLength(100)]
        public string ActionName { get; set; }

        [StringLength(100)]
        public string ActionDisplayName { get; set; }

        [StringLength(100)]
        public string CssIcon { get; set; }

        public DateTime? CreateDate { get; set; }

        public bool ShowMenuStatus { get; set; }

        public bool PublicStatus { get; set; }

        public int? Sort { get; set; }

        public bool? Visible { get; set; }

        public bool? IsDefault { get; set; }

        public int? LastUpdatedUserID { get; set; }

        public DateTime? LastUpdated { get; set; }
    }
}
