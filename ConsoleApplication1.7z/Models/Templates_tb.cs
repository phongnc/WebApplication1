namespace ConsoleApplication1.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Templates_tb
    {
        [Key]
        [StringLength(50)]
        public string Template_Name { get; set; }

        [Column(TypeName = "ntext")]
        public string Template_Content { get; set; }
    }
}
