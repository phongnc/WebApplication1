﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;

namespace ConsoleApplication1
{
    public class TSummary<T>
    {
        public int id;
        //cac field khac
    }
    public class TView<T>
    {
        public T model;
        //cac summary khac
    }
    public class TMore<T>
    {
        public T model;
        //cac model khac
    }
    public class TFull<T>
    {
        public T model;
        //cac list khac
    }
    public class TFilter<T>
    {
        //cac summary khac
        //cac filter khac
    }
    public class BaseRepository<T>
    {
        public SqlConnection connection;
        public string indexQuery = "SELECT * FROM apox.Customers";
        public string filterQuery =
            "SELECT * FROM apox.customerStatus; " +
            "SELECT * FROM apox.customerRating;";
        public string detailQuery = "SELECT * FROM apox.Customers WHERE Id = @Id";
        public string viewlQuery = "SELECT * FROM apox.Customers WHERE Id = @Id";
        public string moreQuery =
            "SELECT * FROM apox.Customers WHERE Id = @Id; " +
            "SELECT * FROM apox.Orders WHERE CustomerId = @Id;";
        public string fullQuery =
            "SELECT * FROM apox.Customers WHERE Id = @Id; " +
            "SELECT * FROM apox.Orders WHERE CustomerId = @Id;";
        public string insertQuery = 
            "INSERT INTO apox.Customers (Vat,Email,FirstName,LastName,Phone,Address,StatusId,RatingId) VALUES(@Vat, @Email, @FirstName, @LastName,@Phone,@Address,@StatusId,@RatingId); " +
            "SELECT CAST(SCOPE_IDENTITY() as int)";
        public string updateQuery =
             "UPDATE apox.Customers " +
             "SET Vat = @Vat, " +
             "    Email     = @Email, " +
             "    FirstName = @FirstName, " +
             "    LastName  = @LastName, " +
             "    Phone     = @Phone, " +
             "    Address   = @Address, " +
             "    StatusId  = @StatusId, " +
             "    RatingId  = @RatingId " +
             "WHERE Id = @Id";
        public string deleteQuery = "DELETE FROM apox.Customers WHERE Id = @Id";
        public string catalogQuery = "SELECT title,id FROM apox.customerStatus;";

        public BaseRepository()
        {
            connection = new SqlConnection(@"data source=TITMIT-PC\SQLEXPRESS;initial catalog=apox;user id=sa;password=1234;MultipleActiveResultSets=True;");
        }
        public List<T> Index()
        {
            return connection.Query<T>(indexQuery).ToList();
        }
        public TFilter<T> Filter()
        {
            //using (var multipleResults = connection.QueryMultiple(filterQuery))
            //{
            //    var customerDropdown = new CustomerDropdownsModel();
            //    var status = multipleResults.Read<CustomerStatusModel>().ToList();
            //    var ratings = multipleResults.Read<CustomerRatingModel>().ToList();
            //    if (status != null && ratings != null)
            //    {
            //        customerDropdown.CustomerRating.AddRange(ratings);
            //        customerDropdown.CustomerStatus.AddRange(status);
            //    }
            //    return customerDropdown;
            //}
            return null;
        }
        public T Detail(int id)
        {
            return connection.Query<T>(detailQuery, new { id }).SingleOrDefault();
        }
        public TView<T> View(int id)
        {
            return connection.Query<TView<T>>(detailQuery, new { id }).SingleOrDefault();
        }
        public TMore<T> More(int id)
        {
            //using (var multipleResults = this.connection.QueryMultiple(moreQuery, new { Id = id }))
            //{
            //    var customers = multipleResults.Read<customersModel>().SingleOrDefault();
            //    var orders = multipleResults.Read<ordersModel>().ToList();
            //    if (customers != null && orders != null)
            //    {
            //        customers.Orders.AddRange(orders);
            //    }
            //    return customers;
            //}
            return null;
        }
        public TFull<T> Full(int id)
        {
            //using (var multipleResults = this.connection.QueryMultiple(moreQuery, new { Id = id }))
            //{
            //    var customers = multipleResults.Read<customersModel>().SingleOrDefault();
            //    var orders = multipleResults.Read<ordersModel>().ToList();
            //    if (customers != null && orders != null)
            //    {
            //        customers.Orders.AddRange(orders);
            //    }
            //    return customers;
            //}
            return null;
        }
        public T Insert(T model)
        {
            var id = connection.Query<int>(insertQuery, model).Single();
            //model.Id = id;
            return model;
        }
        public T Update(T model)
        {
            connection.Execute(updateQuery, model);
            return model;
        }
        public void Delete(int id)
        {
            connection.Execute(deleteQuery, new { id });
        }
        public List<TSummary<T>> Catalog()
        {
            return connection.Query<TSummary<T>>(catalogQuery).ToList();
        }
    }
}
