public class DomainsModel
{
    public int DomainID;
    public string Title;
    public bool IsDelete;
}
