﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplication1.Models;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            new GenerateTool().Generate("Domains");
        }
    }
    public class GenerateTool
    {
        string path = @"D:\_APPCOLLECTION\WebApplication1\ConsoleApplication1\Generate\";
        public void Generate(string tableName)
        {
            Model1 db = new Model1();
            Tables_vw tvw = db.Tables_vw.Where(o => o.Table_Name == tableName).Single();
            List<Columns_vw> cvws = db.Columns_vw.Where(o => o.Table_Name == tableName).ToList();
            string strModel = "";
            strModel += "public class " + tableName + "Model\n{";
            for (int i = 0; i < cvws.Count; i++)
            {
                strModel += "\n" + "public " + TranslateType(cvws[i].Data_Type) + " " + cvws[i].Column_Name + ";";
            }
            strModel += "\n}";
            try
            {
                using (StreamWriter writer = new StreamWriter(path + tableName + "Model.cs", false))
                {
                    writer.WriteLine(strModel);
                }
            }
            catch { }
        }
        public string TranslateType(string sqlType)
        {
            string[] sqlTypes = new string[] { "bigint", "bit", "char", "datetime", "datetime2", "float", "int", "ntext", "nvarchar", "varchar" };
            string[] netTypes = new string[] { "long", "bool", "char", "DateTime", "DateTime", "float", "int", "string", "string", "string" };
            for (int i = 0; i < sqlTypes.Length; i++)
            {
                if (sqlTypes[i] == sqlType) return netTypes[i];
            }
            return "";
        }
    }
}
