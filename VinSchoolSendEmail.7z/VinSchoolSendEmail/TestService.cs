﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.IO;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using VinSchoolSendEmail.Models.EF;

namespace VinSchoolSendEmail
{
    public partial class TestService : ServiceBase
    {
        System.Timers.Timer timeDelay;
        bool flag = false;
        public TestService()
        {
            InitializeComponent();
            timeDelay = new System.Timers.Timer();
            timeDelay.Interval = 30000;
            timeDelay.Elapsed += new System.Timers.ElapsedEventHandler(WorkProcess);
        }
        public void WorkProcess(object sender, System.Timers.ElapsedEventArgs e)
        {
            LogService("Service is viewing"  + flag.ToString());
            if (!flag)
            {
                Models.DP.Model1 db = new Models.DP.Model1();
                List<BusHocSinh> _listBus = new List<BusHocSinh>();
                _listBus = db.BusHocSinhs.SelectRange("TrangThai IN (2,4) AND CreatedDate IS NULL").ToList();
                if (_listBus.Count == 0) flag = false;
                else
                {
                    flag = true;
                    for (int i = 0; i < _listBus.Count; i++)
                    {
                        string result = "";
                        try { result = SendEmailBusHocSinh(_listBus[i]); } catch (Exception ex) { result = ex.Message; }
                        LogService(result);
                    }
                    flag = false;
                }
            }
        }
        protected override void OnStart(string[] args)
        {
            LogService("Service is Started");
            timeDelay.Enabled = true;
        }
        protected override void OnStop()
        {
            LogService("Service Stoped");
            timeDelay.Enabled = false;
        }
        private void SendService()
        {

        }
        private void LogService(string content)
        {
            var x = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"EmailServiceLog.txt");
            FileStream fs = new FileStream(x, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.BaseStream.Seek(0, SeekOrigin.End);
            sw.WriteLine(content);
            sw.Flush();
            sw.Close();
        }
        public static bool SendEmail(string strSubject, string strTo, string strContent, string strPathAttach = "")
        {
            string strName = ConfigurationManager.AppSettings["MailName"].ToString();// GetValueConfig("MailName" + ma_Mien);
            string strFrom = ConfigurationManager.AppSettings["MailFrom"].ToString();// GetValueConfig("MailFrom" + ma_Mien);
            string strUsername = ConfigurationManager.AppSettings["MaiUsername"].ToString();// GetValueConfig("MaiUsername" + ma_Mien);
            string strPassword = ConfigurationManager.AppSettings["MailPassword"].ToString();// GetValueConfig("MailPassword" + ma_Mien);
            string strSMTPServer = ConfigurationManager.AppSettings["SMTPServer"].ToString();// GetValueConfig("SMTPServer");
            string strSMTPPort = ConfigurationManager.AppSettings["SMTPPort"].ToString();// GetValueConfig("SMTPPort");
            try
            {
                using (System.Net.Mail.MailMessage objMailMessage = new System.Net.Mail.MailMessage())
                {
                    objMailMessage.From = new System.Net.Mail.MailAddress(strFrom, strName, System.Text.Encoding.Unicode);
                    objMailMessage.To.Add(new System.Net.Mail.MailAddress(strTo, strTo, System.Text.Encoding.Unicode));
                    objMailMessage.Subject = strSubject;
                    objMailMessage.IsBodyHtml = true;
                    objMailMessage.BodyEncoding = System.Text.Encoding.Unicode;
                    objMailMessage.Body = strContent;
                    try
                    {
                        if (!string.IsNullOrEmpty(strPathAttach))
                        {
                            System.Net.Mail.Attachment attach = new System.Net.Mail.Attachment(strPathAttach);
                            objMailMessage.Attachments.Add(attach);
                        }
                    }
                    catch { }
                    System.Net.NetworkCredential credential = new System.Net.NetworkCredential(strUsername, strPassword, "vingroup.net");
                    System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient(strSMTPServer, int.Parse(strSMTPPort));
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = credential;
                    if (strSMTPPort != "25") smtpClient.EnableSsl = true;
                    smtpClient.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    try
                    {
                        smtpClient.Send(objMailMessage);
                    }
                    catch (Exception ex)
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public static string SendEmailBusHocSinh(Models.EF.BusHocSinh _bhs)
        {
            string result = "Xem hoc sinh " + _bhs.HocSinhID.ToString();
            Models.DP.Model1 db = new Models.DP.Model1();
            try
            {
                Models.EF.HocSinh _hs = db.HocSinhs.Select("HocSinhID = @HocSinhID", new { HocSinhID = _bhs.HocSinhID });
                var objx = db.DKXBHocSinhs.Select("MaHocSinh = @MaHocSinh ORDER BY DKXBHocSinhID DESC", new { MaHocSinh = _hs.MaHocSinh });
                var jo = Newtonsoft.Json.Linq.JObject.Parse(objx.JsonData);
                var _appu = db.AppUsers.Select("MaHocSinh = @MaHocSinh", new { MaHocSinh = _hs.MaHocSinh });
                Tuyen _tuyen = new Tuyen(); Diem _diemdon = new Diem(); Diem _diemtra = new Diem();
                TuyenDiem _tuyen_diemdon = new TuyenDiem(); TuyenDiem _tuyen_diemtra = new TuyenDiem();
                KhuVuc _khuvuc = new KhuVuc(); CosoTruong _truong = new CosoTruong(); CosoHe _he = new CosoHe();
                XeDriver _laixe = new XeDriver(); XeManager _qlxe = new XeManager();
                try
                {
                    _tuyen = db.Tuyens.Select("TuyenID = @TuyenID", new { TuyenID = _bhs.TuyenID });
                }
                catch { }
                if (_tuyen.TuyenID == 0)
                {
                    var fileContents = System.IO.File.ReadAllText(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Email_tu_choi_cung_cap_dich_vu.html"));
                    try
                    {
                        try { _diemdon = db.Diems.Select("DiemID = @DiemID", new { DiemID = _bhs.DiemDonID }); } catch { }
                        try { _diemtra = db.Diems.Select("DiemID = @DiemID", new { DiemID = _bhs.DiemTraID }); } catch { }
                        try { _tuyen_diemdon = db.TuyenDiems.Select("TuyenID = @TuyenID AND DiemID = @DiemID", new { TuyenID = _tuyen.TuyenID, DiemID = _diemdon.DiemID }); } catch { }
                        try { _tuyen_diemtra = db.TuyenDiems.Select("TuyenID = @TuyenID AND DiemID = @DiemID", new { TuyenID = _tuyen.TuyenID, DiemID = _diemtra.DiemID }); } catch { }
                        try { _khuvuc = db.KhuVucs.Select("KhuVucID = @KhuVucID", new { KhuVucID = _diemdon.KhuVucID }); } catch { }
                        try { _truong = db.CosoTruongs.Select("CosoTruongID = @CosoTruongID", new { CosoTruongID = _khuvuc.CosoTruongID }); } catch { _truong.TenTruong = jo["Truong"].ToString(); }
                        try { _he = db.CosoHes.Select("CosoHeID = @CosoHeID", new { CosoHeID = _khuvuc.CosoHeID }); } catch { _he.TenHe = jo["He"].ToString(); }
                        try { _laixe = db.XeDrivers.Select("XeDriverID = @XeDriverID", new { XeDriverID = _tuyen.XeDriverID }); } catch { }
                        try { _qlxe = db.XeManagers.Select("XeManagerID = @XeManagerID", new { XeManagerID = _tuyen.XeManagerID }); } catch { }
                        string _strDiachi = "";
                        string _strTaidau = "Tại điểm";
                        if (_diemdon.LoaiDiem == 0)
                        {
                            _strTaidau = "Tại nhà";
                            //List<string> _strDiachis = new List<string>();
                            //try { string _ID_temp = db2.DMTinhs.First(o => o.ID_tinh == objx.ID_tinh).Ten_tinh; if (!string.IsNullOrEmpty(_ID_temp)) _strDiachis.Add(_ID_temp); } catch { }
                            //try { string _ID_temp = db2.DMHuyens.First(o => o.ID_huyen == objx.ID_huyen).Ten_huyen; if (!string.IsNullOrEmpty(_ID_temp)) _strDiachis.Add(_ID_temp); } catch { }
                            //try { string _ID_temp = db2.DMXas.First(o => o.ID_xa == objx.ID_xa).Ten_xa; if (!string.IsNullOrEmpty(_ID_temp)) _strDiachis.Add(_ID_temp); } catch { }
                            //_strDiachi = String.Join(", ", _strDiachis);
                        }
                        string _strHinhthuc = "Học sinh tự đón xe tại điểm đón/tự về tại điểm trả"; if (!string.IsNullOrEmpty(objx.Hinh_thuc_gs)) _strHinhthuc = "Phụ huynh trao học sinh tận tay cho Giám sát xe";
                        if (string.IsNullOrEmpty(objx.Khoang_cach)) objx.Khoang_cach = "";
                        try { fileContents = fileContents.Replace("@Truong", string.IsNullOrEmpty(_truong.TenTruong) ? "" : _truong.TenTruong).Replace("@He", string.IsNullOrEmpty(_he.TenHe) ? "" : _he.TenHe).Replace("@Ma_hs", _appu.MaHocSinh).Replace("@Ten_hs", _hs.HoTen); } catch { }
                        try { fileContents = fileContents.Replace("@Loai_hinh_dich_vu", _strTaidau).Replace("@Ten_hinh_thuc", _strHinhthuc).Replace("@Ngay_su_dung", string.IsNullOrEmpty(objx.Ngay_dk) ? "" : objx.Ngay_dk).Replace("@Dia_chi", string.IsNullOrEmpty(_strDiachi) ? objx.Dia_chi : objx.Dia_chi + ", " + _strDiachi).Replace("@Khoang_cach", string.IsNullOrEmpty(objx.Khoang_cach) ? "" : objx.Khoang_cach.ToString()); } catch { }
                        try { fileContents = fileContents.Replace("@Diem_don", string.IsNullOrEmpty(_diemdon.DiemDon) ? "" : _diemdon.DiemDon).Replace("@Thoi_gian_don_du_kien", string.IsNullOrEmpty(_tuyen_diemdon.GioDon) ? "" : _tuyen_diemdon.GioDon).Replace("@Diem_tra", string.IsNullOrEmpty(_diemtra.DiemTra) ? "" : _diemtra.DiemTra).Replace("@Thoi_gian_tra_du_kien", string.IsNullOrEmpty(_tuyen_diemdon.GioTra) ? "" : _tuyen_diemdon.GioTra); } catch { }
                        try { fileContents = fileContents.Replace("@Tuyen_xe", _tuyen.MaTuyen); } catch { }
                        try { fileContents = fileContents.Replace("@Lai_xe", _laixe.HoTen); } catch { }
                        try { fileContents = fileContents.Replace("@Quan_ly_xe", _qlxe.HoTen); } catch { }
                        try { fileContents = fileContents.Replace("@Dien_thoai_lai_xe", _laixe.Phone); } catch { }
                        try { fileContents = fileContents.Replace("@Dien_thoai_quan_ly", _qlxe.Phone); } catch { }
                        try { if (string.IsNullOrEmpty(objx.Ma_hoc_sinh_ace)) objx.Ma_hoc_sinh_ace = ""; fileContents = fileContents.Replace("@Ma_anh_chi_em", objx.Ma_hoc_sinh_ace); } catch { }
                    }
                    catch { }
                    bool _f = SendEmail("Từ chối cung cấp dịch vụ", _appu.Email, fileContents);
                    if (_f) _bhs.TrangThai = 5; else _bhs.TrangThai = 4;
                    result = _f ? "Gửi từ chối thành công " + _appu.Email : "Gửi từ chối thất bại " + _appu.Email;
                }
                else
                {
                    var fileContents = System.IO.File.ReadAllText(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Email_xac_nhan_dang_ky_thanh_cong_dich_vu_xe_buyt.html"));
                    try
                    {
                        try { _diemdon = db.Diems.Select("DiemID = @DiemID", new { DiemID = _bhs.DiemDonID }); } catch { }
                        try { _diemtra = db.Diems.Select("DiemID = @DiemID", new { DiemID = _bhs.DiemTraID }); } catch { }
                        try { _tuyen_diemdon = db.TuyenDiems.Select("TuyenID = @TuyenID AND DiemID = @DiemID", new { TuyenID = _tuyen.TuyenID, DiemID = _diemdon.DiemID }); } catch { }
                        try { _tuyen_diemtra = db.TuyenDiems.Select("TuyenID = @TuyenID AND DiemID = @DiemID", new { TuyenID = _tuyen.TuyenID, DiemID = _diemtra.DiemID }); } catch { }
                        try { _khuvuc = db.KhuVucs.Select("KhuVucID = @KhuVucID", new { KhuVucID = _diemdon.KhuVucID }); } catch { }
                        try { _truong = db.CosoTruongs.Select("CosoTruongID = @CosoTruongID", new { CosoTruongID = _khuvuc.CosoTruongID }); } catch { _truong.TenTruong = jo["Truong"].ToString(); }
                        try { _he = db.CosoHes.Select("CosoHeID = @CosoHeID", new { CosoHeID = _khuvuc.CosoHeID }); } catch { _he.TenHe = jo["He"].ToString(); }
                        try { _laixe = db.XeDrivers.Select("XeDriverID = @XeDriverID", new { XeDriverID = _tuyen.XeDriverID }); } catch { }
                        try { _qlxe = db.XeManagers.Select("XeManagerID = @XeManagerID", new { XeManagerID = _tuyen.XeManagerID }); } catch { }
                        string _strDiachi = "";
                        string _strTaidau = "Tại điểm";
                        if (_diemdon.LoaiDiem == 0)
                        {
                            _strTaidau = "Tại nhà";
                            //List<string> _strDiachis = new List<string>();
                            //try { string _ID_temp = db2.DMTinhs.First(o => o.ID_tinh == objx.ID_tinh).Ten_tinh; if (!string.IsNullOrEmpty(_ID_temp)) _strDiachis.Add(_ID_temp); } catch { }
                            //try { string _ID_temp = db2.DMHuyens.First(o => o.ID_huyen == objx.ID_huyen).Ten_huyen; if (!string.IsNullOrEmpty(_ID_temp)) _strDiachis.Add(_ID_temp); } catch { }
                            //try { string _ID_temp = db2.DMXas.First(o => o.ID_xa == objx.ID_xa).Ten_xa; if (!string.IsNullOrEmpty(_ID_temp)) _strDiachis.Add(_ID_temp); } catch { }
                            //_strDiachi = String.Join(", ", _strDiachis);
                        }
                        string _strHinhthuc = "Học sinh tự đón xe tại điểm đón/tự về tại điểm trả"; if (!string.IsNullOrEmpty(objx.Hinh_thuc_gs)) _strHinhthuc = "Phụ huynh trao học sinh tận tay cho Giám sát xe";
                        if (string.IsNullOrEmpty(objx.Khoang_cach)) objx.Khoang_cach = "";
                        try { fileContents = fileContents.Replace("@Truong", string.IsNullOrEmpty(_truong.TenTruong) ? "" : _truong.TenTruong).Replace("@He", string.IsNullOrEmpty(_he.TenHe) ? "" : _he.TenHe).Replace("@Ma_hs", _appu.MaHocSinh).Replace("@Ten_hs", _hs.HoTen); } catch { }
                        try { fileContents = fileContents.Replace("@Loai_hinh_dich_vu", _strTaidau).Replace("@Ten_hinh_thuc", _strHinhthuc).Replace("@Ngay_su_dung", string.IsNullOrEmpty(objx.Ngay_dk) ? "" : objx.Ngay_dk).Replace("@Dia_chi", string.IsNullOrEmpty(_strDiachi) ? objx.Dia_chi : objx.Dia_chi + ", " + _strDiachi).Replace("@Khoang_cach", string.IsNullOrEmpty(objx.Khoang_cach) ? "" : objx.Khoang_cach.ToString()); } catch { }
                        try { fileContents = fileContents.Replace("@Diem_don", string.IsNullOrEmpty(_diemdon.DiemDon) ? "" : _diemdon.DiemDon).Replace("@Thoi_gian_don_du_kien", string.IsNullOrEmpty(_tuyen_diemdon.GioDon) ? "" : _tuyen_diemdon.GioDon).Replace("@Diem_tra", string.IsNullOrEmpty(_diemtra.DiemTra) ? "" : _diemtra.DiemTra).Replace("@Thoi_gian_tra_du_kien", string.IsNullOrEmpty(_tuyen_diemdon.GioTra) ? "" : _tuyen_diemdon.GioTra); } catch { }
                        try { fileContents = fileContents.Replace("@Tuyen_xe", _tuyen.MaTuyen); } catch { }
                        try { fileContents = fileContents.Replace("@Lai_xe", _laixe.HoTen); } catch { }
                        try { fileContents = fileContents.Replace("@Quan_ly_xe", _qlxe.HoTen); } catch { }
                        try { fileContents = fileContents.Replace("@Dien_thoai_lai_xe", _laixe.Phone); } catch { }
                        try { fileContents = fileContents.Replace("@Dien_thoai_quan_ly", _qlxe.Phone); } catch { }
                        try { if (string.IsNullOrEmpty(objx.Ma_hoc_sinh_ace)) objx.Ma_hoc_sinh_ace = ""; fileContents = fileContents.Replace("@Ma_anh_chi_em", objx.Ma_hoc_sinh_ace); } catch { }
                    }
                    catch { }
                    bool _f = SendEmail("Xác nhận xếp tuyến dịch vụ xe bus", _appu.Email, fileContents);
                    if (_f) _bhs.TrangThai = 3; else _bhs.TrangThai = 2;
                    result = _f ? "Gửi xác nhận thành công " + _appu.Email : "Gửi xác nhận thất bại " + _appu.Email;
                }
            }
            catch { }
            _bhs.CreatedDate = DateTime.Now;
            db.BusHocSinhs.Update(_bhs);
            return result;
        }
    }
}
