﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VinSchoolSendEmail.Models.DO
{
    public class EObject
    {
        public string StringValue = "";
        public string TitValue = "";
        public string ICD = "";
        public int IID = 0;
    }
    public class COConfig
    {
        public string TableName = "";
        public string ColumnName = "";
        public string FTableName = "";
        public string FValueColumnName = "";
        public string FTextColumnName = "";
    }
    public class COManuals
    {
        public List<COConfig> EnumConfigs = new List<COConfig>();
        public List<COConfig> ClientConfigs = new List<COConfig>();
        public COManuals()
        {
            //COConfig _clConfig1 = new COConfig()
            //{
            //    TableName = "IPMAuthors_Tb",
            //    ColumnName = "Biiography",
            //    FTableName = "dxTextArea"
            //};
            //COConfig _clConfig2 = new COConfig()
            //{
            //    TableName = "IPMNewss_Tb",
            //    ColumnName = "Title",
            //    FTableName = "dxDetailLink",
            //    FValueColumnName = "IPMNews_id"
            //};
            //COConfig _clConfig3 = new COConfig()
            //{
            //    TableName = "IPMNewss_Tb",
            //    ColumnName = "Image",
            //    FTableName = "dxImageEditor"
            //};
            //COConfig _clConfig4 = new COConfig()
            //{
            //    TableName = "IPMNewss_Tb",
            //    ColumnName = "Content",
            //    FTableName = "dxHtmlEditor"
            //};
            //COConfig _clConfig5 = new COConfig()
            //{
            //    TableName = "IPMArticles_Tb",
            //    ColumnName = "Title",
            //    FTableName = "dxDetailLink",
            //    FValueColumnName = "IPMArticle_id"
            //};
            //COConfig _clConfig6 = new COConfig()
            //{
            //    TableName = "IPMArticles_Tb",
            //    ColumnName = "Image",
            //    FTableName = "dxImageEditor"
            //};
            //COConfig _clConfig7 = new COConfig()
            //{
            //    TableName = "IPMArticles_Tb",
            //    ColumnName = "Abstract",
            //    FTableName = "dxHtmlEditor"
            //};
            //ClientConfigs.Add(_clConfig1);
            //ClientConfigs.Add(_clConfig2);
            //ClientConfigs.Add(_clConfig3);
            //ClientConfigs.Add(_clConfig4);
            //ClientConfigs.Add(_clConfig5);
            //ClientConfigs.Add(_clConfig6);
            //ClientConfigs.Add(_clConfig7);
            COConfig _coConfig101 = new COConfig()
            {
                TableName = "Huyen",
                ColumnName = "TinhID",
                FTableName = "Tinh",
                FValueColumnName = "TinhID",
                FTextColumnName = "TenTinh"
            };
            COConfig _coConfig102 = new COConfig()
            {
                TableName = "Xa",
                ColumnName = "HuyenID",
                FTableName = "Huyen",
                FValueColumnName = "HuyenID",
                FTextColumnName = "TenHuyen"
            };
            COConfig _coConfig111 = new COConfig()
            {
                TableName = "CosoHe",
                ColumnName = "CosoTruongID",
                FTableName = "CosoTruong",
                FValueColumnName = "CosoTruongID",
                FTextColumnName = "TenTruong"
            };
            COConfig _coConfig112 = new COConfig()
            {
                TableName = "KhuVuc",
                ColumnName = "CosoTruongID",
                FTableName = "CosoTruong",
                FValueColumnName = "CosoTruongID",
                FTextColumnName = "TenTruong"
            };
            COConfig _coConfig113 = new COConfig()
            {
                TableName = "KhuVuc",
                ColumnName = "CosoHeID",
                FTableName = "CosoHe",
                FValueColumnName = "CosoHeID",
                FTextColumnName = "TenHe"
            };
            COConfig _coConfig121 = new COConfig()
            {
                TableName = "XeVehice",
                ColumnName = "XeCompanyID",
                FTableName = "XeCompany",
                FValueColumnName = "XeCompanyID",
                FTextColumnName = "Ten"
            };
            COConfig _coConfig122 = new COConfig()
            {
                TableName = "XeDriver",
                ColumnName = "XeCompanyID",
                FTableName = "XeCompany",
                FValueColumnName = "XeCompanyID",
                FTextColumnName = "Ten"
            };
            COConfig _coConfig123 = new COConfig()
            {
                TableName = "XeManager",
                ColumnName = "XeCompanyID",
                FTableName = "XeCompany",
                FValueColumnName = "XeCompanyID",
                FTextColumnName = "Ten"
            };
            COConfig _coConfig131 = new COConfig()
            {
                TableName = "Tuyen",
                ColumnName = "XeVehiceID",
                FTableName = "XeVehice",
                FValueColumnName = "XeVehiceID",
                FTextColumnName = "BienSo"
            };
            COConfig _coConfig132 = new COConfig()
            {
                TableName = "Tuyen",
                ColumnName = "XeDriverID",
                FTableName = "XeDriver",
                FValueColumnName = "XeDriverID",
                FTextColumnName = "HoTen"
            };
            COConfig _coConfig133 = new COConfig()
            {
                TableName = "Tuyen",
                ColumnName = "XeManagerID",
                FTableName = "XeManager",
                FValueColumnName = "XeManagerID",
                FTextColumnName = "HoTen"
            };
            COConfig _coConfig134 = new COConfig()
            {
                TableName = "Diem",
                ColumnName = "KhuVucID",
                FTableName = "KhuVuc",
                FValueColumnName = "KhuVucID",
                FTextColumnName = "TenKhuVuc"
            };
            COConfig _coConfig135 = new COConfig()
            {
                TableName = "TuyenDiem",
                ColumnName = "TuyenID",
                FTableName = "Tuyen",
                FValueColumnName = "TuyenID",
                FTextColumnName = "MaTuyen"
            };
            COConfig _coConfig136 = new COConfig()
            {
                TableName = "TuyenDiem",
                ColumnName = "DiemID",
                FTableName = "Diem",
                FValueColumnName = "DiemID",
                FTextColumnName = "MaDiem"
            };
            COConfig _coConfig137 = new COConfig()
            {
                TableName = "BusHocSinh",
                ColumnName = "HocSinhID",
                FTableName = "HocSinh",
                FValueColumnName = "HocSinhID",
                FTextColumnName = "HoTen"
            };
            COConfig _coConfig138 = new COConfig()
            {
                TableName = "BusHocSinh",
                ColumnName = "TuyenID",
                FTableName = "Tuyen",
                FValueColumnName = "TuyenID",
                FTextColumnName = "MaTuyen"
            };
            COConfig _coConfig139 = new COConfig()
            {
                TableName = "BusHocSinh",
                ColumnName = "DiemDonID",
                FTableName = "Diem",
                FValueColumnName = "DiemID",
                FTextColumnName = "MaDiem"
            };
            COConfig _coConfig140 = new COConfig()
            {
                TableName = "BusHocSinh",
                ColumnName = "DiemTraID",
                FTableName = "Diem",
                FValueColumnName = "DiemID",
                FTextColumnName = "MaDiem"
            };
            EnumConfigs.Add(_coConfig101);
            EnumConfigs.Add(_coConfig102);
            EnumConfigs.Add(_coConfig111);
            EnumConfigs.Add(_coConfig112);
            EnumConfigs.Add(_coConfig113);
            EnumConfigs.Add(_coConfig121);
            EnumConfigs.Add(_coConfig122);
            EnumConfigs.Add(_coConfig123);
            EnumConfigs.Add(_coConfig131);
            EnumConfigs.Add(_coConfig132);
            EnumConfigs.Add(_coConfig133);
            EnumConfigs.Add(_coConfig134);
            EnumConfigs.Add(_coConfig135);
            EnumConfigs.Add(_coConfig136);
            EnumConfigs.Add(_coConfig137);
            EnumConfigs.Add(_coConfig138);
            EnumConfigs.Add(_coConfig139);
            EnumConfigs.Add(_coConfig140);
        }
    }
    public class DOConfig
    {
        public string PropName = "";
        public string TypeName = "";
        public string KeyName = "";
        public string MapName = "";
    }
    public class DOModel
    {
        public string Name = "";
        public string ListViewType = "GRID"; // GRID OR LIST
        public string DetailViewType = "GROUP"; // GROUP OR TAB
        public List<DOConfig> Configs = new List<DOConfig>();
    }
    public class DOModels
    {
        List<DOModel> doModels = new List<DOModel>();
        public DOModels()
        {
            //DOModel _VinCS = new DOModel();
            //_VinCS.Name = "DOVinCS";
            //_VinCS.DetailViewType = "GROUP";
            //_VinCS.Configs.Add(new DOConfig
            //{
            //    PropName = "VinCSTicket",
            //    TypeName = "VGCase",
            //    KeyName = "VGCaseID",
            //    MapName = ""
            //});
            //_VinCS.Configs.Add(new DOConfig
            //{
            //    PropName = "VinCSTicketSLA",
            //    TypeName = "VGCaseSLA",
            //    KeyName = "VGCaseSLAID",
            //    MapName = "VGCaseSLAID",
            //});
            //_VinCS.Configs.Add(new DOConfig
            //{
            //    PropName = "VinCSKhachHang",
            //    TypeName = "VGKhachHang",
            //    KeyName = "VGKhachHangID",
            //    MapName = "VGKhachHangID",
            //});
            //doModels.Add(_VinCS);
        }
        public DOModel getModel(string name)
        {
            return doModels.First(o => o.Name == name);
        }
    }
}