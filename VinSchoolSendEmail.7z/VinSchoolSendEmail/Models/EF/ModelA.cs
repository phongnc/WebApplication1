namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ModelA : DbContext
    {
        public ModelA()
            : base("name=ModelA")
        {
        }

        public virtual DbSet<DMCapHoc> DMCapHocs { get; set; }
        public virtual DbSet<DMKhoi> DMKhois { get; set; }
        public virtual DbSet<DMHe> DMHes { get; set; }
        public virtual DbSet<DMHuyen> DMHuyens { get; set; }
        public virtual DbSet<DMTinh> DMTinhs { get; set; }
        public virtual DbSet<DMXa> DMXas { get; set; }
        public virtual DbSet<TS_HoSoHocSinh> TS_HoSoHocSinh { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
