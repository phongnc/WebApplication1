namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TS_HoSoHocSinh
    {
        [Key]
        public int ID_hs { get; set; }

        [StringLength(10)]
        public string Ma_hs { get; set; }

        [StringLength(10)]
        public string Ma_TN { get; set; }

        [Required]
        [StringLength(150)]
        public string Ho_ten { get; set; }

        [Column(TypeName = "date")]
        public DateTime Ngay_sinh { get; set; }

        public int ID_gioi_tinh { get; set; }

        public int? ID_dan_toc { get; set; }

        public int? ID_ton_giao { get; set; }

        public int? ID_quoc_tich { get; set; }

        [StringLength(150)]
        public string Dien_thoai_CD { get; set; }

        [StringLength(15)]
        public string Dien_thoai_DD { get; set; }

        [StringLength(150)]
        public string Email { get; set; }

        [StringLength(15)]
        public string CMND { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Ngay_cap { get; set; }

        [StringLength(250)]
        public string Noi_cap { get; set; }

        [StringLength(250)]
        public string Dia_chi_tt { get; set; }

        [StringLength(10)]
        public string ID_tinh_tt { get; set; }

        [StringLength(10)]
        public string ID_huyen_tt { get; set; }

        [StringLength(10)]
        public string ID_xa_tt { get; set; }

        [StringLength(250)]
        public string Dia_chi_ns { get; set; }

        [StringLength(10)]
        public string ID_tinh_ns { get; set; }

        [StringLength(10)]
        public string ID_huyen_ns { get; set; }

        [StringLength(10)]
        public string ID_xa_ns { get; set; }

        [StringLength(250)]
        public string Noi_sinh { get; set; }

        [StringLength(150)]
        public string Nguoi_bao_tin { get; set; }

        [StringLength(250)]
        public string Dia_chi_bao_tin { get; set; }

        [StringLength(15)]
        public string Dien_thoai_bao_tin { get; set; }

        public int? ID_he { get; set; }

        public int? ID_co_so { get; set; }

        public int? ID_cap_hoc { get; set; }

        public int? ID_khoi { get; set; }

        [StringLength(10)]
        public string Nam_hoc { get; set; }

        [StringLength(50)]
        public string Hoc_luc { get; set; }

        [StringLength(50)]
        public string Hanh_kiem { get; set; }

        public int? ID_truong { get; set; }

        public int ID_loai_truong { get; set; }

        public int? ID_tt_hn { get; set; }

        public int? ID_nguon { get; set; }

        public int ID_nguon_hs { get; set; }

        public DateTime? Ngay_ghi_danh { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Ngay_di_hoc { get; set; }

        public DateTime? Ngay_tiep_nhan { get; set; }

        public int? Nguoi_tao { get; set; }

        public int? Nguoi_cap_nhat { get; set; }

        public DateTime? Ngay_cap_nhat { get; set; }

        [StringLength(500)]
        public string Ghi_chu { get; set; }

        public int? ID_gia_dinh { get; set; }

        public int? ID_suc_khoe { get; set; }

        [StringLength(50)]
        public string Ten_can_ho { get; set; }

        public int ID_dia_chi { get; set; }

        public bool Hoc_sinh_vip { get; set; }

        public bool Hoc_sinh_ngoai_giao { get; set; }

        public bool Isdelete { get; set; }

        public bool Duyet_online { get; set; }

        public int? UserID_nguoi_duyet { get; set; }

        public DateTime? Ngay_duyet_online { get; set; }

        public bool Cu_dan_Vinhome { get; set; }

        public bool La_con_VGR { get; set; }
    }
}
