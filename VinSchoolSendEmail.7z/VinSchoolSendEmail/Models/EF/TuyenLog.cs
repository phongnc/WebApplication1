namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TuyenLog")]
    public partial class TuyenLog
    {
        public int TuyenLogID { get; set; }

        public int TuyenID { get; set; }

        public string JsonData { get; set; }

        public int? CreatedUID { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }
    }
}
