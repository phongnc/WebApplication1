namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Tinh")]
    public partial class Tinh
    {
        public int TinhID { get; set; }

        public string TenTinh { get; set; }

        public string MaTinh { get; set; }

        public bool? TrangThai { get; set; }
    }
}
