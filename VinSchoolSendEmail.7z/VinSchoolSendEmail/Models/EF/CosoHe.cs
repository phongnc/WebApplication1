namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CosoHe")]
    public partial class CosoHe
    {
        public int CosoHeID { get; set; }

        public int? CosoTruongID { get; set; }

        public int? ADMID { get; set; }

        public string TenHe { get; set; }

        public bool TrangThai { get; set; }
    }
}
