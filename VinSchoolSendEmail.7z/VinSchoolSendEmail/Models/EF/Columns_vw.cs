namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Columns_vw
    {
        [Key]
        [Column(Order = 0)]
        public string Table_Name { get; set; }

        [StringLength(128)]
        public string Column_Name { get; set; }

        [Key]
        [Column(Order = 1)]
        public string Data_Type { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short Max_Len { get; set; }

        [Key]
        [Column(Order = 3)]
        public bool Is_Id { get; set; }

        public bool? Is_Null { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int STT { get; set; }
    }
}
