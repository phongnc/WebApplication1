namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DMHe")]
    public partial class DMHe
    {
        [Key]
        public int ID_he { get; set; }

        [Required]
        [StringLength(5)]
        public string Ma_he { get; set; }

        [Required]
        [StringLength(50)]
        public string Ten_he { get; set; }

        [StringLength(50)]
        public string Ma_profit { get; set; }

        public bool Trang_thai { get; set; }
    }
}
