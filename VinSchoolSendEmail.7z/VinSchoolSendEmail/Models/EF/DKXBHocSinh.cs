namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DKXBHocSinh")]
    public partial class DKXBHocSinh
    {
        public int DKXBHocSinhID { get; set; }

        [StringLength(50)]
        public string Nam_hoc { get; set; }

        [StringLength(10)]
        public string MaHocSinh { get; set; }

        [StringLength(150)]
        public string HoTen { get; set; }

        [StringLength(10)]
        public string Tai_dau { get; set; }

        public int? DKXBAction { get; set; }

        public int? CosoTruongID { get; set; }

        public int? CosoHeID { get; set; }

        [StringLength(10)]
        public string ID_khu_vuc { get; set; }

        [StringLength(10)]
        public string ID_diem_don { get; set; }

        [StringLength(10)]
        public string ID_diem_tra { get; set; }

        [StringLength(150)]
        public string ID_khu_vuc0 { get; set; }

        [StringLength(150)]
        public string ID_diem_don0 { get; set; }

        [StringLength(150)]
        public string ID_diem_tra0 { get; set; }

        [StringLength(50)]
        public string Khoang_cach { get; set; }

        [StringLength(10)]
        public string ID_tinh { get; set; }

        [StringLength(10)]
        public string ID_huyen { get; set; }

        [StringLength(10)]
        public string ID_xa { get; set; }

        [StringLength(150)]
        public string ID_tinh0 { get; set; }

        [StringLength(150)]
        public string ID_huyen0 { get; set; }

        [StringLength(150)]
        public string ID_xa0 { get; set; }

        [StringLength(250)]
        public string Dia_chi { get; set; }

        [StringLength(50)]
        public string Ngay_dk { get; set; }

        [StringLength(10)]
        public string Hinh_thuc_gs { get; set; }

        [StringLength(10)]
        public string Hinh_thuc_hs { get; set; }

        [StringLength(50)]
        public string Ma_hoc_sinh_ace { get; set; }

        [StringLength(50)]
        public string Ho_ten_ace { get; set; }

        public int? DKXBStatus { get; set; }

        public string JsonData { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CreatedDate { get; set; }
    }
}
