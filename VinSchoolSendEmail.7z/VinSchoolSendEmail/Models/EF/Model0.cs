namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model0 : DbContext
    {
        public Model0()
            : base("name=Model0")
        {
        }

        public virtual DbSet<Columns_vw> Columns_vw { get; set; }
        public virtual DbSet<Tables_vw> Tables_vw { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
