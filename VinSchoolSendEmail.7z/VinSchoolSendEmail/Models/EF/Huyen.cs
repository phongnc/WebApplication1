namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Huyen")]
    public partial class Huyen
    {
        public int HuyenID { get; set; }

        public int TinhID { get; set; }

        public string TenHuyen { get; set; }

        public bool? TrangThai { get; set; }
    }
}
