namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Tuyen")]
    public partial class Tuyen
    {
        public int TuyenID { get; set; }

        public int? XeVehiceID { get; set; }

        public int? XeDriverID { get; set; }

        public int? XeManagerID { get; set; }

        public string MaTuyen { get; set; }

        public string GhiChu { get; set; }

        public bool? TrangThai { get; set; }
    }
}
