namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("XeDriver")]
    public partial class XeDriver
    {
        public int XeDriverID { get; set; }

        public int? XeCompanyID { get; set; }

        public string HoTen { get; set; }

        public string MaVG { get; set; }

        public string Phone { get; set; }

        public bool? TrangThai { get; set; }
    }
}
