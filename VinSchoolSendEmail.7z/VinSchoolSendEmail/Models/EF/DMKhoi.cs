namespace VinSchoolSendEmail.Models.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("DMKhoi")]
    public partial class DMKhoi
    {
        [Key]
        public int ID_khoi { get; set; }

        [Required]
        [StringLength(5)]
        public string Ma_khoi { get; set; }

        [Required]
        [StringLength(50)]
        public string Ten_khoi { get; set; }
    }
}
